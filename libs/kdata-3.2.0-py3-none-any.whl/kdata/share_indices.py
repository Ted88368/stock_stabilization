
from enum import Enum
import pandas as pd
import os
import yaml
from typing import Callable, Dict, Tuple
import logging  

class ShareIndices(Enum):
    # S&P_500 = 'S&P 500'
    # NASDAQ_100 = 'NASDAQ 100'
    # DOW_JONES = 'Dow Jones Industrial Average'
    # FTSE_100 = 'FTSE 100'
    # NIKKEI_225 = 'Nikkei 225'
    SZ50 = "上证50"
    CSI300 = "沪深300"
    CSI500 = "中证500"
    STAR50 = "科创50"   
    SZEXT50 = "创业板50"
    # 399006,创业板指
    SZEXT = "创业板"
    # 000680,科创综指
    STAR = "科创综指"
    # 000001,上证指数
    SZMS = "上证指数"
    # 399011 深证1000
    SZ1000 = "深证1000"
    # 399019,创业200
    SZ200 = "创业200"
    # 399401,中小盘
    SZSMALL = "中小盘"
    # 399102 创业板综合指数
    SZCOMPREHENSIVE = "创业板综合指数"
    # 399012,创业300
    SZ300 = "创业300"

    # 港股通
    HKG = "港股通"


# 指数提供商和索引的映射
INDICES_CONFIG = {
    # baostock 类型
    ShareIndices.SZ50: ("baostock", None),
    ShareIndices.CSI300: ("baostock", None),
    ShareIndices.CSI500: ("baostock", None),
    # akshare 类型
    ShareIndices.STAR50: ("akshare", "000688"),
    ShareIndices.SZEXT50: ("akshare", "399673"),
    ShareIndices.SZEXT: ("akshare", "399006"),
    ShareIndices.STAR: ("akshare", "000680"),
    ShareIndices.SZMS: ("akshare", "000046"),
    ShareIndices.SZ1000: ("akshare", "399011"),
    ShareIndices.SZ200: ("akshare", "399019"),
    ShareIndices.SZSMALL: ("akshare", "399401"),
    ShareIndices.SZ300: ("akshare", "399012"),
    ShareIndices.SZCOMPREHENSIVE: ("akshare", "399102"),
    ShareIndices.HKG: ("akshare", None),
}

# baostock 查询方法映射
BAOSTOCK_QUERY_METHODS = {
    ShareIndices.SZ50: "query_sz50_stocks",
    ShareIndices.CSI300: "query_hs300_stocks",
    ShareIndices.CSI500: "query_zz500_stocks",
}


def get_share_indices_list(indices: ShareIndices) -> list:
    """
    获取指定指数的成分股列表
    Args:
        indices (ShareIndices): 指数枚举值
    Returns:
        list: 成分股代码列表
    """
    if indices not in INDICES_CONFIG:
        raise ValueError(f"不支持的指数类型: {indices}")
    
    provider, _ = INDICES_CONFIG[indices]
    if provider == "baostock":
        return get_share_indices_list_by_baostock(indices)
    elif provider == "akshare":
        return get_share_indices_list_by_akshare(indices)
    else:
        raise ValueError(f"不支持的指数提供商: {provider}")


def get_share_indices_list_by_baostock(indices: ShareIndices) -> list:
    """
    使用baostock获取指定指数的成分股列表
    Args:
        indices (ShareIndices): 指数枚举值
    Returns:
        list: 成分股代码列表
    """
    if indices not in BAOSTOCK_QUERY_METHODS:
        raise ValueError(f"不支持的baostock指数类型: {indices}")
    
    filename = f"/tmp/{indices.name.lower()}_components.csv"
    
    # 检查本地缓存
    if os.path.exists(filename):
        df = pd.read_csv(filename)
        df['code'] = df['code'].astype(str)
        return df['code'].tolist()
    
    # 从baostock下载数据
    import baostock as bs
    lg = bs.login()
    if lg.error_code != '0':
        raise ConnectionError(f"baostock登录失败，错误代码: {lg.error_code}, 错误信息: {lg.error_msg}")
    
    # 获取查询方法名
    method_name = BAOSTOCK_QUERY_METHODS[indices]
    query_method = getattr(bs, method_name)
    rs = query_method()
    
    # 处理结果
    data_list = []
    while (rs.error_code == '0') and rs.next():
        stock_code = rs.get_row_data()[1]
        data_list.append({'code': stock_code})
    
    df = pd.DataFrame(data_list)
    df.to_csv(filename, index=False)
    return df['code'].tolist()    


def download_and_save_indices_to_yaml(indices: ShareIndices, output_dir: str):
    """
    下载指定指数的成分股列表并保存为YAML文件
    Args:
        indices (ShareIndices): 指数枚举值
        output_dir (str): 输出目录
    """
    codes = get_share_indices_list(indices)

    logging.info(f"下载 {indices.value} 成分股列表，共 {len(codes)} 只股票")
    logging.debug(f"股票列表: {codes}")

    # 按市场分类
    sh_codes = []
    sz_codes = []
    hk_codes = []
    for code in codes:
        if code.startswith('sh.'):
            # 去掉前缀
            tmp = code.split('.')[-1]
            sh_codes.append(str(tmp))
        elif code.startswith('sz.'):
            tmp = code.split('.')[-1]
            sz_codes.append(str(tmp))
        elif code.startswith('hk.'):
            tmp = code.split('.')[-1]
            hk_codes.append(str(tmp))
    filename = f"{indices.name.lower()}.yaml"
    filepath = os.path.join(output_dir, filename)
    data = {}
    if sh_codes:
        data["sh"] = sh_codes
    if sz_codes:
        data["sz"] = sz_codes
    if hk_codes:
        data["hk"] = hk_codes
    
    # 自定义YAML dumper，确保字符串带引号
    class CustomDumper(yaml.SafeDumper):
        pass

    # 注册自定义的字符串表示方法
    def represent_str(dumper, data):
        return dumper.represent_scalar('tag:yaml.org,2002:str', data, style="'")

    CustomDumper.add_representer(str, represent_str)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, Dumper=CustomDumper, default_flow_style=False, allow_unicode=True)
    logging.info(f"已保存 {indices.value} 成分股到 {filepath}")



def get_share_indices_list_by_akshare(indices: ShareIndices) -> list:
    """
    使用akshare获取指定指数的成分股列表
    Args:
        indices (ShareIndices): 指数枚举值
    Returns:
        list: 成分股代码列表
    """
    import akshare as ak
    
    if indices not in INDICES_CONFIG:
        raise ValueError(f"不支持的指数类型: {indices}")
    
    _, symbol = INDICES_CONFIG[indices]
    filename = f"/tmp/{indices.name.lower()}_components_ak.csv"
    
    # 特殊处理港股
    if indices == ShareIndices.HKG:
        return _get_hkg_codes(filename)
    
    # 特殊处理需要自定义列名的指数
    if indices in [ShareIndices.SZ300, ShareIndices.SZCOMPREHENSIVE]:
        column_name = '代码'
    else:
        column_name = '品种代码'
    
    # 检查本地缓存
    if os.path.exists(filename):
        df = pd.read_csv(filename)
        if column_name in df.columns:
            df[column_name] = df[column_name].astype(str)
            codes = df[column_name].tolist()
        else:
            # 如果列名不存在，重新下载
            return _fetch_akshare_data(ak, indices, symbol, filename, column_name)
    else:
        codes = _fetch_akshare_data(ak, indices, symbol, filename, column_name)
    
    # 添加前缀并返回
    return _add_stock_prefix(codes)


def _fetch_akshare_data(ak, indices: ShareIndices, symbol: str, filename: str, column_name: str) -> list:
    """
    从akshare获取数据并保存到文件
    """
    if indices == ShareIndices.HKG:
        df = ak.stock_hk_ggt_components_em()
        column_name = '代码'
    else:
        df = ak.index_stock_cons(symbol=symbol)
    
    # 处理列名：如果指定的列名不存在，尝试其他可能的列名
    if column_name not in df.columns:
        # 尝试其他常见列名
        alternative_names = ['品种代码', '代码', '股票代码', 'code', 'symbol']
        found = False
        for alt_name in alternative_names:
            if alt_name in df.columns:
                column_name = alt_name
                found = True
                break
        if not found:
            # 如果都没找到，使用第一列
            column_name = df.columns[1] if len(df.columns) > 1 else df.columns[0]
            logging.warning(f"未找到预期的列名，使用第一列: {column_name}")
    
    df[column_name] = df[column_name].astype(str)
    df.to_csv(filename, index=False)
    return df[column_name].tolist()


def _get_hkg_codes(filename: str) -> list:
    """
    获取港股通代码，处理特殊的文件格式
    """
    import akshare as ak
    
    if os.path.exists(filename):
        try:
            # 尝试按有表头的格式读取
            df = pd.read_csv(filename)
            if '代码' in df.columns:
                df['代码'] = df['代码'].astype(str)
                codes = df['代码'].tolist()
            else:
                # 如果没有'代码'列，尝试按无表头的格式读取
                df = pd.read_csv(filename, header=None)
                # 确保至少有两列
                if len(df.columns) >= 2:
                    # 股票代码在第二列（索引1）
                    df[1] = df[1].astype(str).str.zfill(5)
                    codes = df[1].tolist()
                else:
                    # 如果格式不正确，重新下载
                    df = ak.stock_hk_ggt_components_em()
                    df['代码'] = df['代码'].astype(str).str.zfill(5)
                    df.to_csv(filename, index=False)
                    codes = df['代码'].tolist()
        except:
            # 如果读取失败，重新下载
            df = ak.stock_hk_ggt_components_em()
            df['代码'] = df['代码'].astype(str).str.zfill(5)
            df.to_csv(filename, index=False)
            codes = df['代码'].tolist()
    else:
        df = ak.stock_hk_ggt_components_em()
        df['代码'] = df['代码'].astype(str).str.zfill(5)
        df.to_csv(filename, index=False)
        codes = df['代码'].tolist()
    
    return codes


def _add_stock_prefix(codes: list) -> list:
    """
    根据股票代码确定前缀（sh、sz、hk）并返回带前缀的代码
    """
    result = []
    for code in codes:
        # 只有5位就是香港的
        if len(str(code)) == 5:
            prefix = "hk."
            result.append(prefix + code)
        else:
            # 确保code是字符串并格式化为6位
            code_str = str(code).zfill(6)
            if code_str:
                try:
                    code_num = int(code_str)
                    prefix = "sz." if code_num < 400000 else "sh."
                    result.append(prefix + code_str)
                except ValueError:
                    # 处理无法转换为整数的代码
                    prefix = "sz."
                    result.append(prefix + code_str)
            else:
                # 处理空代码
                prefix = "sz."
                result.append(prefix + code_str)
    
    logging.info(f"共处理 {len(codes)} 个股票代码，生成 {len(result)} 个带前缀的股票代码")
    logging.info(f"前10个股票代码：{result[:10]}")
    return result