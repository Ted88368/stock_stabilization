"""Simple CLI to download and inspect K-line data using kdata package.

Usage examples (after `pip install -e .`):
  kdata-download sh.000300 2023-01-01 2023-01-31

This script intentionally keeps dependencies light and prints helpful errors
when provider libraries are not installed.
"""
from __future__ import annotations

import argparse
import sys
from typing import Optional

from .provider import DownloadProvider
from .env import get_data_dir, data_file_path, init_env
import os
from typing import Any
import logging
log = logging.getLogger(__name__)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

# Try to import single-download helper at module import time; if unavailable keep None
try:
    from kdata.data import get_ohlc  # type: ignore
except Exception:
    get_ohlc = None


def _load_yaml_jobs(path: str):
    """Load jobs from a YAML file and return a list of job dicts.

    Expected simple formats:
    - A list of job mappings: - code: sh.000300\n  start: 2023-01-01\n  end: 2023-01-31
    - Or a mapping with a top-level key `jobs` containing the list.
    Each job may include: code (or symbol), start, end, provider (optional), out (optional path) or out_dir.
    """
    try:
        import yaml
    except Exception as exc:  # ImportError
        raise ImportError("要使用 --batch 功能请先安装 pyyaml: python -m pip install pyyaml") from exc

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if data is None:
        return []

    parsed = []

    # case A: explicit jobs list
    if isinstance(data, dict) and "jobs" in data:
        jobs = data["jobs"]
        for item in jobs:
            if not isinstance(item, dict):
                continue
            code = item.get("code") or item.get("symbol")
            if not code:
                continue
            parsed.append({
                "code": code,
                "start": item.get("start"),
                "end": item.get("end"),
                "provider": item.get("provider"),
                "out": item.get("out"),
                "out_dir": item.get("out_dir"),
            })
        return parsed

    # case B: plain list of job dicts
    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            code = item.get("code") or item.get("symbol")
            if not code:
                continue
            parsed.append({
                "code": code,
                "start": item.get("start"),
                "end": item.get("end"),
                "provider": item.get("provider"),
                "out": item.get("out"),
                "out_dir": item.get("out_dir"),
            })
        return parsed

    # case C: mapping of provider/exchange -> list of codes (current data/ config files)
    if isinstance(data, dict):
        for key, val in data.items():
            if not isinstance(val, list):
                continue
            # map yaml top-level key to provider key used by BatchDownloader
            k = str(key).lower()
            if k in ("usa", "us"):
                provider = "usa"
            elif k in ("hk", "h", "hongkong"):
                provider = "hk"
            elif k in ("etf",):
                provider = "etf"
            elif k in ("sh", "sz", "a", "cn", "china"):
                provider = "baostock"
            else:
                # fallback: use key name as provider
                provider = k

            for code in val:
                # accept plain scalars; include market (top-level key) so we can
                # later normalize codes to the 9-char form like 'sh.600000'
                parsed.append({
                    "code": str(code),
                    "start": None,
                    "end": None,
                    "provider": provider,
                    "out": None,
                    "out_dir": None,
                    "market": k,
                })
        return parsed

    raise ValueError(f"无法识别的批量文件格式: {path}")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="kdata-download", description="Download and show K-line data using kdata providers")
    # make positional args optional so we can run in --batch mode without them
    parser.add_argument("code", nargs="?", help="code or symbol, e.g. sh.000300 or 000300.SH")
    parser.add_argument("start", nargs="?", help="start date YYYY-MM-DD")
    parser.add_argument("end", nargs="?", help="end date YYYY-MM-DD")
    parser.add_argument("--provider", default=None, help="provider name (optional). If omitted, data.get_ohlc will decide")
    parser.add_argument("--out", help="optional CSV path to write the result")
    parser.add_argument("--data-dir", help="optional data directory to initialize K_DATA_CENTER")
    parser.add_argument("--batch", help="path to a YAML batch file (or directory) describing jobs")
    parser.add_argument("--batch-dir", help="directory to scan for YAML batch files (defaults to data dir)")

    args = parser.parse_args(argv)

    if args.data_dir:
        init_env(args.data_dir)
    else:
        # ensure default data dir exists
        init_env()

    # decide if we should run batch mode: explicit flags or YAML files under data dir
    batch_path = args.batch
    batch_dir = args.batch_dir
    # if no explicit batch flags, but data dir contains yaml files, default to batch_dir=data_dir
    if not batch_path and not batch_dir:
        try:
            data_dir = get_data_dir()
            if os.path.isdir(data_dir):
                for fn in os.listdir(data_dir):
                    if fn.lower().endswith((".yml", ".yaml")):
                        batch_dir = data_dir
                        break
        except Exception:
            # if get_data_dir fails, ignore and continue
            pass

    # if not in batch mode, ensure helper is available
    if not batch_path and not batch_dir:
        if get_ohlc is None:
            print("无法导入 kdata.data: get_ohlc 未找到。请确保包已正确安装或使用 PYTHONPATH=src。", file=sys.stderr)
            return 2

    # support batch mode: load YAML job specs and use BatchDownloader
    batch_path = args.batch
    batch_dir = args.batch_dir
    if batch_path or batch_dir:
        # lazy import BatchDownloader
        try:
            from kdata.batch import BatchDownloader
        except Exception as exc:
            print("无法导入 BatchDownloader:", exc, file=sys.stderr)
            return 6

        dl = BatchDownloader()

        # collect job dicts
        jobs: list[dict[str, Any]] = []
        # if explicit batch file path given
        if batch_path:
            if os.path.isdir(batch_path):
                # scan for yaml files
                for fn in os.listdir(batch_path):
                    if fn.lower().endswith(('.yml', '.yaml')):
                        full = os.path.join(batch_path, fn)
                        jobs.extend(_load_yaml_jobs(full))
            else:
                jobs.extend(_load_yaml_jobs(batch_path))

        # batch_dir overrides or supplements
        bd = batch_dir or (get_data_dir() if not batch_path else None)
        if bd:
            if os.path.isdir(bd):
                for fn in os.listdir(bd):
                    if fn.lower().endswith(('.yml', '.yaml')):
                        full = os.path.join(bd, fn)
                        jobs.extend(_load_yaml_jobs(full))

        if not jobs:
            print("未找到任何批量任务（YAML）。", file=sys.stderr)
            return 7

        # group jobs by (start,end,provider,out_dir) where out_dir is used as target dir
        groups: dict[tuple, list[str]] = {}
        per_job_out_files: list[dict[str, Any]] = []
        for j in jobs:
            code = j.get("code")
            # job-specific start/end fall back to CLI positional args
            start = j.get("start") or args.start
            end = j.get("end") or args.end
            # If still missing, derive sensible defaults: use an end date of today
            # and a start date defaulting to (end - N days). N can be overridden
            # by env KDATA_DEFAULT_WINDOW_DAYS. This lets users keep YAML unchanged.
            if not start or not end:
                from datetime import date, timedelta

                try:
                    window = int(os.environ.get("KDATA_DEFAULT_WINDOW_DAYS", "365"))
                except Exception:
                    window = 90

                def _parse(d: str):
                    from datetime import datetime

                    try:
                        return datetime.fromisoformat(d).date()
                    except Exception:
                        # try common yyyy-mm-dd fallback
                        try:
                            return date.fromisoformat(d)
                        except Exception:
                            return None

                parsed_start = _parse(start) if start else None
                parsed_end = _parse(end) if end else None

                if parsed_start and not parsed_end:
                    parsed_end = date.today()
                if parsed_end and not parsed_start:
                    parsed_start = parsed_end - timedelta(days=window)
                if not parsed_start and not parsed_end:
                    # both missing -> default to last `window` days
                    parsed_end = date.today()
                    parsed_start = parsed_end - timedelta(days=window)

                if not parsed_start or not parsed_end:
                    print(f"任务 {code} 无法解析 start/end（{start}/{end}），请在命令行或 YAML 中指定有效日期。", file=sys.stderr)
                    return 12

                # format back to ISO strings for provider calls
                start = parsed_start.isoformat()
                end = parsed_end.isoformat()

            provider = j.get("provider")
            # normalize China A codes to the 9-char format, e.g. 'sh.600000'
            if provider == "baostock":
                # if code already has a market prefix, leave it
                if isinstance(code, str) and "." not in code and code.isdigit() and len(code) == 6:
                    market = j.get("market")
                    if market in ("sh", "sz"):
                        code = f"{market}.{code}"
                    else:
                        # heuristic: codes starting with '6' -> sh, otherwise sz
                        if code.startswith("6"):
                            code = f"sh.{code}"
                        else:
                            code = f"sz.{code}"
            out = j.get("out")
            out_dir = j.get("out_dir") or (get_data_dir() if args.data_dir is None else args.data_dir)
            if out:
                # special-case: save to explicit output file per-job
                per_job_out_files.append({"code": code, "start": start, "end": end, "provider": provider, "out": out})
            else:
                key = (start, end, provider, out_dir)
                groups.setdefault(key, []).append(code)

        # 按组顺序下载（限速由各 provider 的 global_pacer 控制）
        overall_results = []
        for (start, end, provider, out_dir), symbols in groups.items():
            log.info(f"下载 {len(symbols)} 个符号，范围 {start}..{end}，provider={provider}，out_dir={out_dir}")
            res = dl.download(symbols, start, end, provider=provider, out_dir=out_dir, stop_on_error=True)
            overall_results.extend(res)
            # 如果开启了 stop_on_error 且该组有失败，后续组也不再运行
            if any(not r.ok for r in res):
                log.info("检测到下载失败，由于 stop_on_error=True，停止后续下载任务")
                break

        # handle explicit per-job out files individually
        for job in per_job_out_files:
            code = job["code"]
            start = job["start"]
            end = job["end"]
            provider = job.get("provider")
            out = job["out"]
            # resolve provider function
            key = provider or None
            fn = None
            if key and key in dl.provider_map:
                fn = dl.provider_map[key]
            else:
                # try provider detection via internal helper
                # fall back to BatchDownloader detection by invoking download for single symbol
                res = dl.download([code], start, end, provider=provider)
                overall_results.extend(res)
                # if file was saved by download, move/rename to requested out
                # download writes canonical path under out_dir; we will skip move in this path
                continue

            try:
                df = fn(code, start, end)
            except Exception as exc:
                overall_results.append(type("R", (), {"symbol": code, "ok": False, "path": None, "error": exc}))
                continue

            try:
                # ensure parent exists
                os.makedirs(os.path.dirname(out), exist_ok=True)
                df.to_csv(out)
                overall_results.append(type("R", (), {"symbol": code, "ok": True, "path": out, "error": None}))
            except Exception as exc:
                overall_results.append(type("R", (), {"symbol": code, "ok": False, "path": None, "error": exc}))

        # Summarize
        succ = [r for r in overall_results if getattr(r, "ok", False)]
        fail = [r for r in overall_results if not getattr(r, "ok", False)]
        log.info(f"批量完成：成功 {len(succ)}，失败 {len(fail)}")
        if fail:
            for r in fail:
                log.error(f"{getattr(r,'symbol',None)} -> 错误: {getattr(r,'error',None)}")
            return 8 if succ else 9
        return 0

    # 处理 provider 字符串转枚举
    download_provider = DownloadProvider.AUTO
    if args.provider:
        try:
            download_provider = DownloadProvider(args.provider)
        except ValueError:
            print(f"警告: 不支持的 provider '{args.provider}'，将使用 AUTO 模式", file=sys.stderr)

    try:
        df = get_ohlc(args.code, args.start, args.end, download_provider=download_provider)
    except ImportError as exc:
        # provider-specific dependency missing
        print("数据提供器依赖未安装:", exc, file=sys.stderr)
        print("按需安装（例如：pandas, baostock, akshare, efinance 等）。", file=sys.stderr)
        return 3
    except Exception as exc:
        print("获取 K 线数据失败:", exc, file=sys.stderr)
        return 4

    # Print basic info
    try:
        print(f"data dir: {get_data_dir()}")
    except Exception:
        pass

    try:
        # try to print head if pandas DataFrame
        print(df.head())
    except Exception:
        print(df)

    # By default save to the data directory defined by K_DATA_CENTER unless --out provided
    out_path = args.out
    if out_path is None:
        out_path = data_file_path(args.code, args.start, args.end)

    try:
        df.to_csv(out_path)
        print(f"Saved to {out_path}")
    except Exception as exc:
        print("保存 CSV 失败:", exc, file=sys.stderr)
        return 5

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
