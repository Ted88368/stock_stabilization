import talib
import pandas as pd
def set_rsi(df, timeperiod=6):

    # if 'RSI' in df.columns and 'RSI_6' in df.columns and 'RSI_12' in df.columns and 'RSI_24' in df.columns:
    #     return

    df['RSI'] = talib.RSI(df['close'], timeperiod=timeperiod)
    df['RSI_6'] = talib.RSI(df['close'], timeperiod=6)
    df['RSI_12'] = talib.RSI(df['close'], timeperiod=12)
    df['RSI_24'] = talib.RSI(df['close'], timeperiod=24)
    # return df