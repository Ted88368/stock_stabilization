import talib
from talib import MA_Type

def set_boll(df, ma_type=MA_Type.EMA):

    # if "upper_band" in df.columns and "middle_band" in df.columns and "lower_band" in df.columns:
    #     return

    # 计算布林线
    # 计算 Bollinger Bands，默认参数20日均线，2倍标准差
    df['upper_band'], df['middle_band'], df['lower_band'] = talib.BBANDS(df['close'], timeperiod=20, nbdevup=2,
                                                                         nbdevdn=2, matype=MA_Type.EMA)
    # return df
