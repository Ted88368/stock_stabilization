import talib


def set_kdj(df):


    # if "K" in df.columns and "D" in df.columns and "J" in df.columns:
    #     return df

    # 使用 talib.STOCH 计算 %K 和 %D（这里选择常用参数：9, 3, 3），
    # %K 即为 K 值，%D 即为 D 值
    df['K'], df['D'] = talib.STOCH(df['high'], df['low'], df['close'],
                                   fastk_period=9, slowk_period=3, slowk_matype=0,
                                   slowd_period=3, slowd_matype=0)
    # 计算 J 值
    df['J'] = 3 * df['K'] - 2 * df['D']

    return df
