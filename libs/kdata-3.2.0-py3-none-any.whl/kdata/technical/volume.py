import talib
import pandas as pd

def set_volume(df):
    """
    计算成交量指标
    :param df: 股票数据
    :return: 更新后的数据框
    """

    # 成交量均线
    df['Volume_MA'] = talib.SMA(df['volume'], timeperiod=20)
    
    # VR（Volume Ratio）指标代表成交量比率。它是一种技术指标，用于衡量某个特定时间段内上涨和下跌交易量的相对关系。
    # VR指标通常用于期货市场中的技术分析，旨在辅助判断标的物的买卖压力和价格趋势。
    # VR指标的计算方式如下： VR = （上涨交易总量 / 下跌交易总量）*100
    # 计算结果的数值范围通常在0到100之间。数值越高，意味着上涨交易量相对较大，市场情绪偏乐观；数值越低，意味着下跌交易量相对较大，市场情绪偏悲观。

    # 自定义计算正负成交量比率（周期N=14）
    # 上涨的成交总量
    up_volume = df['volume'].where(df['close'] > df['close'].shift(1), 0).rolling(14).sum()

    # 下跌的成交总量
    down_volume = df['volume'].where(df['close'] < df['close'].shift(1), 0).rolling(14).sum()
    df['Volume_Ratio'] = up_volume / down_volume * 100 # 避免除零需处理异常值

    atr_period = 14
    df['ATR'] = talib.ATR(df['high'], df['low'], df['close'], timeperiod=atr_period)

    # 波动率 (过去20天收盘价的标准差/均值)
    # 计算波动率
    volatility_period = 20
    df['Volatility'] = talib.STDDEV(df['close'], timeperiod=volatility_period) / talib.SMA(df['close'],
                    timeperiod=volatility_period) * 100


