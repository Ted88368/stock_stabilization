import os
import threading
import warnings
import pandas as pd
from typing import Optional, Callable, Dict, Tuple
from enum import Enum

from .env import data_file_path
from .provider import OHLC, Period, DownloadProvider
from .kdata_utils import generate_weekly_kdata
from .utils.cleaner import clean_ohlc_data
from .utils.pacing import global_pacer
import efinance as ef
import akshare as ak
from mootdx.quotes import Quotes
from mootdx.consts import (
    KLINE_DAILY,
    KLINE_WEEKLY,
    MARKET_SH,
    MARKET_SZ,
)
from datetime import datetime, timedelta, timezone
import json
import logging

log = logging.getLogger(__name__)

# 过滤 mootdx 库的 ResourceWarning
warnings.filterwarnings(
    "ignore", message=".*unclosed file.*mootdx.*config.json.*", category=ResourceWarning
)

class DownloadFunctionManager:
    """下载函数管理器，支持手动和自动切换"""

    def __init__(self, cache_dir: Optional[str] = None):
        """
        初始化下载函数管理器

        Args:
            cache_dir: 缓存目录，用于存储失败记录
        """
        self.cache_dir = cache_dir or os.getenv("K_DATA_CENTER") or "/tmp"
        self.cache_file = os.path.join(
            self.cache_dir, "etf_download_failure_cache.json"
        )
        self.failure_timeout = timedelta(hours=12)

        # 注册下载函数
        self.download_functions: Dict[str, Callable] = {
            DownloadProvider.EFINANCE.value: self._download_with_efinance,
            DownloadProvider.AKSHARE.value: self._download_with_akshare,
            DownloadProvider.MOOTDX.value: self._download_with_mootdx,
        }

        # 下载函数优先级（自动模式下的尝试顺序）
        self.priority_order = [
            DownloadProvider.MOOTDX.value,
            DownloadProvider.EFINANCE.value,
            DownloadProvider.AKSHARE.value,
        ]

    def _download_with_efinance(self, stock_code: str) -> pd.DataFrame:
        log.info(f"Downloading ETF data for {stock_code} using efinance")

        """使用efinance下载数据"""
        return ef.stock.get_quote_history(stock_code)

    def _download_with_akshare(self, stock_code: str) -> pd.DataFrame:
        """使用akshare下载数据"""

        # 感觉编号需要添加sh或者sz
        # 上交所ETF：代码以 51、56、58​ 开头
        # 深交所ETF：代码以 15、16​ 开头
        if (
            stock_code.startswith("51")
            or stock_code.startswith("56")
            or stock_code.startswith("58")
        ):
            stock_code = "sh" + stock_code
        elif stock_code.startswith("15") or stock_code.startswith("16"):
            stock_code = "sz" + stock_code
        else:
            raise RuntimeError(f"akshare does not support {stock_code}")

        log.info(f"akshare download ETF data for {stock_code}")

        data = ak.fund_etf_hist_sina(symbol=stock_code)
        if data is None or data.empty:
            raise RuntimeError(f"akshare returned empty data for {stock_code}")
        return data

    def _download_with_mootdx(self, stock_code: str) -> pd.DataFrame:
        """使用mootdx下载数据"""
        log.info(f"mootdx download ETF data for {stock_code}")

        # ETF代码通常是6位数字，需要确定市场
        # 上交所ETF/基金：代码以 5 开头（50、51、56、58 等）
        # 深交所ETF：代码以 15、16​ 开头
        symbol = stock_code.strip().zfill(6)

        if symbol.startswith("5"):
            market = MARKET_SH
        elif symbol.startswith("1"):
            market = MARKET_SZ
        else:
            raise RuntimeError(f"mootdx does not support ETF code: {stock_code}")

        # 创建客户端并获取数据
        client = Quotes.factory(market="std")
        data = client.bars(
            symbol=symbol, frequency=KLINE_DAILY, market=market, start=0, offset=1000
        )

        if data is None or data.empty:
            raise RuntimeError(f"mootdx returned empty data for {stock_code}")

        # 转换列名到标准格式
        # mootdx返回的列名可能是 datetime, open, high, low, close, volume 等
        column_mapping = {
            "datetime": "date",
            "open": "open",
            "high": "high",
            "low": "low",
            "close": "close",
            "volume": "volume",
        }

        for old_name, new_name in column_mapping.items():
            if old_name in data.columns:
                data = data.rename(columns={old_name: new_name})

        # 标准化日期格式：去掉时分秒，只保留日期部分
        if "date" in data.columns:
            data["date"] = pd.to_datetime(data["date"]).dt.normalize()

        # 确保有必要的列
        required_cols = ["date", "open", "high", "low", "close", "volume"]
        for col in required_cols:
            if col not in data.columns:
                raise RuntimeError(f"mootdx data missing required column: {col}")

        return data

    def _load_failure_cache(self) -> Dict:
        """加载失败记录缓存"""
        if not os.path.exists(self.cache_file):
            return {}
        try:
            with open(self.cache_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            log.warning(f"Failed to load failure cache: {e}")
            return {}

    def _save_failure_cache(self, cache: Dict):
        """保存失败记录缓存"""
        try:
            with open(self.cache_file, "w", encoding="utf-8") as f:
                json.dump(cache, f)
        except Exception as e:
            log.warning(f"Failed to save failure cache: {e}")

    def _record_failure(self, provider: str):
        """记录下载函数失败"""
        cache = self._load_failure_cache()
        now = datetime.now(timezone.utc)
        cache[provider] = {
            "last_failure": now.isoformat(),
            "failure_count": cache.get(provider, {}).get("failure_count", 0) + 1,
        }
        self._save_failure_cache(cache)
        log.info(f"Recorded failure for {provider} at {now.isoformat()}")

    def _clear_failure(self, provider: str):
        """清除下载函数的失败记录"""
        cache = self._load_failure_cache()
        if provider in cache:
            cache.pop(provider)
            self._save_failure_cache(cache)
            log.info(f"Cleared failure record for {provider}")

    def _is_provider_available(self, provider: str) -> bool:
        """检查下载函数是否可用（12小时内未失败）"""
        cache = self._load_failure_cache()
        if provider not in cache:
            return True

        failure_info = cache[provider]
        if "last_failure" not in failure_info:
            return True

        try:
            last_failure_str = failure_info["last_failure"]
            # 解析ISO格式的datetime字符串，确保是时区感知的
            last_failure = datetime.fromisoformat(last_failure_str)
            # 如果解析出来的是naive datetime，添加UTC时区
            if last_failure.tzinfo is None:
                last_failure = last_failure.replace(tzinfo=timezone.utc)

            now = datetime.now(timezone.utc)
            if now - last_failure < self.failure_timeout:
                log.debug(
                    f"{provider} is unavailable (failed {now - last_failure} ago)"
                )
                return False
            else:
                # 超过12小时，清除失败记录
                self._clear_failure(provider)
                return True
        except Exception as e:
            log.warning(f"Error checking provider availability: {e}")
            return True

    def download(
        self, stock_code: str, provider: DownloadProvider = DownloadProvider.AUTO
    ) -> Tuple[pd.DataFrame, str]:
        """
        下载ETF数据

        Args:
            stock_code: ETF代码
            provider: 下载函数提供者，可以是EFINANCE、AKSHARE或AUTO（自动切换）

        Returns:
            Tuple[DataFrame, str]: (数据, 使用的提供者名称)

        Raises:
            RuntimeError: 所有下载函数都失败时抛出
        """
        # 手动指定提供者
        if provider != DownloadProvider.AUTO:
            provider_name = provider.value
            # 手动指定时，即使提供者之前失败过，也允许强制尝试
            is_available = self._is_provider_available(provider_name)
            if not is_available:
                log.warning(
                    f"{provider_name} was marked as failed within last 12 hours, "
                    f"but allowing forced retry since provider was manually specified"
                )

            try:
                # Use global pacer to handle implementation-specific pacing
                with global_pacer.limit(provider_name):
                    data = self.download_functions[provider_name](stock_code)
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(f"Successfully downloaded {stock_code} using {provider_name}")
                return data, provider_name
            except Exception as e:
                self._record_failure(provider_name)
                log.error(f"Failed to download {stock_code} using {provider_name}: {e}")
                raise RuntimeError(
                    f"Failed to download {stock_code} using {provider_name}: {e}"
                )

        # 自动切换模式：按优先级尝试可用的下载函数
        available_providers = [
            p for p in self.priority_order if self._is_provider_available(p)
        ]

        if not available_providers:
            raise RuntimeError(
                f"All download providers are temporarily unavailable "
                f"(failed within last 12 hours). Please try again later."
            )

        last_error = None
        for provider_name in available_providers:
            try:
                with global_pacer.limit(provider_name):
                    data = self.download_functions[provider_name](stock_code)
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(
                    f"Successfully downloaded {stock_code} using {provider_name} (auto mode)"
                )
                return data, provider_name
            except Exception as e:
                self._record_failure(provider_name)
                last_error = e
                log.warning(
                    f"Failed to download {stock_code} using {provider_name}: {e}"
                )
                continue

        # 所有提供者都失败
        raise RuntimeError(
            f"All download providers failed for {stock_code}. Last error: {last_error}"
        )


class ETF(OHLC):
    name_file_lock = threading.Lock()

    def __init__(self, download_provider: DownloadProvider = DownloadProvider.AUTO):
        """
        初始化ETF类

        Args:
            download_provider: 下载函数提供者，默认为自动切换模式
        """
        self.stock_name = ""
        self.download_provider = download_provider
        self.download_manager = DownloadFunctionManager()

    def rename(self, name):
        return "{}-{}".format(name, self.stock_name)

    def get_k_data(
        self,
        stock_code: str,
        start_date: str,
        end_date: str,
        period: Period = Period.DAILY,
        download_provider: Optional[DownloadProvider] = None,
    ) -> pd.DataFrame:
        """
        获取ETF的K线数据

        Args:
            stock_code: ETF代码
            start_date: 开始日期
            end_date: 结束日期
            period: 周期，目前支持Period.DAILY（日K）和Period.WEEKLY（周K）
            download_provider: 下载函数提供者，如果为None则使用初始化时设置的提供者

        Returns:
            DataFrame: OHLC数据
        """
        name = self.rename(stock_code)
        df = None

        # 构建缓存文件路径，包含周期信息
        data_file = data_file_path(stock_code, start_date, end_date, period)
        data = None
        if os.path.exists(data_file):
            data = pd.read_csv(data_file)
            df = data
            df["Date"] = pd.to_datetime(df["Date"])
            df.set_index("Date", inplace=True)

            # 数据清洗
            df = clean_ohlc_data(df)

            return df
        else:
            if period == Period.DAILY:
                # 使用下载函数管理器获取数据
                provider = (
                    download_provider
                    if download_provider is not None
                    else self.download_provider
                )
                try:
                    data, data_source = self.download_manager.download(
                        stock_code, provider
                    )
                except RuntimeError as e:
                    log.error(f"Failed to download ETF data for {stock_code}: {e}")
                    raise
                # 如果 akshare 返回的列是英文 'date'，统一为中文 '日期' 以匹配后续处理
                if "日期" not in data.columns and "date" in data.columns:
                    data = data.rename(columns={"date": "日期"})

                # 先获取名字(股票名称)
                #         股票名称    股票代码          日期     开盘     收盘     最高     最低         成交量           成交额    振幅   涨跌幅    涨跌额    换手率
                # 0     中概互联网ETF  513050  2017-01-18  0.989  0.977  0.989  0.969    345605.0  3.381795e+07  0.00  0.00  0.000   0.26
                if self.stock_name == "":
                    if "股票名称" in data.columns:
                        self.stock_name = data.iloc[0]["股票名称"]
                    else:
                        # akshare 备份可能没有 股票名称 列，尝试从其它列或忽略
                        if data_source == "akshare" and "基金简称" in data.columns:
                            self.stock_name = data.iloc[0]["基金简称"]

                    # kv to json
                    filename = os.path.join(
                        os.getenv("K_DATA_CENTER") or "/tmp",
                        "etf_name_from_efinance.json",
                    )
                    with self.name_file_lock:
                        if not os.path.exists(filename):
                            kv = {}
                        else:
                            with open(filename, "r", encoding="utf-8") as f:
                                try:
                                    kv = json.load(f)
                                except Exception:
                                    kv = {}

                        kv[stock_code] = self.stock_name
                        # dump file
                        with open(filename, "w", encoding="utf-8") as f:
                            json.dump(kv, f)

                # do not persist here; BatchDownloader is responsible for storage
                # 过滤日期范围
                # 列名映射和兼容：使用可用列的交集来构造数据
                candidates = {
                    "Date": ["日期", "date"],
                    "open": ["开盘", "open"],
                    "high": ["最高", "high"],
                    "low": ["最低", "low"],
                    "close": ["收盘", "close"],
                    "volume": ["成交量", "成交额", "volume"],
                }

                found = {}
                cols = list(data.columns)
                for key, names in candidates.items():
                    for n in names:
                        if n in cols:
                            found[key] = n
                            break

                required = ["Date", "open", "high", "low", "close"]
                if not all(k in found for k in required):
                    log.warning(
                        "ETF %s: missing required columns, available=%s",
                        stock_code,
                        cols,
                    )
                    # 返回空的 DataFrame（不要把 'Date' 也作为列，否则保存时会出现重复的 Date 列头）
                    empty = pd.DataFrame(
                        columns=["open", "high", "low", "close", "volume"]
                    )
                    empty.index.name = "Date"
                    return empty

                # 构造最终 DataFrame 列表（带可选 volume）
                use_cols = [
                    found["Date"],
                    found["open"],
                    found["high"],
                    found["low"],
                    found["close"],
                ]
                if "volume" in found:
                    use_cols.append(found["volume"])

                df = data[use_cols].rename(
                    columns={
                        found["Date"]: "Date",
                        found["open"]: "open",
                        found["high"]: "high",
                        found["low"]: "low",
                        found["close"]: "close",
                        found.get("volume"): "volume",
                    }
                )
                # 确保Date列是datetime类型
                df["Date"] = pd.to_datetime(df["Date"])
                df.set_index("Date", inplace=True)
                # 过滤日期范围
                # 注意：需要标准化日期以包含整个 end_date
                # mootdx 返回的时间戳包含时间部分（如 15:00:00）
                # 如果 end_date 是 "2026-02-02"，pd.to_datetime 会转换为 "2026-02-02 00:00:00"
                # 这会导致当天 15:00:00 的数据被排除
                start = pd.to_datetime(start_date).normalize()
                end = pd.to_datetime(end_date).normalize() + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
                filtered_df = df[start:end]
                df = filtered_df

            # 转换为周K数据或直接使用日K数据
            elif period == Period.WEEKLY:
                # 周K数据需要先将日期列命名为'date'（小写）以适配generate_weekly_kdata函数
                daily_df = self.get_k_data(
                    stock_code, start_date, end_date, period=Period.DAILY
                )
                # 调用周K生成函数
                # 重置索引，将Date索引转换为Date列
                daily_df = daily_df.reset_index()
                # 生成周线数据
                df = generate_weekly_kdata(daily_df)
            else:
                raise NotImplementedError(f"ETF类目前不支持{period}周期数据获取")

        # 转换数据类型
        df[["open", "high", "low", "close", "volume"]] = df[
            ["open", "high", "low", "close", "volume"]
        ].astype(float)

        # Ensure 'Date' is the index and not also a column to avoid duplicated 'Date' header
        if "Date" in df.columns and not isinstance(df.index, pd.DatetimeIndex):
            try:
                df["Date"] = pd.to_datetime(df["Date"])
                df.set_index("Date", inplace=True)
            except Exception:
                df = df.drop(columns=["Date"], errors="ignore")

        if "Date" in df.columns:
            df = df.drop(columns=["Date"], errors="ignore")

        if not os.path.exists(data_file):
            df.to_csv(data_file, index=True)

        # 数据清洗
        df = clean_ohlc_data(df)

        # 确保index为DatetimeIndex，且命名为'Date'
        if not isinstance(df.index, pd.DatetimeIndex):
            try:
                df.index = pd.to_datetime(df.index)
            except Exception:
                pass
        df.index.name = "Date"
        return df
