# -*- coding: utf-8 -*-
from venv import logger
import os
import pandas as pd
import akshare as ak
from datetime import datetime, timedelta, timezone
from typing import Optional, Callable, Dict, Tuple
from enum import Enum
import json
import logging

from .env import get_data_dir, data_file_path
from .utils.pacing import global_pacer
from .provider import OHLC, Period, DownloadProvider
from .kdata_utils import generate_weekly_kdata
from .utils.cleaner import clean_ohlc_data
from .utils.tiingo_tokens import tiingo_token_manager


log = logging.getLogger(__name__)





class USADownloadFunctionManager:
    """美股下载函数管理器，支持手动和自动切换"""
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        初始化下载函数管理器
        
        Args:
            cache_dir: 缓存目录，用于存储失败记录
        """
        self.cache_dir = cache_dir or os.getenv("K_DATA_CENTER") or "/tmp"
        self.cache_file = os.path.join(self.cache_dir, "usa_download_failure_cache.json")
        self.failure_timeout = timedelta(hours=12)
        
        self.download_functions: Dict[str, Callable] = {
            DownloadProvider.TIINGO.value: self._download_with_tiingo,
            DownloadProvider.YFINANCE.value: self._download_with_yfinance,
            DownloadProvider.STOCK_US_DAILY.value: self._download_with_stock_us_daily,
            DownloadProvider.STOCK_US_HIST.value: self._download_with_stock_us_hist,
        }
        
        # 下载函数优先级（自动模式下的尝试顺序）
        # 优先使用 tiingo（多token轮询），然后 stock_us_hist，yfinance，最后 STOCK_US_DAILY
        self.priority_order = [
            DownloadProvider.TIINGO.value,
            DownloadProvider.STOCK_US_HIST.value,
            DownloadProvider.YFINANCE.value,
            DownloadProvider.STOCK_US_DAILY.value,
        ]
        self._symbol_map = None
    
    def _download_with_tiingo(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用 Tiingo API 下载美股数据，支持多 token 轮询绕过限制
        
        需要设置环境变量 TIINGO_API_KEYS，格式：token1,token2,token3
        """
        try:
            import requests
        except ImportError:
            raise RuntimeError("requests is not installed. Please install it with: pip install requests")
        
        log.info(f"[tiingo] Starting download for {stock_code}, date range: {start_date} to {end_date}")
        
        # 参数验证
        if not stock_code or not isinstance(stock_code, str):
            raise ValueError(f"Invalid stock_code: {stock_code}")
        if not start_date or not isinstance(start_date, str):
            raise ValueError(f"Invalid start_date: {start_date}")
        if not end_date or not isinstance(end_date, str):
            raise ValueError(f"Invalid end_date: {end_date}")
        
        # 验证日期格式
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            if start_dt > end_dt:
                raise ValueError(f"start_date ({start_date}) must be <= end_date ({end_date})")
        except ValueError as e:
            raise RuntimeError(f"Invalid date format: start_date={start_date}, end_date={end_date}. Error: {e}")
        
        # 获取可用的 token
        token = tiingo_token_manager.get_next_token()
        if not token:
            raise RuntimeError(
                "No Tiingo API tokens available. Please set TIINGO_API_KEYS environment variable "
                "with comma-separated tokens: TIINGO_API_KEYS=token1,token2,token3"
            )
        
        # 获取 token 对应的锁（用于串行访问）
        token_lock = tiingo_token_manager.get_token_lock(token)
        
        # Tiingo API 端点
        base_url = "https://api.tiingo.com/tiingo/daily"
        url = f"{base_url}/{stock_code}/prices"
        
        params = {
            "startDate": start_date,
            "endDate": end_date,
            "format": "json"
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Token {token}"
        }
        
        max_retries = len(tiingo_token_manager.tokens) if tiingo_token_manager.tokens else 1
        last_error = None
        
        for attempt in range(max_retries):
            try:
                with token_lock:
                    response = requests.get(url, params=params, headers=headers, timeout=30)
                
                # 检查响应状态
                if response.status_code == 200:
                    data_list = response.json()
                    if not data_list:
                        error_msg = f"tiingo returned no data for {stock_code}"
                        log.warning(f"[tiingo] {error_msg}")
                        raise RuntimeError(error_msg)
                    
                    # 转换为 DataFrame
                    data = pd.DataFrame(data_list)
                    
                    log.info(f"[tiingo] Received DataFrame with {len(data)} rows, columns: {list(data.columns)}")
                    
                    # Tiingo API 返回：date, open, high, low, close, volume, adjOpen, adjHigh, adjLow, adjClose, adjVolume
                    # 优先用调整后价格（adj*），只选一套列再重命名，避免 open/adjOpen 同时存在导致重复列
                    required_cols = ['date', 'open', 'high', 'low', 'close', 'volume']
                    if "adjOpen" in data.columns and "adjClose" in data.columns:
                        data = data[["date", "adjOpen", "adjHigh", "adjLow", "adjClose", "adjVolume"]].copy()
                        data = data.rename(columns={
                            "adjOpen": "open", "adjHigh": "high", "adjLow": "low",
                            "adjClose": "close", "adjVolume": "volume",
                        })
                    else:
                        missing = [c for c in required_cols if c not in data.columns]
                        if missing:
                            raise RuntimeError(f"tiingo data missing columns: {missing}. Available: {list(data.columns)}")
                        data = data[required_cols].copy()
                    
                    # 转换date列为datetime类型；若为 timezone-aware 则转为 naive，避免与 bounds 比较时报错
                    data['date'] = pd.to_datetime(data['date'])
                    if data['date'].dt.tz is not None:
                        data['date'] = data['date'].dt.tz_localize(None)
                    
                    # 按日期排序
                    data = data.sort_values('date').reset_index(drop=True)
                    
                    # 过滤日期范围（bounds 用 pd.Timestamp 与列类型一致）
                    start_dt = pd.to_datetime(start_date)
                    end_dt = pd.to_datetime(end_date)
                    mask = (data['date'] >= start_dt) & (data['date'] <= end_dt)
                    filtered_data = data[mask]
                    
                    if filtered_data.empty:
                        error_msg = f"tiingo filtered data is empty for {stock_code} with date range {start_date} to {end_date}"
                        log.warning(f"[tiingo] {error_msg}")
                        raise RuntimeError(error_msg)
                    
                    # 标记 token 成功并记录请求
                    tiingo_token_manager.mark_token_success(token)
                    tiingo_token_manager.record_request(token)
                    
                    log.info(f"[tiingo] Download completed successfully: {len(filtered_data)} rows for {stock_code}")
                    return filtered_data
                
                elif response.status_code == 429:
                    # 速率限制，标记 token 错误并尝试下一个
                    error_msg = f"tiingo rate limit exceeded for token {token[:8]}..."
                    log.warning(f"[tiingo] {error_msg}")
                    tiingo_token_manager.mark_token_error(token)
                    last_error = RuntimeError(error_msg)
                    
                    # 尝试下一个 token
                    token = tiingo_token_manager.get_next_token()
                    if not token:
                        raise RuntimeError("All Tiingo tokens have reached rate limit")
                    continue
                
                elif response.status_code == 401:
                    # 认证失败，标记 token 错误
                    error_msg = f"tiingo authentication failed for token {token[:8]}..."
                    log.error(f"[tiingo] {error_msg}")
                    tiingo_token_manager.mark_token_error(token)
                    last_error = RuntimeError(error_msg)
                    
                    # 尝试下一个 token
                    token = tiingo_token_manager.get_next_token()
                    if not token:
                        raise RuntimeError("All Tiingo tokens have authentication errors")
                    continue
                
                else:
                    # 其他错误
                    error_msg = f"tiingo API returned error {response.status_code}: {response.text}"
                    log.error(f"[tiingo] {error_msg}")
                    raise RuntimeError(error_msg)
                    
            except requests.exceptions.RequestException as e:
                error_msg = f"tiingo request failed for {stock_code}: {type(e).__name__}: {e}"
                log.error(f"[tiingo] {error_msg}", exc_info=True)
                tiingo_token_manager.mark_token_error(token)
                last_error = RuntimeError(error_msg)
                
                # 尝试下一个 token
                if attempt < max_retries - 1:
                    token = tiingo_token_manager.get_next_token()
                    if not token:
                        break
                    continue
                else:
                    raise last_error from e
        
        # 所有 token 都失败了
        if last_error:
            raise last_error
        else:
            raise RuntimeError("Failed to download data from Tiingo API after trying all tokens")
    
    def _download_with_yfinance(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用 yfinance 下载美股数据"""
        try:
            import yfinance as yf
        except ImportError:
            raise RuntimeError("yfinance is not installed. Please install it with: pip install yfinance")
        
        log.info(f"[yfinance] Starting download for {stock_code}, date range: {start_date} to {end_date}")
        
        # 参数验证
        if not stock_code or not isinstance(stock_code, str):
            log.error(f"[yfinance] Invalid stock_code: {stock_code} (type: {type(stock_code)})")
            raise ValueError(f"Invalid stock_code: {stock_code}")
        if not start_date or not isinstance(start_date, str):
            log.error(f"[yfinance] Invalid start_date: {start_date} (type: {type(start_date)})")
            raise ValueError(f"Invalid start_date: {start_date}")
        if not end_date or not isinstance(end_date, str):
            log.error(f"[yfinance] Invalid end_date: {end_date} (type: {type(end_date)})")
            raise ValueError(f"Invalid end_date: {end_date}")
        
        # 验证日期范围合理性
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            
            if start_dt > end_dt:
                error_msg = f"start_date ({start_date}) must be <= end_date ({end_date})"
                log.error(f"[yfinance] {error_msg}")
                raise ValueError(error_msg)
        except ValueError as e:
            error_msg = f"Invalid date format for {stock_code}: start_date={start_date}, end_date={end_date}. Error: {e}"
            log.error(f"[yfinance] {error_msg}")
            raise RuntimeError(error_msg)
        
        try:
            ticker = yf.Ticker(stock_code)
            # yfinance 的 end_date 是排他的，需要加1天
            end_dt_plus_one = (datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
            data = ticker.history(start=start_date, end=end_dt_plus_one, auto_adjust=True)
            
            if data is None or data.empty:
                error_msg = f"yfinance returned no data for {stock_code}"
                log.error(f"[yfinance] {error_msg}")
                raise RuntimeError(error_msg)
            
            log.info(f"[yfinance] Received DataFrame with {len(data)} rows, columns: {list(data.columns)}")
            
            # 转换为 DataFrame，统一列名格式
            data = data.reset_index()
            data['Date'] = pd.to_datetime(data['Date']).dt.date
            
            # yfinance 返回的列名可能是 'Open', 'High', 'Low', 'Close', 'Volume'
            # 统一转换为小写列名以保持一致性
            column_mapping = {
                'Open': 'open',
                'High': 'high',
                'Low': 'low',
                'Close': 'close',
                'Volume': 'volume',
                'Date': 'date'
            }
            
            # 重命名列
            for old_col, new_col in column_mapping.items():
                if old_col in data.columns:
                    data = data.rename(columns={old_col: new_col})
            
            # 确保包含所有必需的列
            required_cols = ['date', 'open', 'high', 'low', 'close', 'volume']
            missing_cols = [col for col in required_cols if col not in data.columns]
            if missing_cols:
                error_msg = f"yfinance returned data missing columns: {missing_cols}. Available columns: {list(data.columns)}"
                log.error(f"[yfinance] {error_msg}")
                raise RuntimeError(error_msg)
            
            # 只保留需要的列
            data = data[required_cols]
            
            # 过滤日期范围（yfinance 的 end 是排他的，但我们已经加了1天，所以需要再过滤一次确保精确）
            data['date'] = pd.to_datetime(data['date'])
            start_dt = pd.to_datetime(start_date).normalize()
            end_dt = pd.to_datetime(end_date).normalize() + pd.Timedelta(days=1)
            mask = (data['date'] >= start_dt) & (data['date'] < end_dt)
            data = data.loc[mask]
            
            if data.empty:
                error_msg = f"yfinance filtered data is empty for {stock_code} with date range {start_date} to {end_date}"
                log.warning(f"[yfinance] {error_msg}")
                raise RuntimeError(error_msg)
            
            log.info(f"[yfinance] Download completed successfully: {len(data)} rows for {stock_code}")
            return data
            
        except Exception as e:
            error_msg = f"yfinance download failed for {stock_code}: {type(e).__name__}: {e}"
            log.error(f"[yfinance] {error_msg}", exc_info=True)
            raise RuntimeError(error_msg) from e

    def _get_us_symbol_map(self) -> Dict[str, str]:
        """从 stock_us_spot_em.csv 加载代码映射"""
        if self._symbol_map is not None:
            return self._symbol_map
            
        mapping_file = os.path.join(self.cache_dir, "stock_us_spot_em.csv")
        if not os.path.exists(mapping_file):
            log.warning(f"Mapping file {mapping_file} not found in {self.cache_dir}.")
            self._symbol_map = {}
            return self._symbol_map
        
        try:
            df = pd.read_csv(mapping_file)
            if '代码' not in df.columns:
                log.error(f"Column '代码' not found in {mapping_file}. Available columns: {list(df.columns)}")
                self._symbol_map = {}
                return self._symbol_map
                
            mapping = {}
            for code in df['代码'].dropna():
                code_str = str(code)
                if '.' in code_str:
                    # 格式如 105.AAPL，提取 AAPL
                    symbol = code_str.split('.')[-1]
                    mapping[symbol] = code_str
                else:
                    mapping[code_str] = code_str
            self._symbol_map = mapping
            log.info(f"Loaded {len(mapping)} US symbol mappings from {mapping_file}")
            return self._symbol_map
        except Exception as e:
            log.error(f"Failed to load symbol mapping from {mapping_file}: {e}")
            self._symbol_map = {}
            return self._symbol_map

    def _download_with_stock_us_hist(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用 akshare.stock_us_hist 下载美股数据"""
        symbol_map = self._get_us_symbol_map()
        # 处理可能的 us. 前缀已在 get_k_data 中处理，这里接收到的 stock_code 应该是 AAPL 这种
        full_code = symbol_map.get(stock_code)
        
        if not full_code:
            log.warning(f"[stock_us_hist] Symbol {stock_code} not found in spot map, trying common prefix 105.")
            full_code = f"105.{stock_code}"
            
        log.info(f"[stock_us_hist] Starting download for {full_code} (original: {stock_code}), range: {start_date} to {end_date}")
        
        # akshare.stock_us_hist 需要日期格式为 YYYYMMDD
        start_date_ak = start_date.replace("-", "")
        end_date_ak = end_date.replace("-", "")
        
        try:
            data = ak.stock_us_hist(symbol=full_code, period="daily", start_date=start_date_ak, end_date=end_date_ak, adjust="qfq")
            if data is None or data.empty:
                error_msg = f"stock_us_hist returned no data for {full_code}"
                log.warning(f"[stock_us_hist] {error_msg}")
                raise RuntimeError(error_msg)
            
            log.info(f"[stock_us_hist] Received {len(data)} rows for {full_code}")
            
            # 统一列名
            column_mapping = {
                "日期": "date",
                "开盘": "open",
                "最高": "high",
                "最低": "low",
                "收盘": "close",
                "成交量": "volume",
            }
            
            data = data.rename(columns={old: new for old, new in column_mapping.items() if old in data.columns})
            
            # 确保包含所有必需列
            required_cols = ['date', 'open', 'high', 'low', 'close', 'volume']
            missing_cols = [col for col in required_cols if col not in data.columns]
            if missing_cols:
                error_msg = f"stock_us_hist data missing columns: {missing_cols}"
                log.error(f"[stock_us_hist] {error_msg}")
                raise RuntimeError(error_msg)
                
            data = data[required_cols]
            data['date'] = pd.to_datetime(data['date'])
            
            return data
        except Exception as e:
            error_msg = f"stock_us_hist download failed for {full_code}: {e}"
            log.error(f"[stock_us_hist] {error_msg}")
            raise RuntimeError(error_msg) from e
    
    def _download_with_stock_us_daily(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用stock_us_daily下载数据，需要手动切片日期范围"""
        log.info(f"[stock_us_daily] Starting download for {stock_code}, date range: {start_date} to {end_date}")
        
        # 参数验证
        if not stock_code or not isinstance(stock_code, str):
            log.error(f"[stock_us_daily] Invalid stock_code: {stock_code} (type: {type(stock_code)})")
            raise ValueError(f"Invalid stock_code: {stock_code}")
        if not start_date or not isinstance(start_date, str):
            log.error(f"[stock_us_daily] Invalid start_date: {start_date} (type: {type(start_date)})")
            raise ValueError(f"Invalid start_date: {start_date}")
        if not end_date or not isinstance(end_date, str):
            log.error(f"[stock_us_daily] Invalid end_date: {end_date} (type: {type(end_date)})")
            raise ValueError(f"Invalid end_date: {end_date}")
        
        # 验证日期范围合理性
        try:
            from datetime import datetime
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            
            # 检查结束日期不能是未来日期
            today = datetime.now().date()
            if end_dt.date() > today:
                log.warning(
                    f"[stock_us_daily] End date {end_dt.date()} is in the future. "
                    f"Adjusting to today ({today})"
                )
                end_dt = datetime.combine(today, datetime.min.time())
                end_date = end_dt.strftime("%Y-%m-%d")
            
            if start_dt > end_dt:
                error_msg = f"start_date ({start_date}) must be <= end_date ({end_date})"
                log.error(f"[stock_us_daily] {error_msg}")
                raise ValueError(error_msg)
            
            # 检查日期范围是否过大（超过10年）
            days_diff = (end_dt - start_dt).days
            if days_diff > 3650:  # 10年
                log.warning(
                    f"[stock_us_daily] Date range is very large ({days_diff} days, ~{days_diff/365:.1f} years). "
                    f"This may cause API issues."
                )
            
            log.debug(f"[stock_us_daily] Date range validated: {start_dt.date()} to {end_dt.date()} ({days_diff} days)")
        except ValueError as e:
            # 如果日期格式不对，尝试转换
            try:
                if len(start_date) == 8 and start_date.isdigit():
                    start_date = datetime.strptime(start_date, "%Y%m%d").strftime("%Y-%m-%d")
                    log.debug(f"[stock_us_daily] Converted start_date format: {start_date}")
                if len(end_date) == 8 and end_date.isdigit():
                    end_date = datetime.strptime(end_date, "%Y%m%d").strftime("%Y-%m-%d")
                    log.debug(f"[stock_us_daily] Converted end_date format: {end_date}")
                start_dt = datetime.strptime(start_date, "%Y-%m-%d")
                end_dt = datetime.strptime(end_date, "%Y-%m-%d")
                if start_dt > end_dt:
                    error_msg = f"start_date ({start_date}) must be <= end_date ({end_date})"
                    log.error(f"[stock_us_daily] {error_msg}")
                    raise ValueError(error_msg)
            except ValueError:
                error_msg = f"Invalid date format for {stock_code}: start_date={start_date}, end_date={end_date}. Error: {e}"
                log.error(f"[stock_us_daily] {error_msg}")
                raise RuntimeError(error_msg)
        
        log.info(f"[stock_us_daily] Calling akshare API: symbol={stock_code}, adjust=qfq")
        
        # 调用 akshare API，捕获所有可能的异常
        try:
            import time
            start_time = time.time()
            data = ak.stock_us_daily(symbol=stock_code, adjust="qfq")
            elapsed_time = time.time() - start_time
            log.info(f"[stock_us_daily] API call completed in {elapsed_time:.2f}s for {stock_code}")
        except TypeError as e:
            error_msg = (
                f"stock_us_daily TypeError for {stock_code}: {e}. "
                f"This may indicate an API issue or invalid parameters."
            )
            log.error(error_msg)
            raise RuntimeError(error_msg) from e
        except AttributeError as e:
            error_msg = (
                f"stock_us_daily AttributeError for {stock_code}: {e}. "
                f"This may indicate akshare internal error or API response issue."
            )
            log.error(error_msg)
            raise RuntimeError(error_msg) from e
        except KeyError as e:
            error_msg = (
                f"stock_us_daily KeyError for {stock_code}: {e}. "
                f"This may indicate unexpected API response format."
            )
            log.error(f"[stock_us_daily] {error_msg}", exc_info=True)
            raise RuntimeError(error_msg) from e
        except IndexError as e:
            error_msg = (
                f"stock_us_daily IndexError for {stock_code}: {e}. "
                f"This may indicate empty or malformed API response."
            )
            log.error(f"[stock_us_daily] {error_msg}", exc_info=True)
            raise RuntimeError(error_msg) from e
        except Exception as e:
            error_msg = (
                f"stock_us_daily API call failed for {stock_code}: "
                f"{type(e).__name__}: {e}"
            )
            log.error(f"[stock_us_daily] {error_msg}", exc_info=True)
            raise RuntimeError(error_msg) from e
        
        # 验证返回数据
        log.debug(f"[stock_us_daily] Validating response data for {stock_code}")
        if data is None:
            error_msg = (
                f"stock_us_daily returned None for {stock_code}. "
                f"This may indicate no data available or API issue."
            )
            log.error(f"[stock_us_daily] {error_msg}")
            raise RuntimeError(error_msg)
        
        if not isinstance(data, pd.DataFrame):
            error_msg = (
                f"stock_us_daily returned unexpected type {type(data)} for {stock_code}, "
                f"expected DataFrame. Value: {data}"
            )
            log.error(f"[stock_us_daily] {error_msg}")
            raise RuntimeError(error_msg)
        
        if data.empty:
            error_msg = (
                f"stock_us_daily returned empty DataFrame for {stock_code}. "
                f"This may indicate no data available."
            )
            log.warning(f"[stock_us_daily] {error_msg}")
            raise RuntimeError(error_msg)
        
        log.info(f"[stock_us_daily] Received DataFrame with {len(data)} rows, columns: {list(data.columns)}")
        
        # stock_us_daily 没有时间参数，需手动切片
        log.debug(f"[stock_us_daily] Searching for date column in {len(data.columns)} columns")
        # 尝试多种可能的日期列名
        date_column = None
        for col_name in ['date', 'Date', '日期', 'datetime', 'DateTime']:
            if col_name in data.columns:
                date_column = col_name
                log.info(f"[stock_us_daily] Found date column: '{date_column}'")
                break
        
        if date_column is None:
            # 如果没有找到日期列，检查索引是否是日期类型
            if isinstance(data.index, pd.DatetimeIndex):
                log.info(f"[stock_us_daily] No date column found, using DatetimeIndex for filtering")
                # 确保包含 end_date 当天的所有数据：使用 < end_date + 1 day
                start_dt = pd.to_datetime(start_date).normalize()
                end_dt = pd.to_datetime(end_date).normalize() + pd.Timedelta(days=1)
                mask = (data.index >= start_dt) & (data.index < end_dt)
                data = data.loc[mask]
                log.info(f"[stock_us_daily] Filtered to {len(data)} rows using DatetimeIndex (inclusive of {end_date})")
            else:
                error_msg = (
                    f"stock_us_daily returned data for {stock_code} without date column or DatetimeIndex. "
                    f"Available columns: {list(data.columns)}, Index type: {type(data.index)}"
                )
                log.error(f"[stock_us_daily] {error_msg}")
                raise RuntimeError(error_msg)
        else:
            try:
                log.debug(f"[stock_us_daily] Converting date column '{date_column}' to datetime")
                data[date_column] = pd.to_datetime(data[date_column])
                date_min = data[date_column].min()
                date_max = data[date_column].max()
                log.debug(f"[stock_us_daily] Date range in data: {date_min} to {date_max}")
                
                # 确保包含 end_date 当天的所有数据：使用 < end_date + 1 day
                start_dt = pd.to_datetime(start_date).normalize()
                end_dt = pd.to_datetime(end_date).normalize() + pd.Timedelta(days=1)
                mask = (data[date_column] >= start_dt) & (data[date_column] < end_dt)
                filtered_data = data.loc[mask]
                
                log.debug(f"[stock_us_daily] Filter mask matched {mask.sum()} rows out of {len(data)} total rows")
                
                if filtered_data.empty:
                    error_msg = (
                        f"stock_us_daily filtered data is empty for {stock_code} "
                        f"with date range {start_date} to {end_date}. "
                        f"Original data has {len(data)} rows, date range: "
                        f"{date_min} to {date_max}"
                    )
                    log.warning(f"[stock_us_daily] {error_msg}")
                    raise RuntimeError(error_msg)
                
                data = filtered_data
                log.info(f"[stock_us_daily] Successfully filtered to {len(data)} rows for {stock_code} in date range {start_date} to {end_date}")
            except Exception as e:
                error_msg = (
                    f"Error filtering stock_us_daily data for {stock_code} by date range "
                    f"{start_date} to {end_date}: {type(e).__name__}: {e}"
                )
                log.error(f"[stock_us_daily] {error_msg}", exc_info=True)
                raise RuntimeError(error_msg) from e
        
        log.info(f"[stock_us_daily] Download completed successfully: {len(data)} rows for {stock_code}")
        return data
    


    def _load_failure_cache(self) -> Dict:
        """加载失败记录缓存"""
        if not os.path.exists(self.cache_file):
            return {}
        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log.warning(f"Failed to load failure cache: {e}")
            return {}
    
    def _save_failure_cache(self, cache: Dict):
        """保存失败记录缓存"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache, f)
        except Exception as e:
            log.warning(f"Failed to save failure cache: {e}")
    
    def _record_failure(self, provider: str):
        """记录下载函数失败"""
        cache = self._load_failure_cache()
        now = datetime.now(timezone.utc)
        cache[provider] = {
            'last_failure': now.isoformat(),
            'failure_count': cache.get(provider, {}).get('failure_count', 0) + 1
        }
        self._save_failure_cache(cache)
        log.info(f"Recorded failure for {provider} at {now.isoformat()}")
    
    def _clear_failure(self, provider: str):
        """清除下载函数的失败记录"""
        cache = self._load_failure_cache()
        if provider in cache:
            cache.pop(provider)
            self._save_failure_cache(cache)
            log.info(f"Cleared failure record for {provider}")
    
    def _is_provider_available(self, provider: str) -> bool:
        """检查下载函数是否可用（12小时内未失败）"""
        cache = self._load_failure_cache()
        if provider not in cache:
            return True
        
        failure_info = cache[provider]
        if 'last_failure' not in failure_info:
            return True
        
        try:
            last_failure_str = failure_info['last_failure']
            # 解析ISO格式的datetime字符串，确保是时区感知的
            last_failure = datetime.fromisoformat(last_failure_str)
            # 如果解析出来的是naive datetime，添加UTC时区
            if last_failure.tzinfo is None:
                last_failure = last_failure.replace(tzinfo=timezone.utc)
            
            now = datetime.now(timezone.utc)
            if now - last_failure < self.failure_timeout:
                log.debug(f"{provider} is unavailable (failed {now - last_failure} ago)")
                return False
            else:
                # 超过12小时，清除失败记录
                self._clear_failure(provider)
                return True
        except Exception as e:
            log.warning(f"Error checking provider availability: {e}")
            return True
    
    def download(
        self, 
        stock_code: str,
        start_date: str,
        end_date: str,
        provider: DownloadProvider = DownloadProvider.AUTO
    ) -> Tuple[pd.DataFrame, str]:
        """
        下载美股数据
        
        Args:
            stock_code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            provider: 下载函数提供者，可以是STOCK_US_DAILY或AUTO（自动切换，默认使用STOCK_US_DAILY）
        
        Returns:
            Tuple[DataFrame, str]: (数据, 使用的提供者名称)
        
        Raises:
            RuntimeError: 所有下载函数都失败时抛出
        """
        log.info(f"[USA DownloadManager] Starting download for {stock_code}, date range: {start_date} to {end_date}, provider: {provider.value}")
        
        # 手动指定提供者
        # 手动指定提供者
        if provider != DownloadProvider.AUTO:
            provider_name = provider.value
            log.info(f"[USA DownloadManager] Manual mode: using provider '{provider_name}'")
            
            # 手动指定时，即使提供者之前失败过，也允许强制尝试
            is_available = self._is_provider_available(provider_name)
            if not is_available:
                log.warning(
                    f"[USA DownloadManager] {provider_name} was marked as failed within last 12 hours, "
                    f"but allowing forced retry since provider was manually specified"
                )
            
            try:
                # 限速：持锁/间隔后再发起请求
                with global_pacer.limit(provider_name):
                    log.debug(f"[USA DownloadManager] Calling download function for provider '{provider_name}'")
                    data = self.download_functions[provider_name](stock_code, start_date, end_date)
                
                # 验证返回的数据
                log.debug(f"[USA DownloadManager] Validating downloaded data from '{provider_name}'")
                if data is None:
                    error_msg = f"{provider_name} returned None for {stock_code}"
                    log.error(f"[USA DownloadManager] {error_msg}")
                    raise RuntimeError(error_msg)
                if not isinstance(data, pd.DataFrame):
                    error_msg = (
                        f"{provider_name} returned unexpected type {type(data)} for {stock_code}, "
                        f"expected DataFrame"
                    )
                    log.error(f"[USA DownloadManager] {error_msg}")
                    raise RuntimeError(error_msg)
                
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(f"[USA DownloadManager] Successfully downloaded {stock_code} using {provider_name}: {len(data)} rows")
                return data, provider_name
            except RuntimeError:
                # 重新抛出RuntimeError（这些是我们预期的错误）
                raise
            except Exception as e:
                self._record_failure(provider_name)
                error_msg = f"Failed to download {stock_code} using {provider_name}: {type(e).__name__}: {e}"
                log.error(f"[USA DownloadManager] {error_msg}", exc_info=True)
                raise RuntimeError(error_msg) from e
        
        # 自动切换模式：按优先级尝试可用的下载函数
        log.info(f"[USA DownloadManager] Auto mode: checking available providers")
        available_providers = [
            p for p in self.priority_order 
            if self._is_provider_available(p)
        ]
        
        log.info(f"[USA DownloadManager] Available providers: {available_providers}")
        
        if not available_providers:
            error_msg = (
                f"All download providers are temporarily unavailable "
                f"(failed within last 12 hours). Please try again later."
            )
            log.error(f"[USA DownloadManager] {error_msg}")
            raise RuntimeError(error_msg)
        
        last_error = None
        for idx, provider_name in enumerate(available_providers, 1):
            try:
                # 限速：持锁/间隔后再发起请求，日志在进入 limit 内打以便体现控速
                with global_pacer.limit(provider_name):
                    log.info(f"[USA DownloadManager] Auto mode: calling provider {idx}/{len(available_providers)}: '{provider_name}'")
                    data = self.download_functions[provider_name](stock_code, start_date, end_date)
                
                # 验证返回的数据
                if data is None:
                    raise RuntimeError(f"{provider_name} returned None for {stock_code}")
                if not isinstance(data, pd.DataFrame):
                    raise RuntimeError(
                        f"{provider_name} returned unexpected type {type(data)} for {stock_code}, "
                        f"expected DataFrame"
                    )
                
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(f"[USA DownloadManager] Successfully downloaded {stock_code} using {provider_name} (auto mode): {len(data)} rows")
                return data, provider_name
            except Exception as e:
                # 在自动模式下，所有异常都应该被捕获并继续尝试下一个提供者
                self._record_failure(provider_name)
                last_error = e
                log.warning(
                    f"[USA DownloadManager] Provider '{provider_name}' failed ({idx}/{len(available_providers)}): "
                    f"{type(e).__name__}: {e}. Trying next provider..."
                )
                continue
        
        # 所有提供者都失败
        error_msg = (
            f"All download providers failed for {stock_code}. "
            f"Last error: {last_error}"
        )
        log.error(f"[USA DownloadManager] {error_msg}")
        raise RuntimeError(error_msg)


class USA(OHLC):
    def __init__(self, download_provider: DownloadProvider = DownloadProvider.AUTO):
        """
        初始化USA类
        
        Args:
            download_provider: 下载函数提供者，默认为自动切换模式
        """
        self.download_provider = download_provider
        self.download_manager = USADownloadFunctionManager()
    
    @staticmethod
    def rename(name):
        return name

    def get_k_data(
        self, 
        stock_code: str, 
        start_date: str, 
        end_date: str, 
        period: Period = Period.DAILY,
        download_provider: Optional[DownloadProvider] = None
    ) -> pd.DataFrame:
        """
        获取美股的K线数据
        
        Args:
            stock_code: 美股代码（支持带或不带 us. 前缀，如 "AAPL" 或 "us.AAPL"）
            start_date: 开始日期
            end_date: 结束日期
            period: 周期，目前支持Period.DAILY（日K）和Period.WEEKLY（周K）
            download_provider: 下载函数提供者，如果为None则使用初始化时设置的提供者
        
        Returns:
            DataFrame: OHLC数据
        """
        # 处理股票代码前缀：如果带有 us. 前缀，去掉它
        original_code = stock_code
        if stock_code.startswith("us."):
            stock_code = stock_code.replace("us.", "", 1)
            log.debug(f"[USA.get_k_data] Removed 'us.' prefix: {original_code} -> {stock_code}")
        
        # 目前仅支持日K数据
        # if period != Period.DAILY:
        #     raise NotImplementedError("USA类目前仅支持日K数据获取")
        
        name = self.rename(stock_code)
        df = None
        need_split = True
        pd.set_option('display.float_format', lambda x: '%.3f' % x)

        # 构建缓存文件路径，包含周期信息
        data_file = data_file_path(stock_code, start_date, end_date, period)
        # print(f"缓存文件路径: {data_file}")
        data = None
        if os.path.exists(data_file):
            data = pd.read_csv(data_file)
            # 删除多余的Unnamed: 0列（如果有）
            if 'Unnamed: 0' in data.columns:
                data.drop('Unnamed: 0', axis=1, inplace=True)
            # 确保Date是索引而不是列
            if 'Date' in data.columns:
                data['Date'] = pd.to_datetime(data['Date'])
                data.set_index('Date', inplace=True)
            
            # 数据清洗
            data = clean_ohlc_data(data)
            
            df = data
            return df
        else:
            if period == Period.DAILY:
                # 使用下载函数管理器获取数据
                provider = download_provider if download_provider is not None else self.download_provider
                log.info(f"[USA.get_k_data] Downloading {stock_code} (original: {original_code}) with provider: {provider.value}")
                try:
                    data, data_source = self.download_manager.download(stock_code, start_date, end_date, provider)
                    log.info(f"[USA.get_k_data] Downloaded {len(data)} rows for {stock_code} using {data_source}")
                except RuntimeError as e:
                    log.error(f"[USA.get_k_data] Failed to download USA data for {stock_code}: {e}", exc_info=True)
                    raise
                
                # 验证数据格式
                if data is None or data.empty:
                    raise RuntimeError(f"Downloaded data is empty for {stock_code}")
                
                # 检查必需的列
                required_cols = ['date', 'open', 'high', 'low', 'close', 'volume']
                missing_cols = [col for col in required_cols if col not in data.columns]
                if missing_cols:
                    raise RuntimeError(
                        f"Missing required columns for {stock_code}: {missing_cols}. "
                        f"Available columns: {list(data.columns)}"
                    )

                df = data[required_cols].rename(columns={'date': 'Date'})
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)

            elif period == Period.WEEKLY:
                # 递归调用获取日线数据
                daily_df = self.get_k_data(stock_code, start_date, end_date, period=Period.DAILY)
                # 重置索引，将Date索引转换为Date列
                daily_df = daily_df.reset_index()
                # 生成周线数据
                df = generate_weekly_kdata(daily_df)
            else :
                raise NotImplementedError(f"USA类目前不支持{period}周期数据获取")



        df[['open', 'high', 'low', 'close', 'volume']] = df[['open', 'high', 'low', 'close', 'volume']].astype(float)

        # Ensure 'Date' is the index and not also a column to avoid duplicated 'Date' header
        if 'Date' in df.columns and not isinstance(df.index, pd.DatetimeIndex):
            try:
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
            except Exception:
                df = df.drop(columns=['Date'], errors='ignore')

        if 'Date' in df.columns:
            df = df.drop(columns=['Date'], errors='ignore')

        if not os.path.exists(data_file):
            df.to_csv(data_file, index=True)
            
        # 数据清洗
        df = clean_ohlc_data(df)
            
        # 确保index为DatetimeIndex，且命名为'Date'
        if not isinstance(df.index, pd.DatetimeIndex):
            try:
                df.index = pd.to_datetime(df.index)
            except Exception:
                pass
        df.index.name = 'Date'
        return df
