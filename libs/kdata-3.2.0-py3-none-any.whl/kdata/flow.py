from typing import Optional

def main(argv: Optional[list[str]] = None) -> int:

    # 使用efinance获取主力资金流入前10股票
    import pandas as pd
    import akshare as ak
    import yaml
    # 获取A股主力资金流数据
    df = ak.stock_main_fund_flow(symbol="全部股票")
    # 按资金流入降序排序，取前10
    top10 = df.sort_values(by='主力净流入', ascending=False).head(10)
    codes = top10['股票代码'].tolist()
    # 写入yaml文件
    with open('top10_fund_flow.yaml', 'w', encoding='utf-8') as f:
        yaml.dump({'top10_fund_flow': codes}, f, allow_unicode=True)
    print('已写入top10_fund_flow.yaml')
    return 0

if __name__ == "__main__":
    import sys
    raise SystemExit(main(sys.argv[1:]))