# -*- coding: utf-8 -*-
from datetime import datetime, timedelta


def get_date_string(date: datetime = None):
    # 获取当前日期和时间
    today = date if date else datetime.now()

    # 将当前日期转为字符串（格式为 'YYYY-MM-DD'）
    today_str = today.strftime('%Y-%m%d')
    return today_str.strip()


def get_date_string_v2(date: datetime = None):
    # 获取当前日期和时间
    today = date if date else datetime.now()

    # 将当前日期转为字符串（格式为 'YYYY-MM-DD'）
    today_str = today.strftime('%m%d')
    return today_str.strip()


def get_date_x_days_ago(x: int, date: datetime = None):
    # 获取当前日期和时间
    today = date if date else datetime.now()    

    # 计算x天前的日期
    date_x_days_ago = today - timedelta(days=x)

    # 将日期转为字符串（格式为 'YYYY-MM-DD'）
    date_x_days_ago_str = date_x_days_ago.strftime('%Y-%m-%d')
    return date_x_days_ago_str