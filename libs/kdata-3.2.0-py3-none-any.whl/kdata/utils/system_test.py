import unittest

from .system import get_home_location


class MyTestCase(unittest.TestCase):
    def test_something(self):
        home = get_home_location()
        self.assertEqual(isinstance(home, str), True)  # add assertion here


if __name__ == '__main__':
    unittest.main()
