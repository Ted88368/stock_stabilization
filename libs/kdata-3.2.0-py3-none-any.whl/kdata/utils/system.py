# -*- coding: utf-8 -*-

from pathlib import Path

def get_home_location():
    return Path.home().as_posix()