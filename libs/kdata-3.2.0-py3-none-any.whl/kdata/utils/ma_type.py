from talib import MA_Type


def ma_string(mt : MA_Type) -> str:
    if mt == MA_Type.SMA:
        return "SMA"
    elif mt == MA_Type.EMA:
        return "EMA"
    elif mt == MA_Type.WMA:
        return "WMA"
    else :
        return "unknown"