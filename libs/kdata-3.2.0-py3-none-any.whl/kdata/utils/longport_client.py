# -*- coding: utf-8 -*-
import logging
import os
from threading import Lock
from typing import Optional

log = logging.getLogger(__name__)

try:
    from longport.openapi import Config, QuoteContext
    LONGPORT_AVAILABLE = True
except ImportError:
    LONGPORT_AVAILABLE = False
    log.warning("longport-openapi SDK not installed. LongPort provider will be unavailable.")

class LongPortClient:
    """
    LongPort OpenAPI 客户端管理器 (单例模式)
    """
    _instance = None
    _lock = Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(LongPortClient, cls).__new__(cls)
                cls._instance._ctx = None
                cls._instance._initialized = False
        return cls._instance

    def _init_context(self):
        if self._initialized:
            return

        if not LONGPORT_AVAILABLE:
            raise RuntimeError("longport-openapi SDK is not installed.")

        try:
            # Config.from_env() 会自动读取 LONGPORT_APP_KEY, LONGPORT_APP_SECRET, LONGPORT_ACCESS_TOKEN
            config = Config.from_env()
            self._ctx = QuoteContext(config)
            self._initialized = True
            log.info("LongPort QuoteContext initialized successfully.")
        except Exception as e:
            log.error(f"Failed to initialize LongPort QuoteContext: {e}")
            raise RuntimeError(f"LongPort initialization failed: {e}")

    @property
    def context(self) -> 'QuoteContext':
        if not self._initialized:
            self._init_context()
        return self._ctx

    def close(self):
        if self._ctx:
            # QuoteContext does not have a formal close() in some versions, 
            # but it's good practice to check if it needs cleanup.
            self._ctx = None
            self._initialized = False

longport_client = LongPortClient()
