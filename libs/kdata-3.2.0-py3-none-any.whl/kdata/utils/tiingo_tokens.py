# -*- coding: utf-8 -*-
"""Tiingo API Token Manager for rotating multiple tokens to bypass rate limits."""
import os
import logging
import threading
from typing import List, Optional, Dict
from datetime import datetime, timedelta
from collections import deque

log = logging.getLogger(__name__)


class TiingoTokenManager:
    """
    多 Token 轮询管理器，用于绕过 Tiingo API 的使用限制。
    
    从环境变量 TIINGO_API_KEYS 读取多个 token（逗号分隔），轮询使用。
    适配 Tiingo API 限制：
    - 每小时最多 50 次请求
    - 每天最多 1000 次请求
    
    当某个 token 达到限制时，自动切换到下一个 token。
    """
    _instance = None
    _lock = threading.Lock()
    
    # Tiingo API 限制
    HOURLY_LIMIT = 50  # 每小时最多 50 次请求
    DAILY_LIMIT = 1000  # 每天最多 1000 次请求
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(TiingoTokenManager, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self.tokens: List[str] = []
        self.current_index = 0
        self.token_locks: Dict[str, threading.Lock] = {}
        self.token_last_error: Dict[str, Optional[datetime]] = {}  # 记录每个 token 的最后错误时间
        self.token_request_times: Dict[str, deque] = {}  # 记录每个 token 的请求时间戳（滑动窗口）
        self.error_timeout = timedelta(minutes=5)  # token 错误后5分钟内不再使用
        self._init_tokens()
        self._initialized = True
    
    def _init_tokens(self):
        """从环境变量初始化 tokens"""
        api_keys_str = os.getenv("TIINGO_API_KEYS", "")
        if not api_keys_str:
            log.warning(
                "TIINGO_API_KEYS environment variable not set. "
                "Please set it as comma-separated tokens: TIINGO_API_KEYS=token1,token2,token3"
            )
            return
        
        # 解析逗号分隔的 tokens
        tokens = [token.strip() for token in api_keys_str.split(",") if token.strip()]
        if not tokens:
            log.warning("No valid tokens found in TIINGO_API_KEYS")
            return
        
        self.tokens = tokens
        # 为每个 token 创建锁、错误记录和请求时间队列
        for token in self.tokens:
            self.token_locks[token] = threading.Lock()
            self.token_last_error[token] = None
            self.token_request_times[token] = deque()  # 使用 deque 存储请求时间戳
        
        log.info(
            f"Initialized TiingoTokenManager with {len(self.tokens)} token(s). "
            f"Limits: {self.HOURLY_LIMIT} requests/hour, {self.DAILY_LIMIT} requests/day per token"
        )
    
    def get_next_token(self) -> Optional[str]:
        """
        获取下一个可用的 token（轮询方式）
        
        检查每个 token 的请求限制：
        - 每小时最多 50 次
        - 每天最多 1000 次
        
        Returns:
            可用的 token，如果没有可用 token 则返回 None
        """
        if not self.tokens:
            return None
        
        # 尝试所有 token，找到第一个可用的
        start_index = self.current_index
        attempts = 0
        
        while attempts < len(self.tokens):
            token = self.tokens[self.current_index]
            
            # 检查 token 是否可用（错误冷却期 + 请求限制）
            if self._is_token_available(token):
                # 更新索引为下一个 token
                self.current_index = (self.current_index + 1) % len(self.tokens)
                return token
            
            # 尝试下一个 token
            self.current_index = (self.current_index + 1) % len(self.tokens)
            attempts += 1
        
        # 如果所有 token 都不可用，返回第一个（至少尝试一下）
        log.warning("All tokens have reached rate limits or are in cooldown, using first token anyway")
        return self.tokens[0] if self.tokens else None
    
    def _is_token_available(self, token: str) -> bool:
        """
        检查 token 是否可用
        
        检查项：
        1. 不在错误冷却期
        2. 每小时请求数 < 50
        3. 每天请求数 < 1000
        """
        # 检查错误冷却期
        if token in self.token_last_error:
            last_error = self.token_last_error[token]
            if last_error is not None:
                if datetime.now() - last_error <= self.error_timeout:
                    return False
        
        # 清理过期的请求时间戳（超过24小时）
        self._clean_old_requests(token)
        
        # 检查请求限制
        now = datetime.now()
        hour_ago = now - timedelta(hours=1)
        day_ago = now - timedelta(days=1)
        
        request_times = self.token_request_times.get(token, deque())
        
        # 统计最近1小时的请求数
        hourly_count = sum(1 for req_time in request_times if req_time >= hour_ago)
        if hourly_count >= self.HOURLY_LIMIT:
            log.debug(
                f"Token {token[:8]}... reached hourly limit ({hourly_count}/{self.HOURLY_LIMIT})"
            )
            return False
        
        # 统计最近24小时的请求数
        daily_count = sum(1 for req_time in request_times if req_time >= day_ago)
        if daily_count >= self.DAILY_LIMIT:
            log.debug(
                f"Token {token[:8]}... reached daily limit ({daily_count}/{self.DAILY_LIMIT})"
            )
            return False
        
        return True
    
    def _clean_old_requests(self, token: str):
        """清理超过24小时的请求时间戳"""
        if token not in self.token_request_times:
            return
        
        now = datetime.now()
        day_ago = now - timedelta(days=1)
        request_times = self.token_request_times[token]
        
        # 移除超过24小时的时间戳
        while request_times and request_times[0] < day_ago:
            request_times.popleft()
    
    def mark_token_error(self, token: str):
        """标记 token 出错，进入冷却期"""
        self.token_last_error[token] = datetime.now()
        log.warning(f"Token {token[:8]}... marked as error, will retry after {self.error_timeout}")
    
    def mark_token_success(self, token: str):
        """标记 token 成功使用，清除错误记录"""
        if token in self.token_last_error:
            self.token_last_error[token] = None
        log.debug(f"Token {token[:8]}... marked as success, error record cleared")
    
    def record_request(self, token: str):
        """
        记录 token 的一次请求
        
        在成功请求后调用，用于跟踪请求计数
        """
        if token not in self.token_request_times:
            self.token_request_times[token] = deque()
        
        now = datetime.now()
        self.token_request_times[token].append(now)
        
        # 清理超过24小时的时间戳（保持队列大小合理）
        self._clean_old_requests(token)
        
        # 记录当前统计信息
        hour_ago = now - timedelta(hours=1)
        day_ago = now - timedelta(days=1)
        request_times = self.token_request_times[token]
        hourly_count = sum(1 for req_time in request_times if req_time >= hour_ago)
        daily_count = sum(1 for req_time in request_times if req_time >= day_ago)
        
        log.debug(
            f"Token {token[:8]}... request recorded. "
            f"Hourly: {hourly_count}/{self.HOURLY_LIMIT}, Daily: {daily_count}/{self.DAILY_LIMIT}"
        )
    
    def get_token_lock(self, token: str) -> threading.Lock:
        """获取 token 对应的锁（用于串行访问）"""
        return self.token_locks.get(token, threading.Lock())


# 全局单例实例
tiingo_token_manager = TiingoTokenManager()
