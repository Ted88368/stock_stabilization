# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import logging

def clean_ohlc_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    对OHLC数据进行清洗，确保其满足逻辑约束
    参考: https://mp.weixin.qq.com/s/FXZEge_iMG1snlier-nb9A
    
    逻辑约束:
    1. low <= min(open, close)
    2. high >= max(open, close)
    3. low <= high
    4. volume >= 0
    
    修复策略:
    1. low = min(low, open, close, high)
    2. high = max(high, open, close, low)
    3. 丢弃无法修复的行 (如修复后 low > high 或 volume < 0)
    
    Args:
        df: 包含 open, high, low, close, volume 列的 DataFrame
        
    Returns:
        清洗后的 DataFrame
    """
    if df is None or df.empty:
        return df
    # 避免SettingWithCopyWarning
    df = df.copy()

    # 统一索引为'Date'列，并转为DatetimeIndex
    if 'Date' in df.columns:
        df.loc[:, 'Date'] = pd.to_datetime(df['Date'])
        df.set_index('Date', inplace=True)
    elif df.index.name != 'Date':
        # 如果index不是'Date'，尝试将index转为datetime
        try:
            df.index = pd.to_datetime(df.index)
            df.index.name = 'Date'
        except Exception:
            pass

    cols = ['open', 'high', 'low', 'close', 'volume']
    for col in cols:
        if col not in df.columns:
            logging.warning(f"Dataframe missing column: {col}, skipping cleaning.")
            return df

    # 1. 确保数据类型为 float
    df.loc[:, cols] = df[cols].astype(float)

    # 2. 修复 low
    df.loc[:, 'low'] = df[['low', 'open', 'close', 'high']].min(axis=1)

    # 3. 修复 high
    df.loc[:, 'high'] = df[['high', 'open', 'close', 'low']].max(axis=1)

    # 4. 过滤无法修复的无效数据
    valid_mask = (df['volume'] >= 0) & (df['low'] <= df['high'])

    initial_count = len(df)
    df = df[valid_mask].copy()

    if len(df) < initial_count:
        logging.warning(f"Dropped {initial_count - len(df)} invalid bars during cleaning.")

    # 再次强制索引为'Date'并为DatetimeIndex，防止上游未生效
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'])
        df.set_index('Date', inplace=True)
    elif df.index.name != 'Date':
        try:
            df.index = pd.to_datetime(df.index)
            df.index.name = 'Date'
        except Exception:
            pass
    return df
