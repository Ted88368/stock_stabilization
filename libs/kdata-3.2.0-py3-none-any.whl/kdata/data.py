# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from typing import Optional, Union

import pandas as pd

from .astock import AStock
from .etf import ETF
from .hk import HK
from .usa import USA
from .provider import Period, DownloadProvider

"""
统一的接口，方便用户调用切换不同的数据源
股票编号：规则 为 sh.000300
"""


def get_ohlc(
    stock_code: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    period: Union[Period, str] = Period.DAILY,
    download_provider: Optional[DownloadProvider] = None,
) -> pd.DataFrame:
    """
    获取股票的OHLC数据

    Args:
        stock_code: 股票代码，格式为 sh.000300, sz.000001, hk.00001, us.AAPL 或纯数字代码
        start_date: 开始日期，格式为 'YYYY-MM-DD'
        end_date: 结束日期，格式为 'YYYY-MM-DD'
        period: 周期类型，可以是Period枚举或字符串('d'表示日K，'w'表示周K)
        download_provider: 下载函数提供者 (仅对ETF有效)

    Returns:
        包含OHLC数据的DataFrame
    """
    # 处理周期参数，提供向后兼容
    if isinstance(period, str):
        period_map = {"d": Period.DAILY, "w": Period.WEEKLY}
        if period in period_map:
            period = period_map[period]
        else:
            raise ValueError(
                f"不支持的周期类型: {period}，请使用 'd' (日K) 或 'w' (周K)"
            )

    from .env import get_default_start_date
    if start_date is None:
        start_date = get_default_start_date()
    if end_date is None:
        end_date = datetime.now().strftime("%Y-%m-%d")

    # 时间不是日期格式，转为日期格式
    try:
        datetime.strptime(start_date, "%Y-%m-%d")
    except ValueError:
        # 尝试多种常见格式：20220101、2022-0101、2022-01-01
        try:
            start_date = datetime.strptime(start_date, "%Y%m%d").strftime("%Y-%m-%d")
        except ValueError:
            start_date = datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%d")

    try:
        datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError:
        # 有没有其他格式的可能，比如20251109
        end_date = datetime.strptime(end_date, "%Y%m%d").strftime("%Y-%m-%d")

    if start_date >= "2022-01-01" and end_date < "2025-12-31":
        df = get_ohlc(
            stock_code,
            "2022-01-01",
            "2025-12-31",
            period,
            download_provider=download_provider,
        )
        # Convert Date index to column
        df_with_date = df.reset_index()
        # Filter by Date column using boolean conditions
        filtered_df = df_with_date[
            (df_with_date["Date"] >= start_date) & (df_with_date["Date"] <= end_date)
        ]
        # 清洗并统一索引
        from .utils.cleaner import clean_ohlc_data

        filtered_df = clean_ohlc_data(filtered_df)
        if "Date" in filtered_df.columns:
            filtered_df["Date"] = pd.to_datetime(filtered_df["Date"])
            filtered_df.set_index("Date", inplace=True)
        elif not isinstance(filtered_df.index, pd.DatetimeIndex):
            filtered_df.index = pd.to_datetime(filtered_df.index)
        filtered_df.index.name = "Date"
        return filtered_df

    # 根据股票代码前缀选择对应的实现类
    if stock_code.startswith("hk."):
        code = stock_code.replace("hk.", "")
        return HK().get_k_data(
            code, start_date, end_date, period, download_provider=download_provider
        )
    elif stock_code.startswith("us."):
        code = stock_code.replace("us.", "")
        return USA().get_k_data(
            code, start_date, end_date, period, download_provider=download_provider
        )
    elif stock_code.startswith("sz.") or stock_code.startswith("sh."):
        return AStock().get_k_data(
            stock_code, start_date, end_date, period, download_provider=download_provider
        )
    else:
        return ETF().get_k_data(stock_code, start_date, end_date, period, download_provider=download_provider)
