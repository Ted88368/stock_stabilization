# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod

class IDraw(metaclass=ABCMeta):

    """
    绘制表格，数据来自IData接口
    :param df 数据来自IData接口
    :param out 表示输出的图片地址
    """
    @abstractmethod
    def draw_index(self, df, out, table_tile=None, pos=False):
        pass

    """
    绘制恐慌表格，数据来自IFearOrGreed接口
    :param df 数据来自IFearOrGreed接口
    :param out 表示输出的图片地址
    """
    def draw_fear_or_greed(self, df, out):
        pass
