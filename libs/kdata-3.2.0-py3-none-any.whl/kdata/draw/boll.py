
# -*- coding: utf-8 -*-
import mplfinance as mpf


def create_boll_plot(df):
    """
    返回 Bollinger Bands
    Args:
        df:

    Returns:

    """

    # 使用 make_addplot 添加 Bollinger Bands
    ap_upper = mpf.make_addplot(df['upper_band'], panel=0, color='red', linestyle='--')

    # 中规 60日均线
    ap_middle = mpf.make_addplot(df['middle_band'], panel=0, color='white', linestyle='--')
    ap_lower = mpf.make_addplot(df['lower_band'], panel=0, color='blue', linestyle='--')


    return [ap_upper, ap_middle, ap_lower]

