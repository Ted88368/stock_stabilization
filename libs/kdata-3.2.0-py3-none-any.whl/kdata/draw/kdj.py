# -*- coding: utf-8 -*-
import mplfinance as mpf


def create_kdj_plot(df):
    """
    创建KDJ指标的绘图函数
    """

    # 创建附加图，用于显示 KDJ 指标 在第二个面板（panel=1）中，跟 交易量方一起
    ap_k = mpf.make_addplot(df['K'], panel=1, color='blue', label='K', ylabel = 'KDJ')
    ap_d = mpf.make_addplot(df['D'], panel=1, color='orange', label='D')
    ap_j = mpf.make_addplot(df['J'], panel=1, color='purple', label='J')

    return [ap_k, ap_d, ap_j]

