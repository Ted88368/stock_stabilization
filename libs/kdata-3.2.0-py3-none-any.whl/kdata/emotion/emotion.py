# -*- coding: utf-8 -*-

# 定义枚举
from enum import Enum
import fear_and_greed

# 区分A股和美股
class StockMarkType(Enum):
    A_STOCK = "CHINA"
    US_STOCK = "US"


# 定义接口返回fear_greed_index
class FearGreedIndex:
    def __init__(self, index: int, description: str, timestamp: str):
        self.value = index  # 0-100的整数
        self.description = description # 描述
        self.timestamp = timestamp # 更新时间，格式为YYYY-MM-DD HH:MM:SS

    def __str__(self):
        return f"FearGreedIndex(index={self.value}, description={self.description}, timestamp={self.timestamp})"
    
    def __repr__(self):
        return self.__str__()
    
    def __eq__(self, other):
        if not isinstance(other, FearGreedIndex):
            return False
        return self.value == other.value and self.description == other.description and self.timestamp == other.timestamp
    
    def __hash__(self):
        return hash((self.value, self.description, self.timestamp))
    

def get_fear_greed_index(stock_mark_type: StockMarkType) -> FearGreedIndex:
    """
    获取股票市场的恐惧与贪婪指数

    Args:
        stock_mark_type: 股票市场类型，A股或美股

    Returns:
        FearGreedIndex: 恐惧与贪婪指数对象
    """
    # 模拟获取数据
    if stock_mark_type == StockMarkType.A_STOCK:
        raise ValueError(f"不支持获取A股的恐惧与贪婪指数")
    elif stock_mark_type == StockMarkType.US_STOCK:
        index, description, timestamp = fear_and_greed.get()
    else:
        raise ValueError(f"不支持的股票市场类型: {stock_mark_type}")
    
    return FearGreedIndex(index, description, timestamp)


if __name__ == "__main__":
    # 测试A股
    a_stock_index = get_fear_greed_index(StockMarkType.A_STOCK)
    print(a_stock_index)

    # 测试美股
    us_stock_index = get_fear_greed_index(StockMarkType.US_STOCK)
    print(us_stock_index)