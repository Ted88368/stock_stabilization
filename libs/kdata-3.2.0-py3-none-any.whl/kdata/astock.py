# -*- coding: utf-8 -*-
import logging
import os
import warnings
from typing import Optional, Callable, Dict, Tuple
from enum import Enum
from datetime import datetime, timedelta, timezone
import json

import baostock as bs
import akshare as ak

# 过滤 mootdx 库的 ResourceWarning
warnings.filterwarnings(
    "ignore", message=".*unclosed file.*mootdx.*config.json.*", category=ResourceWarning
)

from mootdx.quotes import Quotes
from mootdx.consts import (
    KLINE_DAILY,
    KLINE_WEEKLY,
    MARKET_SH,
    MARKET_SZ,
)
import atexit
import numpy as np
import pandas as pd
from .env import data_file_path
from .utils.pacing import global_pacer
from .provider import OHLC, Period, DownloadProvider
from .utils.cleaner import clean_ohlc_data

log = logging.getLogger(__name__)

# module-level flag to indicate whether we've logged into baostock in this process
_BS_LOGGED_IN = False





class AStockDownloadFunctionManager:
    """A股下载函数管理器，支持手动和自动切换"""

    def __init__(self, cache_dir: Optional[str] = None):
        """
        初始化下载函数管理器

        Args:
            cache_dir: 缓存目录，用于存储失败记录
        """
        self.cache_dir = cache_dir or os.getenv("K_DATA_CENTER") or "/tmp"
        self.cache_file = os.path.join(
            self.cache_dir, "astock_download_failure_cache.json"
        )
        self.failure_timeout = timedelta(hours=12)

        # 注册下载函数
        self.download_functions: Dict[str, Callable] = {
            DownloadProvider.BAOSTOCK.value: self._download_with_baostock,
            DownloadProvider.AKSHARE.value: self._download_with_akshare,
            DownloadProvider.MOOTDX.value: self._download_with_mootdx,
        }

        # 下载函数优先级（自动模式下的尝试顺序）
        self.priority_order = [
            DownloadProvider.MOOTDX.value,
            DownloadProvider.BAOSTOCK.value,
            DownloadProvider.AKSHARE.value,
        ]

    def _convert_code_for_akshare(self, code: str) -> str:
        """将baostock格式的代码转换为akshare格式"""
        # baostock格式: "sh.000300" 或 "sz.000001"
        # akshare格式: "000300" 或 "000001" (去掉前缀)
        if "." in code:
            return code.split(".")[1]
        return code

    def _download_with_baostock(
        self, code: str, start_date: str, end_date: str
    ) -> pd.DataFrame:
        """使用baostock下载数据"""
        global _BS_LOGGED_IN
        if not _BS_LOGGED_IN:
            lg = bs.login()
            logging.info("baostock login respond error_code: %s", lg.error_code)
            logging.info("baostock login respond error_msg: %s", lg.error_msg)
            if getattr(lg, "error_code", None) != "0":
                raise RuntimeError(
                    f"baostock login failed: {getattr(lg, 'error_msg', lg)}"
                )
            _BS_LOGGED_IN = True

            def _kdata_bs_logout():
                try:
                    bs.logout()
                except Exception:
                    logging.exception("baostock logout failed")
                finally:
                    try:
                        globals()["_BS_LOGGED_IN"] = False
                    except Exception:
                        pass

            atexit.register(_kdata_bs_logout)

        code = AStock.rename(code)
        rs = bs.query_history_k_data_plus(
            code,
            "date,open,high,low,close,volume",
            start_date=start_date,
            end_date=end_date,
            frequency="d",
            adjustflag="2",
        )
        data = rs.get_data()

        if data is None or data.empty:
            raise RuntimeError(f"baostock returned empty data for {code}")

        return data

    def _download_with_akshare(
        self, code: str, start_date: str, end_date: str
    ) -> pd.DataFrame:
        """使用akshare下载数据"""
        # 转换代码格式
        akshare_code = self._convert_code_for_akshare(code)

        # akshare的stock_zh_a_hist需要日期格式为YYYYMMDD
        start_date_ak = start_date.replace("-", "")
        end_date_ak = end_date.replace("-", "")

        # akshare只支持日K数据

        data = ak.stock_zh_a_hist(
            symbol=akshare_code,
            start_date=start_date_ak,
            end_date=end_date_ak,
            adjust="qfq",  # 前复权
        )

        if data is None or data.empty:
            raise RuntimeError(f"akshare returned empty data for {code}")

        # akshare返回的列名可能是中文，需要转换为标准格式
        # 列名映射: 日期->date, 开盘->open, 收盘->close, 最高->high, 最低->low, 成交量->volume
        column_mapping = {
            "日期": "date",
            "开盘": "open",
            "收盘": "close",
            "最高": "high",
            "最低": "low",
            "成交量": "volume",
        }

        # 重命名列
        for old_name, new_name in column_mapping.items():
            if old_name in data.columns:
                data = data.rename(columns={old_name: new_name})

        return data

    def _download_with_mootdx(
        self, code: str, start_date: str, end_date: str
    ) -> pd.DataFrame:
        """使用mootdx下载数据"""
        log.info(f"mootdx download AStock data for {code}")

        # 转换代码格式
        # baostock格式: "sh.000300" 或 "sz.000001"
        # mootdx格式: 纯数字代码 + market参数
        if "." in code:
            code_parts = code.split(".")
            market_prefix = code_parts[0].lower()
            symbol = code_parts[1]
        else:
            # 默认为深市，除非代码以 6, 9 开头
            symbol = code.strip().zfill(6)
            if symbol.startswith("6") or symbol.startswith("9"):
                market_prefix = "sh"
            else:
                market_prefix = "sz"

        # 确定市场代码
        if market_prefix == "sh":
            market = MARKET_SH
        elif market_prefix == "sz":
            market = MARKET_SZ
        else:
            raise ValueError(f"Invalid market prefix: {market_prefix}")

        # 确定频率
        # mootdx的频率：9=日线, 5=周线
        frequency = KLINE_DAILY

        # 创建客户端并获取数据
        client = Quotes.factory(market="std")
        data = client.bars(
            symbol=symbol, frequency=frequency, market=market, start=0, offset=1000
        )

        if data is None or data.empty:
            raise RuntimeError(f"mootdx returned empty data for {code}")

        # 转换列名到标准格式
        # mootdx返回的列名可能是 datetime, open, high, low, close, volume 等
        column_mapping = {
            "datetime": "date",
            "open": "open",
            "high": "high",
            "low": "low",
            "close": "close",
            "volume": "volume",
        }

        for old_name, new_name in column_mapping.items():
            if old_name in data.columns:
                data = data.rename(columns={old_name: new_name})

        # 标准化日期格式：去掉时分秒，只保留日期部分
        if "date" in data.columns:
            data["date"] = pd.to_datetime(data["date"]).dt.normalize()

        # 确保有必要的列
        required_cols = ["date", "open", "high", "low", "close", "volume"]
        for col in required_cols:
            if col not in data.columns:
                raise RuntimeError(f"mootdx data missing required column: {col}")

        return data

    def _load_failure_cache(self) -> Dict:
        """加载失败记录缓存"""
        if not os.path.exists(self.cache_file):
            return {}
        try:
            with open(self.cache_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            log.warning(f"Failed to load failure cache: {e}")
            return {}

    def _save_failure_cache(self, cache: Dict):
        """保存失败记录缓存"""
        try:
            with open(self.cache_file, "w", encoding="utf-8") as f:
                json.dump(cache, f)
        except Exception as e:
            log.warning(f"Failed to save failure cache: {e}")

    def _record_failure(self, provider: str):
        """记录下载函数失败"""
        cache = self._load_failure_cache()
        now = datetime.now(timezone.utc)
        cache[provider] = {
            "last_failure": now.isoformat(),
            "failure_count": cache.get(provider, {}).get("failure_count", 0) + 1,
        }
        self._save_failure_cache(cache)
        log.info(f"Recorded failure for {provider} at {now.isoformat()}")

    def _clear_failure(self, provider: str):
        """清除下载函数的失败记录"""
        cache = self._load_failure_cache()
        if provider in cache:
            cache.pop(provider)
            self._save_failure_cache(cache)
            log.info(f"Cleared failure record for {provider}")

    def _is_provider_available(self, provider: str) -> bool:
        """检查下载函数是否可用（12小时内未失败）"""
        cache = self._load_failure_cache()
        if provider not in cache:
            return True

        failure_info = cache[provider]
        if "last_failure" not in failure_info:
            return True

        try:
            last_failure_str = failure_info["last_failure"]
            # 解析ISO格式的datetime字符串，确保是时区感知的
            last_failure = datetime.fromisoformat(last_failure_str)
            # 如果解析出来的是naive datetime，添加UTC时区
            if last_failure.tzinfo is None:
                last_failure = last_failure.replace(tzinfo=timezone.utc)

            now = datetime.now(timezone.utc)
            if now - last_failure < self.failure_timeout:
                log.debug(
                    f"{provider} is unavailable (failed {now - last_failure} ago)"
                )
                return False
            else:
                # 超过12小时，清除失败记录
                self._clear_failure(provider)
                return True
        except Exception as e:
            log.warning(f"Error checking provider availability: {e}")
            return True

    def download(
        self,
        code: str,
        start_date: str,
        end_date: str,
        provider: DownloadProvider = DownloadProvider.AUTO,
    ) -> Tuple[pd.DataFrame, str]:
        """
        下载A股数据

        Args:
            code: 股票代码（baostock格式: sh.000300 或 sz.000001）
            start_date: 开始日期
            end_date: 结束日期
            provider: 下载函数提供者，可以是BAOSTOCK、AKSHARE或AUTO（自动切换）

        Returns:
            Tuple[DataFrame, str]: (数据, 使用的提供者名称)

        Raises:
            RuntimeError: 所有下载函数都失败时抛出
        """
        # 手动指定提供者
        if provider != DownloadProvider.AUTO:
            provider_name = provider.value
            # 手动指定时，即使提供者之前失败过，也允许强制尝试
            is_available = self._is_provider_available(provider_name)
            if not is_available:
                log.warning(
                    f"{provider_name} was marked as failed within last 12 hours, "
                    f"but allowing forced retry since provider was manually specified"
                )

            try:
                # Use global pacer to handle implementation-specific pacing
                with global_pacer.limit(provider_name):
                    data = self.download_functions[provider_name](
                        code, start_date, end_date
                    )
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(f"Successfully downloaded {code} using {provider_name}")
                return data, provider_name
            except Exception as e:
                self._record_failure(provider_name)
                log.error(f"Failed to download {code} using {provider_name}: {e}")
                raise RuntimeError(
                    f"Failed to download {code} using {provider_name}: {e}"
                )

        # 自动切换模式：按优先级尝试可用的下载函数
        available_providers = [
            p for p in self.priority_order if self._is_provider_available(p)
        ]

        if not available_providers:
            raise RuntimeError(
                f"All download providers are temporarily unavailable "
                f"(failed within last 12 hours). Please try again later."
            )

        last_error = None
        for provider_name in available_providers:
            try:
                # Use global pacer to handle implementation-specific pacing
                with global_pacer.limit(provider_name):
                    data = self.download_functions[provider_name](
                        code, start_date, end_date
                    )
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(
                    f"Successfully downloaded {code} using {provider_name} (auto mode)"
                )
                return data, provider_name
            except Exception as e:
                self._record_failure(provider_name)
                last_error = e
                log.warning(f"Failed to download {code} using {provider_name}: {e}")
                continue

        # 所有提供者都失败
        raise RuntimeError(
            f"All download providers failed for {code}. Last error: {last_error}"
        )


class AStock(OHLC):
    def __init__(
        self, download_provider: DownloadProvider = DownloadProvider.AUTO
    ):
        """
        初始化AStock类

        Args:
            download_provider: 下载函数提供者，默认为自动切换模式
        """
        self.download_provider = download_provider
        self.download_manager = AStockDownloadFunctionManager()

    @staticmethod
    def rename(name):
        return name

    def get_k_data(
        self,
        code: str,
        start: str,
        end: str,
        period: Period = Period.DAILY,
        download_provider: Optional[DownloadProvider] = None,
    ) -> pd.DataFrame:
        """
        获取股票的K线数据

        Args:
            code: 股票代码（baostock格式: sh.000300 或 sz.000001）
            start: 开始日期
            end: 结束日期
            period: 周期，支持Period.DAILY（日K）和Period.WEEKLY（周K）
            download_provider: 下载函数提供者，如果为None则使用初始化时设置的提供者

        Returns:
            DataFrame: OHLC数据
        """
        data_file = data_file_path(code, start, end, period)
        data = None
        # if cached file exists, load and return it (providers should not write files)
        if os.path.exists(data_file):
            data = pd.read_csv(data_file)
            # 删除多余的Unnamed: 0列（如果有）
            if "Unnamed: 0" in data.columns:
                data.drop("Unnamed: 0", axis=1, inplace=True)
            # 确保Date是索引而不是列
            if "Date" in data.columns:
                data["Date"] = pd.to_datetime(data["Date"])
                data.set_index("Date", inplace=True)

            # 数据清洗
            data = clean_ohlc_data(data)

            df = data
            return df
        else:
            if period == Period.DAILY:
                # 使用下载函数管理器获取日K数据
                provider = (
                    download_provider
                    if download_provider is not None
                    else self.download_provider
                )
                try:
                    data, data_source = self.download_manager.download(
                        code, start, end, provider
                    )
                except RuntimeError as e:
                    log.error(f"Failed to download AStock data for {code}: {e}")
                    raise

                # 统一数据格式：采用 ETF 式的 candidates 映射逻辑
                candidates = {
                    "Date": ["日期", "date", "Date"],
                    "open": ["开盘", "open"],
                    "high": ["最高", "high"],
                    "low": ["最低", "low"],
                    "close": ["收盘", "close"],
                    "volume": ["成交量", "成交额", "volume"],
                }

                found = {}
                cols = list(data.columns)
                for key, names in candidates.items():
                    for n in names:
                        if n in cols:
                            found[key] = n
                            break

                required = ["Date", "open", "high", "low", "close"]
                if not all(k in found for k in required):
                    log.warning(
                        "AStock %s: missing required columns, available=%s",
                        code,
                        cols,
                    )
                    empty = pd.DataFrame(
                        columns=["open", "high", "low", "close", "volume"]
                    )
                    empty.index.name = "Date"
                    return empty

                # 构造最终 DataFrame
                use_cols = [
                    found["Date"],
                    found["open"],
                    found["high"],
                    found["low"],
                    found["close"],
                ]
                if "volume" in found:
                    use_cols.append(found["volume"])

                df = data[use_cols].rename(
                    columns={
                        found["Date"]: "Date",
                        found["open"]: "open",
                        found["high"]: "high",
                        found["low"]: "low",
                        found["close"]: "close",
                        found.get("volume"): "volume",
                    }
                )

                df["Date"] = pd.to_datetime(df["Date"])
                df.set_index("Date", inplace=True)

                # 确保在请求的日期范围内
                # 注意：需要标准化日期以包含整个 end_date
                # mootdx 返回的时间戳包含时间部分（如 15:00:00）
                start_dt = pd.to_datetime(start).normalize()
                end_dt = pd.to_datetime(end).normalize() + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
                df = df[start_dt:end_dt]

            elif period == Period.WEEKLY:
                # 周K数据需要先从日K数据生成
                from .kdata_utils import generate_weekly_kdata

                daily_df = self.get_k_data(
                    code,
                    start,
                    end,
                    period=Period.DAILY,
                    download_provider=download_provider,
                )
                # 重置索引，将Date索引转换为Date列
                daily_df = daily_df.reset_index()
                # 生成周线数据
                df = generate_weekly_kdata(daily_df)
            else:
                raise NotImplementedError(f"AStock类目前不支持{period}周期数据获取")

        df[["open", "high", "low", "close", "volume"]] = df[
            ["open", "high", "low", "close", "volume"]
        ].replace("", np.nan)
        df = df.dropna(subset=["open", "high", "low", "close", "volume"])
        df[["open", "high", "low", "close", "volume"]] = df[
            ["open", "high", "low", "close", "volume"]
        ].astype(float)

        if not os.path.exists(data_file):
            df.to_csv(data_file, index=True)

        # 数据清洗
        df = clean_ohlc_data(df)

        # 确保index为DatetimeIndex，且命名为'Date'
        if not isinstance(df.index, pd.DatetimeIndex):
            try:
                df.index = pd.to_datetime(df.index)
            except Exception:
                pass
        df.index.name = "Date"
        return df
