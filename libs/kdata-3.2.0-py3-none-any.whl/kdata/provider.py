# -*- coding: utf-8 -*-
from abc import ABCMeta, abstractmethod
from enum import Enum, auto


class Period(Enum):
    """
    K线周期枚举类
    """

    DAILY = "d"  # 日K
    WEEKLY = "w"  # 周K


class DownloadProvider(Enum):
    """下载函数提供者枚举"""

    # 通用
    AUTO = "auto"  # 自动切换模式
    AKSHARE = "akshare"

    # A股 & ETF
    EFINANCE = "efinance"
    MOOTDX = "mootdx"
    BAOSTOCK = "baostock"

    # 港股
    STOCK_HK_HIST = "stock_hk_hist"
    STOCK_HK_DAILY = "stock_hk_daily"
    FUTU = "futu"  # 富途API，支持港股；当前在 HK 中已禁用，有机会再放开
    LONGPORT = "longport"  # LongPort OpenAPI

    # 美股
    STOCK_US_DAILY = "stock_us_daily"
    STOCK_US_HIST = "stock_us_hist"
    YFINANCE = "yfinance"  # 仅支持美股
    TIINGO = "tiingo"  # Tiingo API，支持多token轮询绕过限制




class OHLC(metaclass=ABCMeta):
    """
    抽象基类：数据提供者接口。
    要求返回 DataFrame，索引为日期，包含列 open, high, low, close, volume。

    参数:
    - period: 周期类型，使用Period枚举（DAILY表示日K，WEEKLY表示周K）
    """

    @abstractmethod
    def get_k_data(self, stock_code, start_date, end_date, period=Period.DAILY):
        pass
