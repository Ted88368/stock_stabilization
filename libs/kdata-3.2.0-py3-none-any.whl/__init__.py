# -*- coding: utf-8 -*-
"""
KData库主包
"""

from . import kdata

# 从kdata包导出所有子包
from .kdata import technical
from .kdata import draw
from .kdata import emotion
from .kdata import utils

__version__ = "2.4.1"

__all__ = ['technical', 'kdata', 'draw', 'emotion', 'utils', '__version__']
