Copyright (c) 2017, Preetam Sharma
All rights reserved.

#TradingPatternScanner

This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) license.

You are free to:

- Share: copy and redistribute the material in any medium or format.

Under the following terms:

- Attribution: You must give appropriate credit, provide a link to the license, and indicate if changes were made. You must do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use. The credit should be given in the following format: "Original work by [Preetam Sharma] is licensed under CC BY-NC-SA 4.0 and can be found at (https://github.com/white07S/TradingPatternScanner)."

- NonCommercial: You may not use the material for commercial purposes. This includes but is not limited to, selling the material, or using it to promote a product or service.


For more information, see the [Creative Commons website](https://creativecommons.org/licenses/by-nc-sa/4.0/) and the [legal code of the license](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).

