import pandas as pd
import numpy as np
from .enum_types import TradingPattern, PivotSignal


def detect_head_shoulder(df, window=3) -> pd.DataFrame:
    """
    检测头肩顶和头肩底形态。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        window (int): 滚动窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'head_shoulder_pattern' 列的 DataFrame。
    """
    # Use local variables for intermediate calculations
    high_roll_max = df['high'].rolling(window=window).max()
    low_roll_min = df['low'].rolling(window=window).min()
    
    # Create masks
    mask_head_shoulder = ((high_roll_max > df['high'].shift(1)) & (high_roll_max > df['high'].shift(-1)) & (df['high'] < df['high'].shift(1)) & (df['high'] < df['high'].shift(-1)))
    mask_inv_head_shoulder = ((low_roll_min < df['low'].shift(1)) & (low_roll_min < df['low'].shift(-1)) & (df['low'] > df['low'].shift(1)) & (df['low'] > df['low'].shift(-1)))
    
    # Create results DataFrame
    new_df = pd.DataFrame(index=df.index)
    # Initialize with None to avoid dtype warnings when assigning strings
    new_df['head_shoulder_pattern'] = None
    new_df.loc[mask_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.HEAD_SHOULDER.value
    new_df.loc[mask_inv_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.INVERSE_HEAD_SHOULDER.value
    return new_df


def detect_multiple_tops_bottoms(df, window=3) -> pd.DataFrame:
    """
    检测多重顶和多重底形态。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low', 'close' 列的 DataFrame。
        window (int): 滚动窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'multiple_top_bottom_pattern' 列 DataFrame。
    """
    # Use local variables
    high_roll_max = df['high'].rolling(window=window).max()
    low_roll_min = df['low'].rolling(window=window).min()
    close_roll_max = df['close'].rolling(window=window).max()
    close_roll_min = df['close'].rolling(window=window).min()
    
    mask_top = (high_roll_max >= df['high'].shift(1)) & (close_roll_max < df['close'].shift(1))
    mask_bottom = (low_roll_min <= df['low'].shift(1)) & (close_roll_min > df['close'].shift(1))
    
    new_df = pd.DataFrame(index=df.index)
    new_df['multiple_top_bottom_pattern'] = None
    new_df.loc[mask_top, 'multiple_top_bottom_pattern'] = TradingPattern.MULTIPLE_TOP.value
    new_df.loc[mask_bottom, 'multiple_top_bottom_pattern'] = TradingPattern.MULTIPLE_BOTTOM.value
    return new_df


def calculate_support_resistance(df, window=3) -> pd.DataFrame:
    """
    根据历史价格的标准差计算支撑位和阻力位。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        window (int): 滚动窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'support' 和 'resistance' 列的 DataFrame。
    """
    std_dev = 2
    mean_high = df['high'].rolling(window=window).mean()
    std_high = df['high'].rolling(window=window).std()
    mean_low = df['low'].rolling(window=window).mean()
    std_low = df['low'].rolling(window=window).std()
    
    new_df = pd.DataFrame(index=df.index)
    new_df['support'] = mean_low - std_dev * std_low
    new_df['resistance'] = mean_high + std_dev * std_high
    return new_df


def detect_triangle_pattern(df, window=3) -> pd.DataFrame:
    """
    检测上升三角形和下降三角形形态。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low', 'close' 列的 DataFrame。
        window (int): 滚动窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'triangle_pattern' 列的 DataFrame。
    """
    high_roll_max = df['high'].rolling(window=window).max()
    low_roll_min = df['low'].rolling(window=window).min()
    
    mask_asc = (high_roll_max >= df['high'].shift(1)) & (low_roll_min <= df['low'].shift(1)) & (df['close'] > df['close'].shift(1))
    mask_desc = (high_roll_max <= df['high'].shift(1)) & (low_roll_min >= df['low'].shift(1)) & (df['close'] < df['close'].shift(1))
    
    new_df = pd.DataFrame(index=df.index)
    new_df['triangle_pattern'] = None
    new_df.loc[mask_asc, 'triangle_pattern'] = TradingPattern.ASCENDING_TRIANGLE.value
    new_df.loc[mask_desc, 'triangle_pattern'] = TradingPattern.DESCENDING_TRIANGLE.value
    return new_df


def detect_wedge(df, window=3) -> pd.DataFrame:
    """
    检测上升楔形和下降楔形形态。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        window (int): 滚动窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'wedge_pattern' 列的 DataFrame。
    """
    high_roll_max = df['high'].rolling(window=window).max()
    low_roll_min = df['low'].rolling(window=window).min()
    trend_high = df['high'].rolling(window=window).apply(lambda x: 1 if (x.iloc[-1]-x.iloc[0])>0 else -1 if (x.iloc[-1]-x.iloc[0])<0 else 0)
    trend_low = df['low'].rolling(window=window).apply(lambda x: 1 if (x.iloc[-1]-x.iloc[0])>0 else -1 if (x.iloc[-1]-x.iloc[0])<0 else 0)
    
    mask_wedge_up = (high_roll_max >= df['high'].shift(1)) & (low_roll_min <= df['low'].shift(1)) & (trend_high == 1) & (trend_low == 1)
    mask_wedge_down = (high_roll_max <= df['high'].shift(1)) & (low_roll_min >= df['low'].shift(1)) & (trend_high == -1) & (trend_low == -1)
    
    new_df = pd.DataFrame(index=df.index)
    new_df['wedge_pattern'] = None
    new_df.loc[mask_wedge_up, 'wedge_pattern'] = TradingPattern.WEDGE_UP.value
    new_df.loc[mask_wedge_down, 'wedge_pattern'] = TradingPattern.WEDGE_DOWN.value
    return new_df


def detect_channel(df, window=3) -> pd.DataFrame:
    """
    检测上升通道和下降通道形态。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        window (int): 滚动窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'channel_pattern' 列的 DataFrame。
    """
    channel_range = 0.1
    high_roll_max = df['high'].rolling(window=window).max()
    low_roll_min = df['low'].rolling(window=window).min()
    trend_high = df['high'].rolling(window=window).apply(lambda x: 1 if (x.iloc[-1]-x.iloc[0])>0 else -1 if (x.iloc[-1]-x.iloc[0])<0 else 0)
    trend_low = df['low'].rolling(window=window).apply(lambda x: 1 if (x.iloc[-1]-x.iloc[0])>0 else -1 if (x.iloc[-1]-x.iloc[0])<0 else 0)
    
    mask_channel_up = (high_roll_max >= df['high'].shift(1)) & (low_roll_min <= df['low'].shift(1)) & (high_roll_max - low_roll_min <= channel_range * (high_roll_max + low_roll_min)/2) & (trend_high == 1) & (trend_low == 1)
    mask_channel_down = (high_roll_max <= df['high'].shift(1)) & (low_roll_min >= df['low'].shift(1)) & (high_roll_max - low_roll_min <= channel_range * (high_roll_max + low_roll_min)/2) & (trend_high == -1) & (trend_low == -1)
    
    new_df = pd.DataFrame(index=df.index)
    new_df['channel_pattern'] = None
    new_df.loc[mask_channel_up, 'channel_pattern'] = TradingPattern.CHANNEL_UP.value
    new_df.loc[mask_channel_down, 'channel_pattern'] = TradingPattern.CHANNEL_DOWN.value
    return new_df


def detect_double_top_bottom(df, window=3, threshold=0.05) -> pd.DataFrame:
    """
    检测双顶和双底形态。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        window (int): 滚动窗口大小。
        threshold (float): 判定双峰/双谷价格接近的阈值。
        
    Returns:
        pd.DataFrame: 包含 'double_pattern' 列的 DataFrame。
    """
    high_roll_max = df['high'].rolling(window=window).max()
    low_roll_min = df['low'].rolling(window=window).min()
    
    mask_double_top = (high_roll_max >= df['high'].shift(1)) & (high_roll_max >= df['high'].shift(-1)) & (df['high'] < df['high'].shift(1)) & (df['high'] < df['high'].shift(-1)) & ((df['high'].shift(1) - df['low'].shift(1)) <= threshold * (df['high'].shift(1) + df['low'].shift(1))/2) & ((df['high'].shift(-1) - df['low'].shift(-1)) <= threshold * (df['high'].shift(-1) + df['low'].shift(-1))/2)
    mask_double_bottom = (low_roll_min <= df['low'].shift(1)) & (low_roll_min <= df['low'].shift(-1)) & (df['low'] > df['low'].shift(1)) & (df['low'] > df['low'].shift(-1)) & ((df['high'].shift(1) - df['low'].shift(1)) <= threshold * (df['high'].shift(1) + df['low'].shift(1))/2) & ((df['high'].shift(-1) - df['low'].shift(-1)) <= threshold * (df['high'].shift(-1) + df['low'].shift(-1))/2)
    
    new_df = pd.DataFrame(index=df.index)
    new_df['double_pattern'] = None
    new_df.loc[mask_double_top, 'double_pattern'] = TradingPattern.DOUBLE_TOP.value
    new_df.loc[mask_double_bottom, 'double_pattern'] = TradingPattern.DOUBLE_BOTTOM.value
    return new_df


def detect_trendline(df, window=2) -> pd.DataFrame:
    """
    使用最小二乘法检测趋势线（支撑位和阻力位）。
    
    Args:
        df (pd.DataFrame): 包含 'close' 列的 DataFrame。
        window (int): 计算斜率的回滚窗口大小。
        
    Returns:
        pd.DataFrame: 包含 'support' 和 'resistance' 列的 DataFrame。
    """
    slopes = np.full(len(df), np.nan)
    intercepts = np.full(len(df), np.nan)
    
    for i in range(window, len(df)):
        x = np.array(range(i-window, i))
        y = df['close'].iloc[i-window:i]
        A = np.vstack([x, np.ones(len(x))]).T
        m, c = np.linalg.lstsq(A, y, rcond=None)[0]
        slopes[i] = m
        intercepts[i] = c
    
    slopes_s = pd.Series(slopes, index=df.index)
    intercepts_s = pd.Series(intercepts, index=df.index)
    
    mask_support = slopes_s > 0
    mask_resistance = slopes_s < 0
    
    new_df = pd.DataFrame(index=df.index)
    new_df['support'] = np.nan
    new_df['resistance'] = np.nan
    
    # We need to align index for calculation
    new_df.loc[mask_support, 'support'] = df['close'] * slopes_s + intercepts_s
    new_df.loc[mask_resistance, 'resistance'] = df['close'] * slopes_s + intercepts_s
    return new_df


def find_pivots(df) -> pd.DataFrame:
    """
    识别价格枢轴点（HH, LL, LH, HL）。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        
    Returns:
        pd.DataFrame: 包含 'signal' 列的 DataFrame。
    """
    high_diffs = df['high'].diff()
    low_diffs = df['low'].diff()

    higher_high_mask = (high_diffs > 0) & (high_diffs.shift(-1) < 0)
    lower_low_mask = (low_diffs < 0) & (low_diffs.shift(-1) > 0)
    lower_high_mask = (high_diffs < 0) & (high_diffs.shift(-1) > 0)
    higher_low_mask = (low_diffs > 0) & (low_diffs.shift(-1) < 0)

    new_df = pd.DataFrame(index=df.index)
    new_df['signal'] = PivotSignal.EMPTY.value
    new_df.loc[higher_high_mask, 'signal'] = PivotSignal.HH.value
    new_df.loc[lower_low_mask, 'signal'] = PivotSignal.LL.value
    new_df.loc[lower_high_mask, 'signal'] = PivotSignal.LH.value
    new_df.loc[higher_low_mask, 'signal'] = PivotSignal.HL.value
    return new_df


def detect_bull_flag(df, window=10, flag_window=5) -> pd.DataFrame:
    """
    检测上涨旗形形态 - 看涨延续形态。
    特征是强劲上涨后接一个下降通道的盘整。
    
    Args:
        df (pd.DataFrame): 包含 'close', 'high', 'low', 'volume' 列的 DataFrame。
        window (int): 计算前期趋势强度的窗口。
        flag_window (int): 计算旗部盘整的窗口。
        
    Returns:
        pd.DataFrame: 包含 'bull_flag_pattern' 列的 DataFrame。
    """
    # Calculate prior trend strength
    close_change = df['close'].pct_change(window)
    
    # Check for prior uptrend (at least 5% gain)
    prior_uptrend = close_change > 0.05
    
    # Calculate flag consolidation (lower highs and lower lows in flag_window)
    high_trend = df['high'].rolling(window=flag_window).apply(
        lambda x: 1 if len(x) >= 2 and x.iloc[-1] < x.iloc[0] else 0
    )
    low_trend = df['low'].rolling(window=flag_window).apply(
        lambda x: 1 if len(x) >= 2 and x.iloc[-1] < x.iloc[0] else 0
    )
    
    # Volume should decrease during consolidation
    volume_decreasing = df['volume'].rolling(window=flag_window).apply(
        lambda x: 1 if len(x) >= 2 and x.iloc[-1] < x.iloc[0] else 0
    )
    
    mask_bull_flag = prior_uptrend & (high_trend == 1) & (low_trend == 1) & (volume_decreasing == 1)
    
    new_df = pd.DataFrame(index=df.index)
    new_df['bull_flag_pattern'] = None
    new_df.loc[mask_bull_flag, 'bull_flag_pattern'] = TradingPattern.BULL_FLAG.value
    return new_df


def detect_cup_and_handle(df, window=20, handle_window=5) -> pd.DataFrame:
    """
    检测杯柄形态 - 看涨延续形态。
    U型恢复后接一个小幅盘整（柄部）。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low', 'close' 列的 DataFrame。
        window (int): 检测杯身的窗口。
        handle_window (int): 检测柄部的窗口。
        
    Returns:
        pd.DataFrame: 包含 'cup_and_handle_pattern' 列的 DataFrame。
    """
    # Find the cup bottom (lowest point in window)
    rolling_min = df['low'].rolling(window=window).min()
    rolling_max = df['high'].rolling(window=window).max()
    
    # Cup depth should be significant (at least 10% from high to low)
    cup_depth = (rolling_max - rolling_min) / rolling_max
    significant_cup = cup_depth > 0.10
    
    # Current price should be recovering (in upper half of cup)
    recovery = (df['close'] - rolling_min) / (rolling_max - rolling_min)
    in_recovery = recovery > 0.7
    
    # Handle: small pullback after recovery
    handle_high = df['high'].rolling(window=handle_window).max()
    handle_low = df['low'].rolling(window=handle_window).min()
    handle_depth = (handle_high - handle_low) / handle_high
    small_handle = (handle_depth > 0.02) & (handle_depth < 0.15)
    
    mask_cup_handle = significant_cup & in_recovery & small_handle
    
    new_df = pd.DataFrame(index=df.index)
    new_df['cup_and_handle_pattern'] = None
    new_df.loc[mask_cup_handle, 'cup_and_handle_pattern'] = TradingPattern.CUP_AND_HANDLE.value
    return new_df


def detect_rounding_bottom(df, window=20) -> pd.DataFrame:
    """
    检测圆弧底形态 - 看涨反转形态。
    价格逐渐呈U型恢复，从下跌到回升的曲线平滑。
    
    Args:
        df (pd.DataFrame): 包含 'close', 'high', 'low', 'volume' 列的 DataFrame。
        window (int): 检测圆弧的窗口。
        
    Returns:
        pd.DataFrame: 包含 'rounding_bottom_pattern' 列的 DataFrame。
    """
    # Calculate rolling statistics
    rolling_mean = df['close'].rolling(window=window).mean()
    rolling_std = df['close'].rolling(window=window).std()
    
    # Find the lowest point in the window
    rolling_min = df['low'].rolling(window=window).min()
    rolling_max = df['high'].rolling(window=window).max()
    
    # Check if current price is near the rolling mean (indicates smooth curve)
    near_mean = np.abs(df['close'] - rolling_mean) < rolling_std
    
    # Price should be recovering from the low
    recovery_ratio = (df['close'] - rolling_min) / (rolling_max - rolling_min)
    recovering = (recovery_ratio > 0.3) & (recovery_ratio < 0.8)
    
    # Volume should increase on the right side (recovery phase)
    volume_trend = df['volume'].rolling(window=window//2).mean()
    volume_increasing = df['volume'] > volume_trend
    
    mask_rounding_bottom = near_mean & recovering & volume_increasing
    
    new_df = pd.DataFrame(index=df.index)
    new_df['rounding_bottom_pattern'] = None
    new_df.loc[mask_rounding_bottom, 'rounding_bottom_pattern'] = TradingPattern.ROUNDING_BOTTOM.value
    return new_df


def detect_symmetrical_triangle(df, window=10) -> pd.DataFrame:
    """
    检测对称三角形形态 - 具有突破潜力的盘整形态。
    趋势线汇聚，表现为更高的高点和更低的低点。
    
    Args:
        df (pd.DataFrame): 包含 'high', 'low' 列的 DataFrame。
        window (int): 检测三角形收敛的窗口。
        
    Returns:
        pd.DataFrame: 包含 'symmetrical_triangle_pattern' 列的 DataFrame。
    """
    # Calculate trends for highs and lows
    high_trend = df['high'].rolling(window=window).apply(
        lambda x: (x.iloc[-1] - x.iloc[0]) / window if len(x) >= 2 else 0
    )
    low_trend = df['low'].rolling(window=window).apply(
        lambda x: (x.iloc[-1] - x.iloc[0]) / window if len(x) >= 2 else 0
    )
    
    # Symmetrical triangle: highs trending down, lows trending up
    highs_declining = high_trend < 0
    lows_rising = low_trend > 0
    
    # The slopes should be similar in magnitude (symmetrical)
    slope_ratio = np.abs(high_trend / (low_trend + 1e-10))  # Avoid division by zero
    symmetrical = (slope_ratio > 0.5) & (slope_ratio < 2.0)
    
    # Price range should be narrowing
    price_range = df['high'] - df['low']
    range_narrowing = price_range < price_range.rolling(window=window).mean()
    
    mask_symmetrical = highs_declining & lows_rising & symmetrical & range_narrowing
    
    new_df = pd.DataFrame(index=df.index)
    new_df['symmetrical_triangle_pattern'] = None
    new_df.loc[mask_symmetrical, 'symmetrical_triangle_pattern'] = TradingPattern.SYMMETRICAL_TRIANGLE.value
    return new_df