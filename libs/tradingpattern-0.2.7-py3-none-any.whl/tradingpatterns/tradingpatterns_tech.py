from scipy.signal import savgol_filter
import numpy as np
import pandas as pd
from pykalman import KalmanFilter
import pywt
from .enum_types import TradingPattern


def detect_head_shoulder(df, window=3) -> pd.DataFrame:
    """
    detect_head_shoulder implements a basic detection of the "Head and Shoulder" and "Inverse Head and Shoulder" patterns 
    in a data frame.
    """
    new_df = pd.DataFrame(index=df.index)
    # Define the rolling window
    roll_window = window
    # Create a rolling window for High and Low
    high_roll_max = df['high'].rolling(window=roll_window).max()
    low_roll_min = df['low'].rolling(window=roll_window).min()
    # Create a boolean mask for Head and Shoulder pattern
    mask_head_shoulder = ((high_roll_max > df['high'].shift(1)) & (high_roll_max > df['high'].shift(-1)) & (df['high'] < df['high'].shift(1)) & (df['high'] < df['high'].shift(-1)))
    # Create a boolean mask for Inverse Head and Shoulder pattern
    mask_inv_head_shoulder = ((low_roll_min < df['low'].shift(1)) & (low_roll_min < df['low'].shift(-1)) & (df['low'] > df['low'].shift(1)) & (df['low'] > df['low'].shift(-1)))
    
    # Create a new column for Head and Shoulder and its inverse pattern and populate it using the boolean masks
    new_df['head_shoulder_pattern'] = None

    # Head and Shoulder 看跌反转形态​
    new_df.loc[mask_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.HEAD_SHOULDER.value
    # Inverse Head and Shoulder 看涨反转形态
    new_df.loc[mask_inv_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.INVERSE_HEAD_SHOULDER.value
    return new_df 

def detect_head_shoulder_filter(df, window=3, threshold=0.01, time_delay=1) -> pd.DataFrame:
    new_df = pd.DataFrame(index=df.index)
    roll_window = window
    high_smooth = savgol_filter(df['high'], roll_window, 2) # Apply Savitzky-Golay filter
    low_smooth = savgol_filter(df['low'], roll_window, 2)
    
    high_roll_max = pd.Series(high_smooth, index=df.index).rolling(window=roll_window).max()
    low_roll_min = pd.Series(low_smooth, index=df.index).rolling(window=roll_window).min()
    
    # Define the height of the head and inverse head
    head_height = high_roll_max - low_roll_min
    inv_head_height = high_roll_max - low_roll_min
    
    # Define the masks for head and shoulder and inverse head and shoulder
    high_smooth_s = pd.Series(high_smooth, index=df.index)
    low_smooth_s = pd.Series(low_smooth, index=df.index)
    
    mask_head_shoulder = ((head_height > threshold) & (high_roll_max > high_smooth_s.shift(time_delay)) & (high_roll_max > high_smooth_s.shift(-time_delay)) & (high_smooth_s < high_smooth_s.shift(time_delay)) & (high_smooth_s < high_smooth_s.shift(-time_delay)))
    mask_inv_head_shoulder = ((inv_head_height > threshold) & (low_roll_min < low_smooth_s.shift(time_delay)) & (low_roll_min < low_smooth_s.shift(-time_delay)) & (low_smooth_s > low_smooth_s.shift(time_delay)) & (low_smooth_s > low_smooth_s.shift(-time_delay)))
    
    new_df['head_shoulder_pattern'] = None
    new_df.loc[mask_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.HEAD_SHOULDER.value
    new_df.loc[mask_inv_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.INVERSE_HEAD_SHOULDER.value

    return new_df

def kalman_smooth(series, n_iter=10):
    # Initialize Kalman filter
    kf = KalmanFilter(initial_state_mean=0, n_dim_obs=1)
    # Use the EM algorithm to estimate the best values for the parameters
    kf = kf.em(series, n_iter=n_iter)
    # Use the observed values of the price to get a rolling mean
    state_means, _ = kf.filter(series.values)
    return state_means.flatten()

def detect_head_shoulder_kf(df, window=3) -> pd.DataFrame:
    new_df = pd.DataFrame(index=df.index)
    roll_window = window
    high_smooth = pd.Series(kalman_smooth(df['high']), index=df.index)
    low_smooth = pd.Series(kalman_smooth(df['low']), index=df.index)
    
    high_roll_max = high_smooth.rolling(window=roll_window).max()
    low_roll_min = low_smooth.rolling(window=roll_window).min()
    
    mask_head_shoulder = ((high_roll_max > high_smooth.shift(1)) & (high_roll_max > high_smooth.shift(-1)) & (high_smooth < high_smooth.shift(1)) & (high_smooth < high_smooth.shift(-1)))
    mask_inv_head_shoulder = ((low_roll_min < low_smooth.shift(1)) & (low_roll_min < low_smooth.shift(-1)) & (low_smooth > low_smooth.shift(1)) & (low_smooth > low_smooth.shift(-1)))
    
    new_df['head_shoulder_pattern'] = None
    new_df.loc[mask_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.HEAD_SHOULDER.value
    new_df.loc[mask_inv_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.INVERSE_HEAD_SHOULDER.value
    
    return new_df

def wavelet_denoise(series, wavelet='db1', level=1):
    # Perform wavelet decomposition
    coeff = pywt.wavedec(series, wavelet, mode="per")
    # Set detail coefficients for levels > level to zero
    for i in range(1, len(coeff)):
        coeff[i] = pywt.threshold(coeff[i], value=np.std(coeff[i])/2, mode="soft")
    # Perform inverse wavelet transform
    return pywt.waverec(coeff, wavelet, mode="per")

def detect_head_shoulder_wavelet(df, window=3) -> pd.DataFrame:
    new_df = pd.DataFrame(index=df.index)
    roll_window = window
    high_smooth = pd.Series(wavelet_denoise(df['high'], 'db1', level=1), index=df.index)
    low_smooth = pd.Series(wavelet_denoise(df['low'], 'db1', level=1), index=df.index)
    
    high_roll_max = high_smooth.rolling(window=roll_window).max()
    low_roll_min = low_smooth.rolling(window=roll_window).min()
    
    mask_head_shoulder = ((high_roll_max > high_smooth.shift(1)) & (high_roll_max > high_smooth.shift(-1)) & (high_smooth < high_smooth.shift(1)) & (high_smooth < high_smooth.shift(-1)))
    mask_inv_head_shoulder = ((low_roll_min < low_smooth.shift(1)) & (low_roll_min < low_smooth.shift(-1)) & (low_smooth > low_smooth.shift(1)) & (low_smooth > low_smooth.shift(-1)))
    
    new_df['head_shoulder_pattern'] = None
    new_df.loc[mask_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.HEAD_SHOULDER.value
    new_df.loc[mask_inv_head_shoulder, 'head_shoulder_pattern'] = TradingPattern.INVERSE_HEAD_SHOULDER.value
    
    return new_df
