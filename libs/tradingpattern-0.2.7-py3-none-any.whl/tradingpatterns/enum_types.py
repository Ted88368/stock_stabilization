from enum import Enum

class TradingPattern(Enum):
    HEAD_SHOULDER = "Head and Shoulder(头肩顶 - 看跌反转)"           
    INVERSE_HEAD_SHOULDER = "Inverse Head and Shoulder(头肩底 - 看涨反转)" 
    MULTIPLE_TOP = "Multiple Top(多重顶 - 看跌反转)"                 
    MULTIPLE_BOTTOM = "Multiple Bottom(多重底 - 看涨反转)"           
    ASCENDING_TRIANGLE = "Ascending Triangle(上升三角形 - 通常看涨)"     
    DESCENDING_TRIANGLE = "Descending Triangle(下降三角形 - 通常看跌)"   
    WEDGE_UP = "Wedge Up(上升楔形 - 看跌)"                         
    WEDGE_DOWN = "Wedge Down(下降楔形 - 看涨)"                     
    CHANNEL_UP = "Channel Up(上升通道 - 看涨趋势)"                     
    CHANNEL_DOWN = "Channel Down(下降通道 - 看跌趋势)"                 
    DOUBLE_TOP = "Double Top(双顶 - 看跌反转)"                     
    DOUBLE_BOTTOM = "Double Bottom(双底 - 看涨反转)"               
    BULL_FLAG = "Bull Flag(上涨旗形 - 看涨延续)"
    CUP_AND_HANDLE = "Cup and Handle(杯柄形态 - 看涨延续)"
    ROUNDING_BOTTOM = "Rounding Bottom(圆弧底 - 看涨反转)"
    SYMMETRICAL_TRIANGLE = "Symmetrical Triangle(对称三角形 - 突破方向待定)"
    NO_PATTERN = "No Pattern(无形态)"                     

    @classmethod
    def get_bullish_patterns(cls) -> list:
        """获取所有看涨形态"""
        return [
            cls.INVERSE_HEAD_SHOULDER,
            cls.MULTIPLE_BOTTOM,
            cls.ASCENDING_TRIANGLE,
            cls.WEDGE_DOWN,
            cls.CHANNEL_UP,
            cls.DOUBLE_BOTTOM,
            cls.BULL_FLAG,
            cls.CUP_AND_HANDLE,
            cls.ROUNDING_BOTTOM,
            cls.SYMMETRICAL_TRIANGLE
        ]

    @classmethod
    def get_bearish_patterns(cls) -> list:
        """获取所有看跌形态"""
        return [
            cls.HEAD_SHOULDER,
            cls.MULTIPLE_TOP,
            cls.DESCENDING_TRIANGLE,
            cls.WEDGE_UP,
            cls.CHANNEL_DOWN,
            cls.DOUBLE_TOP
        ]

    @classmethod
    def all_patterns(cls) -> list:
        """获取所有已定义的形态"""
        return [p for p in cls if p != cls.NO_PATTERN]

class PivotSignal(Enum):
    HH = "HH"  # Higher High
    LL = "LL"  # Lower Low
    LH = "LH"  # Lower High
    HL = "HL"  # Higher Low
    EMPTY = ""
