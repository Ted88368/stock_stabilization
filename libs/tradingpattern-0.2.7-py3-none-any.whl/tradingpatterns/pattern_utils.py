import pandas as pd
from .enum_types import TradingPattern
from .tradingpatterns import (
    detect_head_shoulder, detect_multiple_tops_bottoms,
    detect_triangle_pattern, detect_wedge, detect_channel,
    detect_double_top_bottom, detect_trendline,
    detect_bull_flag, detect_cup_and_handle,
    detect_rounding_bottom, detect_symmetrical_triangle
)

def _get_patterns_by_type(
    df: pd.DataFrame, 
    n: int,
    target_values: list,
    enable_confirmation: bool = False,
    min_strength: int = 2
) -> list:
    """内部通用函数，用于查找指定类型的形态"""
    # 限制数据量：仅取最近的 n 天 + 指标稳定所需的缓冲区 (如 EMA 200 需要 200+ 天)
    # 使用 300 作为缓冲区足以覆盖本项目的所有指标
    lookback_buffer = 300
    total_needed = n + lookback_buffer
    
    if len(df) > total_needed:
        df_work = df.tail(total_needed).copy()
    else:
        df_work = df.copy()
    
    # 确保 'date' 是一个列
    has_date_col = any(col.lower() == 'date' for col in df_work.columns)
    if not has_date_col:
        if isinstance(df_work.index, pd.DatetimeIndex) or (df_work.index.name and 'date' in df_work.index.name.lower()):
            df_work = df_work.reset_index()
            if df_work.columns[0].lower() != 'date':
                df_work.rename(columns={df_work.columns[0]: 'date'}, inplace=True)
            df_work.columns = [c.lower() if c.lower() == 'date' else c for c in df_work.columns]
    
    # 定义所有检测逻辑 (包含看涨和看跌)
    detection_jobs = [
        detect_head_shoulder,
        detect_multiple_tops_bottoms,
        detect_triangle_pattern,
        detect_wedge,
        detect_channel,
        detect_double_top_bottom,
        detect_trendline,
        detect_bull_flag,
        detect_cup_and_handle,
        detect_rounding_bottom,
        detect_symmetrical_triangle
    ]
    
    # 运行所有模式检测
    for func in detection_jobs:
        try:
            res_df = func(df_work)
            new_cols = res_df.columns.difference(df_work.columns)
            if not new_cols.empty:
                df_work = pd.concat([df_work, res_df[new_cols]], axis=1)
        except Exception:
            pass
    
    pattern_cols = [col for col in df_work.columns if col.endswith('_pattern')]
    if not pattern_cols:
        return []
    
    # 获取最后 n 行数据
    recent_df = df_work.tail(n)
    found_patterns = []
    
    for idx, row in recent_df.iterrows():
        date_col = next((col for col in row.index if col.lower() == 'date'), None)
        current_date_raw = row[date_col] if date_col else idx
        
        if hasattr(current_date_raw, 'strftime'):
            current_date = current_date_raw.strftime('%Y-%m-%d')
        else:
            current_date = str(current_date_raw)
        
        for col in pattern_cols:
            val = row[col]
            if pd.notna(val) and (target_values is None or val in target_values):
                found_patterns.append({
                    'date': current_date,
                    'pattern': val
                })
    
    # 如果启用确认
    if enable_confirmation and found_patterns:
        from .pattern_confirmation import enhance_pattern_detection, filter_confirmed_patterns
        enhanced = enhance_pattern_detection(df_work, found_patterns)
        if min_strength > 0:
            enhanced = filter_confirmed_patterns(enhanced, min_strength=min_strength)
        return enhanced
    
    return found_patterns


def get_recent_bullish_patterns(df: pd.DataFrame, n: int, **kwargs) -> list:
    """获取最近的看涨形态"""
    bullish_values = [p.value for p in TradingPattern.get_bullish_patterns()]
    return _get_patterns_by_type(df, n, bullish_values, **kwargs)


def get_recent_bearish_patterns(df: pd.DataFrame, n: int, **kwargs) -> list:
    """获取最近的看跌形态"""
    bearish_values = [p.value for p in TradingPattern.get_bearish_patterns()]
    return _get_patterns_by_type(df, n, bearish_values, **kwargs)


def get_recent_patterns(df: pd.DataFrame, n: int, **kwargs) -> list:
    """获取所有最近的形态 (看涨和看跌)"""
    return _get_patterns_by_type(df, n, None, **kwargs)
