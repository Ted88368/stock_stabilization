"""
技术指标计算模块
用于增强形态识别的确认信号
"""
import pandas as pd
import numpy as np


def calculate_rsi(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """
    计算相对强弱指标 (RSI)
    
    参数:
        df: 包含 'close' 列的 DataFrame
        period: RSI 计算周期，默认 14
    
    返回:
        RSI 值的 Series
    """
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def calculate_macd(df: pd.DataFrame, fast: int = 12, slow: int = 26, signal: int = 9) -> pd.DataFrame:
    """
    计算 MACD 指标
    
    参数:
        df: 包含 'close' 列的 DataFrame
        fast: 快速 EMA 周期，默认 12
        slow: 慢速 EMA 周期，默认 26
        signal: 信号线周期，默认 9
    
    返回:
        包含 'macd', 'signal', 'histogram' 列的 DataFrame
    """
    exp1 = df['close'].ewm(span=fast, adjust=False).mean()
    exp2 = df['close'].ewm(span=slow, adjust=False).mean()
    
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line
    
    result = pd.DataFrame(index=df.index)
    result['macd'] = macd
    result['macd_signal'] = signal_line
    result['macd_histogram'] = histogram
    return result


def calculate_bollinger_bands(df: pd.DataFrame, period: int = 20, std_dev: float = 2.0) -> pd.DataFrame:
    """
    计算布林带
    
    参数:
        df: 包含 'close' 列的 DataFrame
        period: 移动平均周期，默认 20
        std_dev: 标准差倍数，默认 2.0
    
    返回:
        包含 'bb_upper', 'bb_middle', 'bb_lower' 列的 DataFrame
    """
    result = pd.DataFrame(index=df.index)
    result['bb_middle'] = df['close'].rolling(window=period).mean()
    std = df['close'].rolling(window=period).std()
    result['bb_upper'] = result['bb_middle'] + (std * std_dev)
    result['bb_lower'] = result['bb_middle'] - (std * std_dev)
    return result


def calculate_ema(df: pd.DataFrame, periods: list = [5, 10, 20, 50, 200]) -> pd.DataFrame:
    """
    计算多个周期的指数移动平均线 (EMA)
    
    参数:
        df: 包含 'close' 列的 DataFrame
        periods: EMA 周期列表，默认 [5, 10, 20, 50, 200]
    
    返回:
        包含各周期 EMA 的 DataFrame
    """
    result = pd.DataFrame(index=df.index)
    for period in periods:
        result[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
    return result


def calculate_volume_sma(df: pd.DataFrame, period: int = 20) -> pd.Series:
    """
    计算成交量简单移动平均
    
    参数:
        df: 包含 'volume' 列的 DataFrame
        period: 移动平均周期，默认 20
    
    返回:
        成交量 SMA 的 Series
    """
    return df['volume'].rolling(window=period).mean()


def calculate_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """
    计算平均真实波幅 (ATR)
    
    参数:
        df: 包含 'high', 'low', 'close' 列的 DataFrame
        period: ATR 计算周期，默认 14
    
    返回:
        ATR 值的 Series
    """
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    atr = true_range.rolling(window=period).mean()
    return atr


def calculate_stochastic(df: pd.DataFrame, k_period: int = 14, d_period: int = 3) -> pd.DataFrame:
    """
    计算随机指标 (Stochastic Oscillator)
    
    参数:
        df: 包含 'high', 'low', 'close' 列的 DataFrame
        k_period: %K 周期，默认 14
        d_period: %D 周期，默认 3
    
    返回:
        包含 'stoch_k', 'stoch_d' 列的 DataFrame
    """
    low_min = df['low'].rolling(window=k_period).min()
    high_max = df['high'].rolling(window=k_period).max()
    
    k = 100 * ((df['close'] - low_min) / (high_max - low_min))
    d = k.rolling(window=d_period).mean()
    
    result = pd.DataFrame(index=df.index)
    result['stoch_k'] = k
    result['stoch_d'] = d
    return result

def calculate_obv(df: pd.DataFrame) -> pd.Series:
    """
    计算能量潮指标 (On-Balance Volume)
    
    参数:
        df: 包含 'close', 'volume' 列的 DataFrame
    
    返回:
        OBV 值的 Series
    """
    obv = pd.Series(index=df.index, dtype=float)
    obv.iloc[0] = df['volume'].iloc[0]
    
    for i in range(1, len(df)):
        if df['close'].iloc[i] > df['close'].iloc[i-1]:
            obv.iloc[i] = obv.iloc[i-1] + df['volume'].iloc[i]
        elif df['close'].iloc[i] < df['close'].iloc[i-1]:
            obv.iloc[i] = obv.iloc[i-1] - df['volume'].iloc[i]
        else:
            obv.iloc[i] = obv.iloc[i-1]
    
    return obv

def calculate_adx(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
    """
    计算平均趋向指数 (ADX)
    用于衡量趋势强度
    
    参数:
        df: 包含 'high', 'low', 'close' 列的 DataFrame
        period: 计算周期，默认 14
    
    返回:
        包含 'adx', 'plus_di', 'minus_di' 列的 DataFrame
    """
    plus_dm = df['high'].diff()
    minus_dm = df['low'].diff()
    
    plus_dm[plus_dm < 0] = 0
    minus_dm[minus_dm > 0] = 0
    minus_dm = minus_dm.abs()
    
    tr1 = df['high'] - df['low']
    tr2 = (df['high'] - df['close'].shift()).abs()
    tr3 = (df['low'] - df['close'].shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    atr = tr.rolling(window=period).mean()
    
    plus_di = 100 * (plus_dm.rolling(window=period).mean() / atr)
    minus_di = 100 * (minus_dm.rolling(window=period).mean() / atr)
    dx = (100 * (plus_di - minus_di).abs() / (plus_di + minus_di)).rolling(window=period).mean()
    
    result = pd.DataFrame(index=df.index)
    result['adx'] = dx
    result['plus_di'] = plus_di
    result['minus_di'] = minus_di
    return result


def add_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    为 DataFrame 添加所有技术指标
    
    参数:
        df: 包含 OHLCV 数据的 DataFrame
    
    返回:
        添加了所有技术指标的 DataFrame
    """
    df_result = df.copy()
    
    # 趋势指标
    ema_df = calculate_ema(df_result)
    df_result = pd.concat([df_result, ema_df], axis=1)
    
    macd_df = calculate_macd(df_result)
    df_result = pd.concat([df_result, macd_df], axis=1)
    
    adx_df = calculate_adx(df_result)
    df_result = pd.concat([df_result, adx_df], axis=1)
    
    # 震荡指标
    df_result['rsi'] = calculate_rsi(df_result)
    
    stoch_df = calculate_stochastic(df_result)
    df_result = pd.concat([df_result, stoch_df], axis=1)
    
    # 波动性指标
    bb_df = calculate_bollinger_bands(df_result)
    df_result = pd.concat([df_result, bb_df], axis=1)
    
    df_result['atr'] = calculate_atr(df_result)
    
    # 成交量指标
    df_result['volume_sma'] = calculate_volume_sma(df_result)
    df_result['obv'] = calculate_obv(df_result)
    
    return df_result
