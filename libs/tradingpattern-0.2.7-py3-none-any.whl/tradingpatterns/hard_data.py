import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
from .enum_types import TradingPattern

def generate_sample_df_with_pattern(pattern):
    date_rng = pd.date_range(start='1/1/2020', end='1/10/2020', freq='D')
    data = {'date': date_rng}
    if pattern == TradingPattern.HEAD_SHOULDER.value:
        data['open'] = [90, 85, 80, 90, 85, 80, 75, 80, 85, 90]
        data['high'] = [95, 90, 85, 95, 90, 85, 80, 85, 90, 95]
        data['low'] = [80, 75, 70, 80, 75, 70, 65, 70, 75, 80]
        data['close'] = [90, 85, 80, 90, 85, 80, 75, 80, 85, 90]
        data['volume'] = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
    elif pattern == TradingPattern.INVERSE_HEAD_SHOULDER.value:
        data['open'] = [20, 25, 30, 20, 25, 30, 35, 30, 25, 20]
        data['high'] = [25, 30, 35, 25, 30, 35, 40, 35, 30, 25]
        data['low'] = [15, 20, 25, 15, 20, 25, 30, 25, 20, 15]
        data['close'] = [20, 25, 30, 20, 25, 30, 35, 30, 25, 20]
        data['volume'] = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
    elif pattern in [TradingPattern.DOUBLE_TOP.value, TradingPattern.DOUBLE_BOTTOM.value, 
                    TradingPattern.ASCENDING_TRIANGLE.value, TradingPattern.DESCENDING_TRIANGLE.value]:
        data['open'] = [90, 85, 80, 90, 85, 80, 75, 80, 85, 90]
        data['high'] = [95, 90, 85, 95, 90, 85, 80, 85, 90, 95]
        data['low'] = [80, 75, 70, 80, 75, 70, 65, 70, 75, 80]
        data['close'] = [90, 85, 80, 90, 85, 80, 75, 80, 85, 90]
        data['volume'] = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
    elif pattern == TradingPattern.BULL_FLAG.value:
        # Strong uptrend followed by consolidation
        data['open'] = [80, 85, 90, 95, 100, 98, 96, 94, 95, 96]
        data['high'] = [85, 90, 95, 100, 105, 100, 98, 96, 97, 98]
        data['low'] = [78, 83, 88, 93, 98, 95, 93, 91, 92, 93]
        data['close'] = [84, 89, 94, 99, 104, 97, 95, 93, 94, 95]
        data['volume'] = [10000, 9000, 8000, 7000, 6000, 5000, 4000, 3000, 3500, 4000]
    elif pattern == TradingPattern.CUP_AND_HANDLE.value:
        # U-shaped recovery with handle
        data['open'] = [100, 95, 90, 85, 82, 85, 90, 95, 98, 96]
        data['high'] = [102, 97, 92, 87, 85, 88, 93, 98, 100, 98]
        data['low'] = [98, 93, 88, 83, 80, 83, 88, 93, 96, 94]
        data['close'] = [100, 95, 90, 85, 83, 87, 92, 97, 99, 97]
        data['volume'] = [5000, 5500, 6000, 6500, 7000, 6500, 6000, 5500, 5000, 4500]
    elif pattern == TradingPattern.ROUNDING_BOTTOM.value:
        # Gradual U-shaped recovery
        data['open'] = [100, 95, 90, 85, 82, 83, 87, 92, 97, 102]
        data['high'] = [102, 97, 92, 87, 85, 86, 90, 95, 100, 105]
        data['low'] = [98, 93, 88, 83, 80, 81, 85, 90, 95, 100]
        data['close'] = [100, 95, 90, 85, 83, 85, 89, 94, 99, 104]
        data['volume'] = [5000, 5200, 5400, 5600, 5800, 6000, 6500, 7000, 7500, 8000]
    elif pattern == TradingPattern.SYMMETRICAL_TRIANGLE.value:
        # Converging highs and lows
        data['open'] = [100, 98, 96, 94, 93, 93, 93, 94, 94, 95]
        data['high'] = [105, 103, 101, 99, 97, 96, 95, 95, 95, 96]
        data['low'] = [95, 96, 94, 92, 91, 91, 92, 92, 93, 93]
        data['close'] = [100, 99, 97, 95, 94, 94, 94, 94, 95, 95]
        data['volume'] = [5000, 4800, 4600, 4400, 4200, 4000, 3800, 3600, 3400, 3200]
    else:
        # Default pattern for any other case
        data['open'] = [100] * 10
        data['high'] = [105] * 10
        data['low'] = [95] * 10
        data['close'] = [100] * 10
        data['volume'] = [1000] * 10
    
    df = pd.DataFrame(data)
    return df


# Function to generate random OHLCV data
def generate_random_data(length):
    close_values = np.random.randint(100, 200, length).tolist()
    return {
        'open': [value - random.randint(0, 10) for value in close_values],
        'high': [value + random.randint(0, 10) for value in close_values],
        'low': [value - random.randint(0, 10) for value in close_values],
        'close': close_values,
        'volume': np.random.randint(1000, 2000, length).tolist(),
    }

# Function to inject head and shoulders and inverse head and shoulders patterns
def inject_patterns(data):
    shoulder_height = random.randint(120, 140)
    head_height = random.randint(150, 170)
    inv_shoulder_depth = random.randint(60, 80)
    inv_head_depth = random.randint(40, 60)
    
    # Left Shoulder
    data['high'][3] = shoulder_height
    data['close'][3] = shoulder_height - random.randint(0, 5)
    
    # Head
    data['high'][5] = head_height
    data['close'][5] = head_height - random.randint(0, 5)
    
    # Right Shoulder
    data['high'][7] = shoulder_height
    data['close'][7] = shoulder_height - random.randint(0, 5)
    
    # Left Inverse Shoulder
    data['low'][13] = inv_shoulder_depth
    data['close'][13] = inv_shoulder_depth + random.randint(0, 5)
    
    # Inverse Head
    data['low'][15] = inv_head_depth
    data['close'][15] = inv_head_depth + random.randint(0, 5)
    
    # Right Inverse Shoulder
    data['low'][17] = inv_shoulder_depth
    data['close'][17] = inv_shoulder_depth + random.randint(0, 5)
    
    return data

def generate_data_head_shoulder(n):
    # Start date
    start_date = datetime.now()

    # List for storing dataframes
    dfs = []

    # Generate n Head and Shoulders patterns
    for i in range(n):
        data = generate_random_data(20)  # 20 data points are needed for one full pattern
        data = inject_patterns(data)
        
        temp_df = pd.DataFrame(data)
        temp_df['date'] = pd.date_range(start=start_date, periods=20, freq='D')
        start_date += timedelta(days=20)
        
        dfs.append(temp_df)

    df = pd.concat(dfs, ignore_index=True)
    df = df[['date', 'open', 'high', 'low', 'close', 'volume']]

    return df
