"""
形态确认增强模块
结合技术指标来增强形态识别的可靠性
"""
import pandas as pd
import numpy as np
from .enum_types import TradingPattern
from .indicators import add_all_indicators


class PatternConfirmation:
    """
    形态确认类，用于验证信号强度
    参考资料:
    - John J. Murphy, "Technical Analysis of the Financial Markets"
    - Thomas N. Bulkowski, "Encyclopedia of Chart Patterns"
    - Alexander Elder, "Trading for a Living"
    """
    
    @staticmethod
    def confirm_bullish_reversal(df: pd.DataFrame, idx: int) -> dict:
        """
        确认看涨反转 (Bullish Reversal)
        适用于: 双底, 头肩底, 圆弧底等
        """
        if idx < 0 or idx >= len(df):
            return {'confirmed': False, 'strength': 0, 'signals': []}
        
        signals = []
        strength = 0
        
        # 1. RSI 超卖回升 + 底背离迹象 (RSI < 40 且上升)
        if 'rsi' in df.columns and idx > 0:
            rsi = df['rsi'].iloc[idx]
            rsi_prev = df['rsi'].iloc[idx-1]
            if pd.notna(rsi) and pd.notna(rsi_prev):
                if rsi < 40 and rsi > rsi_prev:
                    signals.append('RSI超卖回升')
                    strength += 2
                elif rsi < 30: # 极度超卖也是一种信号
                    signals.append('RSI极度超卖')
                    strength += 1
        
        # 2. MACD 金叉
        if all(col in df.columns for col in ['macd', 'macd_signal']) and idx > 0:
            if df['macd'].iloc[idx] > df['macd_signal'].iloc[idx] and \
               df['macd'].iloc[idx-1] <= df['macd_signal'].iloc[idx-1]:
                signals.append('MACD金叉')
                strength += 2
        
        # 3. 成交量放量 (突破时成交量 > 1.5倍均量)
        if 'volume' in df.columns and 'volume_sma' in df.columns:
            if df['volume'].iloc[idx] > df['volume_sma'].iloc[idx] * 1.5:
                signals.append('放量突破')
                strength += 2
        
        # 4. 短期均线拐头 (EMA 5 > EMA 10)
        if 'ema_5' in df.columns and 'ema_10' in df.columns:
            if df['ema_5'].iloc[idx] > df['ema_10'].iloc[idx]:
                signals.append('短期均线多头')
                strength += 1
                
        # 5. 指数移动平均线(ADX) 趋势开始减弱或增强 (ADX > 20)
        if 'adx' in df.columns:
            if df['adx'].iloc[idx] > 20:
                signals.append('趋势动能增强')
                strength += 1

        return {
            'confirmed': strength >= 3,
            'strength': strength,
            'signals': signals
        }

    @staticmethod
    def confirm_bearish_reversal(df: pd.DataFrame, idx: int) -> dict:
        """
        确认看跌反转 (Bearish Reversal)
        适用于: 双顶, 头肩顶等
        """
        if idx < 0 or idx >= len(df):
            return {'confirmed': False, 'strength': 0, 'signals': []}
        
        signals = []
        strength = 0
        
        # 1. RSI 超买回落 (RSI > 60 且下降)
        if 'rsi' in df.columns and idx > 0:
            rsi = df['rsi'].iloc[idx]
            rsi_prev = df['rsi'].iloc[idx-1]
            if pd.notna(rsi) and pd.notna(rsi_prev):
                if rsi > 60 and rsi < rsi_prev:
                    signals.append('RSI超买回落')
                    strength += 2
                elif rsi > 70:
                    signals.append('RSI极度超买')
                    strength += 1
        
        # 2. MACD 死叉
        if all(col in df.columns for col in ['macd', 'macd_signal']) and idx > 0:
            if df['macd'].iloc[idx] < df['macd_signal'].iloc[idx] and \
               df['macd'].iloc[idx-1] >= df['macd_signal'].iloc[idx-1]:
                signals.append('MACD死叉')
                strength += 2
        
        # 3. 价格跌破布林带中轨
        if 'close' in df.columns and 'bb_middle' in df.columns:
            if df['close'].iloc[idx] < df['bb_middle'].iloc[idx]:
                signals.append('跌破布林中轨')
                strength += 1
        
        # 4. 成交量异常增加 (恐慌抛售)
        if 'volume' in df.columns and 'volume_sma' in df.columns:
            if df['volume'].iloc[idx] > df['volume_sma'].iloc[idx] * 1.5:
                signals.append('放量下跌')
                strength += 2

        return {
            'confirmed': strength >= 3,
            'strength': strength,
            'signals': signals
        }

    @staticmethod
    def confirm_bullish_continuation(df: pd.DataFrame, idx: int) -> dict:
        """
        确认看涨延续 (Bullish Continuation)
        适用于: 上升旗形, 上升三角形, 杯柄形态等
        """
        if idx < 0 or idx >= len(df):
            return {'confirmed': False, 'strength': 0, 'signals': []}
        
        signals = []
        strength = 0
        
        # 1. 强趋势确认 (ADX > 25)
        if 'adx' in df.columns:
            if df['adx'].iloc[idx] > 25:
                signals.append('趋势强劲(ADX)')
                strength += 2
        
        # 2. 动能确认 (RSI 保持在 50-70 之间)
        if 'rsi' in df.columns:
            rsi = df['rsi'].iloc[idx]
            if 50 <= rsi <= 75:
                signals.append('多头动能维持')
                strength += 1
        
        # 3. 价格在长期均线之上 (Close > EMA 50)
        if 'close' in df.columns and 'ema_50' in df.columns:
            if df['close'].iloc[idx] > df['ema_50'].iloc[idx]:
                signals.append('处于大趋势上方')
                strength += 1
        
        # 4. 成交量配合 (突破时放量)
        if 'volume' in df.columns and 'volume_sma' in df.columns:
            if df['volume'].iloc[idx] > df['volume_sma'].iloc[idx]:
                signals.append('成交量温和放大')
                strength += 1

        return {
            'confirmed': strength >= 2,
            'strength': strength,
            'signals': signals
        }

    @staticmethod
    def confirm_bearish_continuation(df: pd.DataFrame, idx: int) -> dict:
        """
        确认看跌延续 (Bearish Continuation)
        适用于: 下降旗形, 下降三角形等
        """
        if idx < 0 or idx >= len(df):
            return {'confirmed': False, 'strength': 0, 'signals': []}
        
        signals = []
        strength = 0
        
        # 1. 强趋势确认 (ADX > 25)
        if 'adx' in df.columns:
            if df['adx'].iloc[idx] > 25:
                signals.append('趋势强劲(ADX)')
                strength += 2
        
        # 2. 动能确认 (RSI 保持在 30-50 之间)
        if 'rsi' in df.columns:
            rsi = df['rsi'].iloc[idx]
            if 25 <= rsi <= 50:
                signals.append('空头动能维持')
                strength += 1
        
        # 3. 价格在均线之下 (Close < EMA 20)
        if 'close' in df.columns and 'ema_20' in df.columns:
            if df['close'].iloc[idx] < df['ema_20'].iloc[idx]:
                signals.append('受制于短期均线')
                strength += 1

        return {
            'confirmed': strength >= 2,
            'strength': strength,
            'signals': signals
        }

    @staticmethod
    def get_pattern_category(pattern_value: str) -> str:
        """
        判断形态所属类别
        
        返回: 'bullish_reversal', 'bearish_reversal', 'bullish_continuation', 'bearish_continuation'
        """
        # 看涨反转
        if pattern_value in [
            TradingPattern.INVERSE_HEAD_SHOULDER.value,
            TradingPattern.DOUBLE_BOTTOM.value,
            TradingPattern.MULTIPLE_BOTTOM.value,
            TradingPattern.ROUNDING_BOTTOM.value,
            TradingPattern.WEDGE_DOWN.value  # 下降楔形通常看涨反转
        ]:
            return 'bullish_reversal'
            
        # 看跌反转
        if pattern_value in [
            TradingPattern.HEAD_SHOULDER.value,
            TradingPattern.DOUBLE_TOP.value,
            TradingPattern.MULTIPLE_TOP.value,
            TradingPattern.WEDGE_UP.value # 上升楔形通常看跌反转
        ]:
            return 'bearish_reversal'
            
        # 看涨延续
        if pattern_value in [
            TradingPattern.BULL_FLAG.value,
            TradingPattern.CUP_AND_HANDLE.value,
            TradingPattern.ASCENDING_TRIANGLE.value,
            TradingPattern.CHANNEL_UP.value
        ]:
            return 'bullish_continuation'
            
        # 看跌延续
        if pattern_value in [
            TradingPattern.DESCENDING_TRIANGLE.value,
            TradingPattern.CHANNEL_DOWN.value
        ]:
            return 'bearish_continuation'
            
        return 'unknown'


def enhance_pattern_detection(df: pd.DataFrame, pattern_results: list) -> list:
    """
    增强形态检测结果，添加技术指标确认
    
    参数:
        df: 原始 OHLCV 数据
        pattern_results: get_recent_bullish_patterns 返回的形态列表
    
    返回:
        增强后的形态列表，包含确认信息
    """
    # 添加所有技术指标
    df_with_indicators = add_all_indicators(df)
    
    # 为每个形态添加确认信息
    enhanced_results = []
    
    for pattern in pattern_results:
        # 找到对应日期的索引
        date_str = pattern['date']
        
        # 稳健地查找日期匹配行
        # 1. 优先查找名为 'date' 的列（不区分大小写）
        date_col = next((col for col in df_with_indicators.columns if col.lower() == 'date'), None)
        
        if date_col:
            matching_rows = df_with_indicators[df_with_indicators[date_col].astype(str).str.contains(date_str)]
        else:
            # 2. 如果没有日期列，检查索引
            matching_rows = df_with_indicators[df_with_indicators.index.astype(str).str.contains(date_str)]
        
        if matching_rows.empty:
            # 如果找不到日期，跳过
            enhanced_pattern = pattern.copy()
            enhanced_pattern['confirmation'] = {
                'confirmed': False,
                'strength': 0,
                'signals': []
            }
            enhanced_results.append(enhanced_pattern)
            continue
        
        idx = matching_rows.index[0]
        idx_pos = df_with_indicators.index.get_loc(idx)
        
        # 判断形态类别并进行相应确认
        category = PatternConfirmation.get_pattern_category(pattern['pattern'])
        
        if category == 'bullish_reversal':
            confirmation = PatternConfirmation.confirm_bullish_reversal(df_with_indicators, idx_pos)
        elif category == 'bearish_reversal':
            confirmation = PatternConfirmation.confirm_bearish_reversal(df_with_indicators, idx_pos)
        elif category == 'bullish_continuation':
            confirmation = PatternConfirmation.confirm_bullish_continuation(df_with_indicators, idx_pos)
        elif category == 'bearish_continuation':
            confirmation = PatternConfirmation.confirm_bearish_continuation(df_with_indicators, idx_pos)
        else:
            # 未知形态或暂不支持的形态
            confirmation = {'confirmed': False, 'strength': 0, 'signals': ['未知形态类型']}
        
        # 添加确认信息到结果
        enhanced_pattern = pattern.copy()
        enhanced_pattern['confirmation'] = confirmation
        enhanced_results.append(enhanced_pattern)
    
    return enhanced_results


def filter_confirmed_patterns(enhanced_patterns: list, min_strength: int = 2) -> list:
    """
    过滤出已确认的强信号形态
    
    参数:
        enhanced_patterns: 增强后的形态列表
        min_strength: 最小信号强度，默认 2
    
    返回:
        过滤后的形态列表
    """
    return [
        p for p in enhanced_patterns 
        if p['confirmation']['confirmed'] and p['confirmation']['strength'] >= min_strength
    ]
