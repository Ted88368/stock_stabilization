# -*- coding: utf-8 -*-
import talib
from talib import MA_Type
import pandas as pb

from ..utils.ma_type import ma_string

def set_sma(df):
    # 计算5日简单移动平均线
    df['SMA_5'] = talib.SMA(df['close'], timeperiod=5)

    # 计算10日简单移动平均线
    df['SMA_10'] = talib.SMA(df['close'], timeperiod=10)

    # 计算20日简单移动平均线
    df['SMA_20'] = talib.SMA(df['close'], timeperiod=20)

    # 计算60日简单移动平均线
    df['SMA_60'] = talib.SMA(df['close'], timeperiod=60)

    # 计算120日简单移动平均线
    df['SMA_120'] = talib.SMA(df['close'], timeperiod=120)

    # 计算250日简单移动平均线
    df['SMA_250'] = talib.SMA(df['close'], timeperiod=250)

    return df


"""
EMA（指数移动平均线）
适合短期交易，常用于日内交易、短期趋势跟踪及动态支撑/阻力分析。
"""


def set_ema(df):

    # if "EMA_5" in df.columns:
    #     return

    # 计算5日指数移动平均线
    df['EMA_5'] = talib.EMA(df['close'], timeperiod=5)

    # 计算10日指数移动平均线
    df['EMA_10'] = talib.EMA(df['close'], timeperiod=10)

    # 计算20日指数移动平均线
    df['EMA_20'] = talib.EMA(df['close'], timeperiod=20)

    # 计算60日指数移动平均线
    df['EMA_60'] = talib.EMA(df['close'], timeperiod=60)

    # 计算120日指数移动平均线
    df['EMA_120'] = talib.EMA(df['close'], timeperiod=120)

    # 计算250日指数移动平均线
    df['EMA_250'] = talib.EMA(df['close'], timeperiod=250)

    # return df


"""
MA（加权或指数移动平均线）
适用场景：适合中短期交易策略，常用于动态支撑/阻力位分析。
"""


def set_ma(df : pb.DataFrame):

    # if "MA_5" in df.columns:
    #     return

    # 计算5日简单移动平均线
    df['MA_5'] = talib.MA(df['close'], timeperiod=5)
    df['SMA_5'] = df['MA_5']

    # 计算10日简单移动平均线
    df['MA_10'] = talib.MA(df['close'], timeperiod=10)
    df['SMA_10'] = df['MA_10']

    # 计算20日简单移动平均线
    df['MA_20'] = talib.MA(df['close'], timeperiod=20)
    df['SMA_20'] = df['MA_20']

    # 计算60日简单移动平均线
    df['MA_60'] = talib.MA(df['close'], timeperiod=60)
    df['SMA_60'] = df['MA_60']

    # 计算120日简单移动平均线
    df['MA_120'] = talib.MA(df['close'], timeperiod=120)
    df['SMA_120'] = df['MA_120']

    # 计算250日简单移动平均线
    df['MA_250'] = talib.MA(df['close'], timeperiod=250)
    df['SMA_250'] = df['MA_250']


