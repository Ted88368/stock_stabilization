import logging
import os

import pandas as pd
import talib

def set_macd(df):
    """
    macd : 对应于DIF
    macdsignal: 对应于DEA
    macdhist: 柱状图
    """

    # if 'MACD' in df.columns and 'MACD_signal' in df.columns and 'MACD_hist' in df.columns:
    #     return

    fast_period = 6
    slow_period = 13
    signal_period = 5

    df['MACD'], df['MACD_signal'], df['MACD_hist'] = talib.MACD(df['close'], fastperiod=fast_period, slowperiod=slow_period, signalperiod=signal_period)
    # return df


