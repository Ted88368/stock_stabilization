# -*- coding: utf-8 -*-
"""kdata package

This package provides simple data provider adapters that read OHLC time series
from various sources. Data storage location is determined by the
K_DATA_CENTER environment variable (defaults to ./data).
"""

from .core import __version__

# 导出 get_ohlc 函数
from .data import get_ohlc, Period, DownloadProvider
from .kdata_utils import generate_weekly_kdata


# 导入子包
from . import utils
from . import technical
from . import draw
from . import emotion

__all__ = [
    "get_ohlc",
    "__version__",
    "Period",
    "DownloadProvider",
    "generate_weekly_kdata",
    "technical",
    "draw",
    "emotion",
    "utils",
]
