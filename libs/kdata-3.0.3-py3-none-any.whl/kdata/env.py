# -*- coding: utf-8 -*-
"""Environment helpers for kdata.

Provides a thin abstraction around the K_DATA_CENTER environment variable so
the rest of the package can obtain and initialize the data directory in a
single place. This makes it easier to switch to a centralized environment
manager later.
"""
from __future__ import annotations

import os
from typing import Optional
import logging
from dotenv import load_dotenv

from .provider import Period



log = logging.getLogger(__name__)

def load_env_vars():
    """Load environment variables from .env files.
    Priority:
    1. .env in K_DATA_CENTER directory (if K_DATA_CENTER is already set)
    2. .env in current working directory
    """
    # 1. Try to load from K_DATA_CENTER if already set
    k_data_center = os.environ.get("K_DATA_CENTER")
    if k_data_center:
        dotenv_path = os.path.join(k_data_center, ".env")
        if os.path.exists(dotenv_path):
            load_dotenv(dotenv_path)
            log.info(f"Loaded environment variables from {dotenv_path}")
            return

    # 2. Try to load from current working directory
    if os.path.exists(".env"):
        load_dotenv(".env")
        log.info("Loaded environment variables from .env in current directory")
        
        # After loading, check if K_DATA_CENTER was defined in .env and try to load again from there
        new_k_data_center = os.environ.get("K_DATA_CENTER")
        if new_k_data_center and new_k_data_center != k_data_center:
            dotenv_path = os.path.join(new_k_data_center, ".env")
            if os.path.exists(dotenv_path):
                load_dotenv(dotenv_path, override=True)
                log.info(f"Loaded environment variables from {dotenv_path} (K_DATA_CENTER from .env)")

# Load environment variables on module import
load_env_vars()

def get_data_dir() -> str:
    """Return the directory used to store data files.

    The function reads the `K_DATA_CENTER` environment variable. If that
    variable is not set, it falls back to a ./data directory under the
    current working directory.
    """
    return os.environ.get("K_DATA_CENTER", os.path.join(os.getcwd(), "data"))


def init_env(path: Optional[str] = None) -> str:
    """Ensure the data directory exists and optionally set K_DATA_CENTER.

    If `path` is None the function will ensure the directory returned by
    :func:`get_data_dir` exists. If `path` is provided it will be used and
    exported to the `K_DATA_CENTER` environment variable for the current
    process.

    Returns the path that was created/validated.
    """
    if path is None:
        path = get_data_dir()

    os.makedirs(path, exist_ok=True)

    # Export into current process so other modules can read it right away.
    os.environ["K_DATA_CENTER"] = path
    return path


def data_file_path(symbol: str, start: str, end: str, period=Period.DAILY, *, base_dir: Optional[str] = None) -> str:
    """Return the canonical file path for a symbol/date range CSV.

    The filename format is: {symbol}_{start}_{end}_{period}.csv placed under the
    directory returned by :func:`get_data_dir` or the optional ``base_dir``.
    
    Args:
        symbol: 股票代码
        start: 开始日期
        end: 结束日期
        period: 周期类型，使用Period枚举或字符串
        base_dir: 基础目录
    """
    base = base_dir or get_data_dir()
    # 添加日期作为文件夹
    date_dir = f"{start}_{end}"
    os.makedirs(os.path.join(base, date_dir), exist_ok=True)

    # 获取周期的字符串表示
    period_value = period.value if hasattr(period, 'value') else period
    filename = f"{symbol}_{start}_{end}_{period_value}.csv"
    return os.path.join(base, date_dir, filename)

def init_log(file_name="etf.log", log_dir=None, simple_formatter=True):
    import logging
    import os
    from logging.handlers import RotatingFileHandler
    root_logger = logging.getLogger()

    # reset the handlers
    root_logger.handlers = []

    root_logger.setLevel(logging.INFO)

    file_name = os.path.join(log_dir, file_name)

    file_log_handler = RotatingFileHandler(file_name, maxBytes=524288000, backupCount=10)

    file_log_handler.setLevel(logging.INFO)

    console_log_handler = logging.StreamHandler()
    console_log_handler.setLevel(logging.INFO)

    # create formatter and add it to the handlers
    if simple_formatter:
        formatter = logging.Formatter("%(asctime)s  %(levelname)s  %(threadName)s  %(message)s")
    else:
        formatter = logging.Formatter(
            "%(asctime)s  %(levelname)s  %(threadName)s  %(name)s:%(filename)s:%(lineno)s  %(funcName)s  %(message)s"
        )
    file_log_handler.setFormatter(formatter)
    console_log_handler.setFormatter(formatter)

    # add the handlers to the logger
    root_logger.addHandler(file_log_handler)
    root_logger.addHandler(console_log_handler)

__all__ = ["get_data_dir", "init_env", "init_log"]
