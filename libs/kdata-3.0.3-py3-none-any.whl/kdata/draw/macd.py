
# -*- coding: utf-8 -*-
import mplfinance as mpf


def create_macd_plot(df):
    ap_macd = mpf.make_addplot(df['MACD'], panel=2, color='blue', width=2, label='MACD', ylabel='MACD', secondary_y=True)
    ap_macd_signal = mpf.make_addplot(df['MACD_signal'], panel=2, color='red', width=2, label='MACD_signal', ylabel='MACD',secondary_y=True)
    ap_macd_hist = mpf.make_addplot(df['MACD_hist'], panel=2, type='bar', color='gray', width=0.8, label='MACD_hist', ylabel='MACD_hist', secondary_y=False)

    return [ap_macd_hist, ap_macd, ap_macd_signal]