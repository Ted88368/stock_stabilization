# -*- coding: utf-8 -*-
import mplfinance as mpf
from talib import MA_Type

from ..utils.ma_type import ma_string


def create_ma_plot(df, ma_type= MA_Type.EMA):

    ma_type_str = ma_string(ma_type)

    aps = [
        mpf.make_addplot(df[f"{ma_type_str}_5"], width=1, color='orange', secondary_y=False),
        mpf.make_addplot(df[f"{ma_type_str}_10"], width=2, color='blue', label=f'{ma_type_str}-{10}', secondary_y=False),
        mpf.make_addplot(df[f"{ma_type_str}_20"], width=3, color='red', label=f'{ma_type_str}-{20}', secondary_y=False),
        mpf.make_addplot(df[f"{ma_type_str}_60"], width=3, color='green', label=f'{ma_type_str}-{60}', secondary_y=False),
        mpf.make_addplot(df[f"{ma_type_str}_120"], width=2, color='black', label=f'{ma_type_str}-{120}', secondary_y=False),
        mpf.make_addplot(df[f"{ma_type_str}_250"], width=2, color='gray', secondary_y=False)
    ]

    return aps