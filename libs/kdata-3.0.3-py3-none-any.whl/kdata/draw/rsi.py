

import mplfinance as mpf


def create_rsi_plot(df):
    """
    创建KDJ指标的绘图函数
    """

    # 创建附加图，用于显示 KDJ 指标 在第二个面板（panel=1）中，跟 交易量方一起
    ap_k = mpf.make_addplot(df['RSI_6'], panel=1, color='blue', label='RSI_6', ylabel = 'RSI')
    ap_d = mpf.make_addplot(df['RSI_12'], panel=1, color='orange', label='RSI_12')
    ap_j = mpf.make_addplot(df['RSI_24'], panel=1, color='purple', label='RSI_24')

    return [ap_k, ap_d, ap_j]
