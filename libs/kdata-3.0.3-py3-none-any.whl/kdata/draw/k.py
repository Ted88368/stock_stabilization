# -*- coding: utf-8 -*-
import platform

import mplfinance as mpf
from matplotlib import pyplot as plt
from talib import MA_Type
import pandas as pd
from .boll import create_boll_plot
from .ma import create_ma_plot
from .macd import create_macd_plot
from .rsi import create_rsi_plot
from ..technical.boll import set_boll
from ..technical.kdj import set_kdj
from ..technical.macd import set_macd
from ..technical.rsi import set_rsi
from ..technical.sma import set_ema, set_ma


def draw_plus(df, name, size=90, path=None, ma_type=MA_Type.EMA):
    """
    画K线图
    Args:
        df:
        name:
        size:
        path:
        ma_type:

    Returns:

    """
    set_ema(df)
    set_ma(df)
    set_boll(df)
    set_macd(df)
    set_kdj(df)
    set_rsi(df)

    df = df.tail(size)
    aps =  create_ma_plot(df,ma_type)
    aps += create_boll_plot(df)
    aps += create_macd_plot(df)
    #aps += create_kdj_plot(df)
    aps += create_rsi_plot(df)

    draw(df, name, aps = aps, path = path)


def draw(df,name=None, aps=None, path=None):

    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    
    # 调用make_marketcolors函数，定义K线颜色
    mc = mpf.make_marketcolors(
        up="red",  # 上涨K线的颜色
        down="green",  # 下跌K线的颜色
        edge="black",  # 蜡烛图箱体的颜色
        volume={"up": "red", "down": "green"},  # 成交量柱子的颜色
        wick="black"  # 蜡烛图影线的颜色
    )


    # 调用make_mpf_style函数，自定义图表样式
    # 函数返回一个字典，查看字典包含的数据，按照需求和规范调整参数
    # https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html
    # 根据系统设置字体
    system = platform.system()

    if system == 'Darwin':  # macOS
        font_name = 'Arial Unicode MS'
    elif system == 'Windows':
        font_name = 'SimHei'
    else:  # Linux 或其他
        font_name = 'WenQuanYi Micro Hei'  # 或 'DejaVu Sans'

    style = mpf.make_mpf_style(base_mpl_style='ggplot', marketcolors=mc,
                               rc={
                                   'font.family': font_name,  # 设置字体
                                   'font.size':12,  # 字体大小
                                   'font.style': 'italic',  # 字体样式（斜体）
                                   'font.weight': 'bold',  # 字体粗细
                                   'axes.unicode_minus': False,  # 解决负号'-'显示为方块的问题
                                   'axes.titlesize': 20,  # 标题大小
                               })

    panel_ratios = [3,1,1]

    if aps is None:
        panel_ratios = [3,1]
        aps =  create_ma_plot(df, MA_Type.EMA)

    # 先创建 Figure 和 Axes
    fig, axlist = mpf.plot(df, type='candle', style=style, volume=True,
                       axtitle=name, addplot=aps, returnfig=True, figsize=(16, 10),
                       # 设置子图的排列方式
                       panel_ratios= panel_ratios)

    for ax in axlist:
       # 设置 x 轴刻度的字体大小
       ax.tick_params(axis='x', labelsize=8)
        # Add legend to the left side
       ax.legend(loc='upper left', bbox_to_anchor=(0.05, 0.9))


    if path is not None:
        fig.savefig(path,bbox_inches='tight')

    else:
        fig.show()
        # 等待 5 秒后关闭图表
        plt.pause(20)

    #fig.clear()
    plt.close(fig)



def draw_ma(df, name,ma_type= MA_Type.EMA, path=None):
    # 调用make_marketcolors函数，定义K线颜色
    mc = mpf.make_marketcolors(
        up="red",  # 上涨K线的颜色
        down="green",  # 下跌K线的颜色
        edge="black",  # 蜡烛图箱体的颜色
        volume="blue",  # 成交量柱子的颜色
        wick="black"  # 蜡烛图影线的颜色
    )

    # 调用make_mpf_style函数，自定义图表样式
    # 函数返回一个字典，查看字典包含的数据，按照需求和规范调整参数

    # 根据系统设置字体
    system = platform.system()

    if system == 'Darwin':  # macOS
        font_name = 'Arial Unicode MS'
    elif system == 'Windows':
        font_name = 'SimHei'
    else:  # Linux 或其他 
        #  sudo apt-get install  ttf-wqy-zenhei ttf-wqy-microhei fonts-arphic-ukai fonts-arphic-uming  
        #  rm -rf ~/.cache/matplotlib 
        font_name = 'WenQuanYi Micro Hei'  # 或 'DejaVu Sans'

    style = mpf.make_mpf_style(base_mpl_style="ggplot", marketcolors=mc,
                               rc={
                                   'font.size': 16,  # 字体大小
                                   'font.family': font_name,  # 字体类型
                                   'font.style': 'italic',  # 字体样式（斜体）
                                   'font.weight': 'bold',  # 字体粗细
                                   'axes.unicode_minus': False,  # 解决负号'-'显示为方块的问题
                                   'axes.titlesize': 30,  # 标题大小
                               })

    aps = create_ma_plot(df, ma_type)
    # 先创建 Figure 和 Axes
    fig, _  = mpf.plot(df, type='candle', style=style, volume=True, axtitle=name, addplot=aps, returnfig=True, figsize=(40, 16))


    if path is not None:
        fig.savefig(path,bbox_inches='tight')

    else:
        fig.show()
        # 等待 5 秒后关闭图表
        plt.pause(20)

    fig.clear()
    plt.close(fig)


