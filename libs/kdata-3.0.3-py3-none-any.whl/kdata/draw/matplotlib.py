# -*- coding: utf-8 -*-
from abc import ABC

import matplotlib.pyplot as plt
from matplotlib import ticker

from .draw import IDraw
from .plottable_draw import Plottable


class Matplotlib(IDraw, ABC):
    def __init__(self):
        self.table_drawer = Plottable();
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Songti SC', 'STFangsong']  # 中文显示
        plt.rcParams['axes.unicode_minus'] = False

    def draw_index(self, df, out=None, table_tile=None, pos=False):
        self.table_drawer.draw_index(df,out,table_tile,pos)


    def draw_fear_or_greed(self, df, out=None):
        # theme = load_theme("scientific")
        # theme.apply()

        df  = df.tail(180)
        # 创建一个绘图对象
        fig, ax1 = plt.subplots(figsize=(10, 6))

        plt.xticks(rotation=45)  # 将 X 轴标签旋转 45 度

        # https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html
        plt.style.use('bmh')

        plt.gca().xaxis.set_major_locator(ticker.MultipleLocator(10))

        ax1.set_ylabel('上证指数', color='b')
        ax1.plot(df['date'], df['index'], label="上证指数", color='b')
        ax1.legend(loc='upper left')  # 设置 ax1 的图例位置

        # 创建第二个 Y 轴并绘制数据
        ax2 = ax1.twinx()  # 使用 twinx() 共享 x 轴
        ax2.set_ylabel('恐贪指数', color='red')
        ax2.plot(df['date'], df['fear'], label="恐贪指数", color='red', linestyle=':')
        ax2.legend(loc='upper center')  # 设置 ax2 的图例位置

        # 添加图例
        fig.tight_layout()  # 自动调整布局

        if out is None:
            plt.show()
        else:
            plt.savefig(out)