# -*- coding: utf-8 -*-
"""
可绘制对象模块
"""

import matplotlib.pyplot as plt
from matplotlib import ticker


class Plottable:
    """
    可绘制对象类，提供基本的绘图功能
    """
    def draw_index(self, df, out=None, table_title=None, pos=False):
        """
        绘制指数图表
        :param df: 包含指数数据的DataFrame
        :param out: 输出图片路径，None表示直接显示
        :param table_title: 图表标题
        :param pos: 是否显示位置信息
        """
        # 设置中文显示
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Songti SC', 'STFangsong']
        plt.rcParams['axes.unicode_minus'] = False
        
        # 创建绘图对象
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # 设置X轴标签旋转
        plt.xticks(rotation=45)
        
        # 设置样式
        plt.style.use('bmh')
        
        # 设置X轴刻度间隔
        ax.xaxis.set_major_locator(ticker.MultipleLocator(10))
        
        # 绘制指数曲线
        ax.plot(df['date'], df['index'], label='指数', color='b')
        
        # 设置标题和标签
        if table_title:
            ax.set_title(table_title)
        ax.set_xlabel('日期')
        ax.set_ylabel('指数值')
        
        # 添加图例
        ax.legend()
        
        # 自动调整布局
        fig.tight_layout()
        
        # 保存或显示图表
        if out is None:
            plt.show()
        else:
            plt.savefig(out)
