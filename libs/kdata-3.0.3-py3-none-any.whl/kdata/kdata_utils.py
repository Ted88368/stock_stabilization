import pandas as pd
from datetime import datetime

def generate_weekly_kdata(daily_kdata: pd.DataFrame) -> pd.DataFrame:
    """
    基于日K数据生成周K数据
    
    Args:
        daily_kdata: 日K数据DataFrame，需包含date或Date列、open、high、low、close、volume列
                     且日期列已转换为datetime类型
    
    Returns:
        周K数据DataFrame
    """
    # 创建副本避免修改原始数据
    df = daily_kdata.copy()
    date_col = None
    # 检查日期列名，支持'date'或'Date'
    if 'Date' in df.columns:
        date_col = 'Date'
    elif 'date' in df.columns:
        date_col = 'date'
    elif df.index.name in ['Date', 'date'] and isinstance(df.index, pd.DatetimeIndex):
        # 如果日期是索引且是datetime类型，直接使用索引
        date_col = df.index.name
    else:
        raise ValueError("数据必须包含'Date'或'date'列，或者日期作为datetime类型的索引")
    
    # 如果日期是列而不是索引，将其设置为索引
    if date_col in df.columns:
        # 确保日期列是datetime类型
        if not pd.api.types.is_datetime64_any_dtype(df[date_col]):
            df[date_col] = pd.to_datetime(df[date_col])
        # 设置日期为索引
        df = df.set_index(date_col)
       
    # 按周重采样并应用聚合函数,包留三位小数
    pd.set_option('display.float_format', lambda x: '%.3f' % x)
 
    weekly_kdata = df.resample('W').agg({
        'open': 'first',      # 周开盘价：本周第一个交易日的开盘价
        'high': 'max',        # 周最高价：本周所有交易日的最高价
        'low': 'min',         # 周最低价：本周所有交易日的最低价
        'close': 'last',      # 周收盘价：本周最后一个交易日的收盘价
        'volume': 'sum'       # 周成交量：本周所有交易日的成交量总和
    })
    
    # 重置索引，保留date列
    weekly_kdata = weekly_kdata.reset_index()
    # 过滤掉空值行（可能是因为当周没有交易数据）
    weekly_kdata = weekly_kdata.dropna()

    # 判断数据的最后一天是否是周的最后一天
    # last_date = df.index[-1]
    # if last_date.weekday() < 5:  # 5是周六的索引
    #     # 删除最后一行
    #     weekly_kdata = weekly_kdata.drop(weekly_kdata.index[-1])

    # 统一清洗和索引
    from .utils.cleaner import clean_ohlc_data
    weekly_kdata = clean_ohlc_data(weekly_kdata)
    if 'Date' in weekly_kdata.columns:
        weekly_kdata['Date'] = pd.to_datetime(weekly_kdata['Date'])
        weekly_kdata.set_index('Date', inplace=True)
    elif 'date' in weekly_kdata.columns:
        weekly_kdata['date'] = pd.to_datetime(weekly_kdata['date'])
        weekly_kdata.set_index('date', inplace=True)
    elif not isinstance(weekly_kdata.index, pd.DatetimeIndex):
        weekly_kdata.index = pd.to_datetime(weekly_kdata.index)
    weekly_kdata.index.name = 'Date'
    return weekly_kdata


