"""Batch downloader for K-line data built on top of kdata providers.

Provides a simple, opinionated BatchDownloader that:
- accepts a list of symbols and a date range
- chooses a provider per-symbol (or uses the user-supplied provider)
- downloads in parallel using ThreadPoolExecutor
- saves each result to CSV under the chosen data directory (or given out_dir)

The implementation is intentionally small and dependency-light so it can be
used in tests and in CI; provider lookup is pluggable and falls back to
explicit imports of the existing provider modules in this package.
"""

from __future__ import annotations

import concurrent.futures
import logging
import os
import random
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from .env import get_data_dir, init_env, data_file_path

log = logging.getLogger(__name__)


def _detect_provider_for_symbol(symbol: str) -> Optional[str]:
    """Heuristic to pick a provider name from a symbol string.

    Returns a provider key such as 'baostock', 'hk', 'usa', 'etf', or None.
    These keys are mapped by BatchDownloader to concrete provider classes.
    """
    s = symbol.lower()
    # convention used elsewhere in the project: 'sh.' / 'sz.' prefix
    if s.startswith("sh.") or s.startswith("sz.") or (s.isdigit() and len(s) == 6):
        return "baostock"
    # hong kong stocks are often numeric codes, user may pass '00700.HK' or plain '00700'
    if s.endswith(".hk") or (s.isdigit() and len(s) in (4, 5)):
        return "hk"
    # us tickers often contain letters and possibly a suffix like .US — fallback to usa
    if s.endswith(".us") or s.isalpha():
        return "usa"
    # etf detection (simple)
    if "etf" in s:
        return "etf"
    return None


@dataclass
class DownloadResult:
    symbol: str
    ok: bool
    path: Optional[str] = None
    error: Optional[Exception] = None


class BatchDownloader:
    """Download many symbols using kdata providers.

    Usage:
        dl = BatchDownloader()
        results = dl.download(["sh.000300", "000858"], "2023-01-01", "2023-01-31")
    """

    def __init__(
        self,
        provider_map: Optional[Dict[str, Callable]] = None,  #
        *,
        rate_limits: Optional[Dict[str, float]] = None,
        min_interval: float = 3.0,
        backoff: bool = True,
        max_backoff: float = 30.0,
        jitter: bool = True,
    ):
        """Initialize the BatchDownloader.
        provider_map: 把 provider key（例如 "baostock"/"hk"/"usa"/"etf"）映射到一个可调用对象（签名：fn(code, start, end) -> pandas.DataFrame）
        rate_limits: 每个 provider key 对应的请求速率限制（每秒请求数）；如果提供，则用于计算最小间隔
        min_interval: 默认的最小间隔（秒）用于同一 provider 的请求之间
        backoff: 是否在失败时启用指数退避
        max_backoff: 最大退避时间（秒）
        jitter: 是否在间隔和退避中添加随机抖动以减少同步请求的可能性
        """
        # provider_map: mapping from provider key -> callable that takes (symbol,start,end) -> DataFrame
        self.provider_map = provider_map or {}
        self.backoff = bool(backoff)
        self.max_backoff = float(max_backoff)
        self.jitter = bool(jitter)

        # lazy import of built-in providers
        self._ensure_builtin_providers()

    def _ensure_builtin_providers(self) -> None:
        # import providers lazily to avoid hard dependency at import time
        if "baostock" not in self.provider_map:
            try:
                from .astock import AStock

                self.provider_map["baostock"] = lambda code, s, e: AStock().get_k_data(
                    code, s, e
                )
            except Exception:
                log.error("baostock provider not available", exc_info=True)

        if "hk" not in self.provider_map:
            try:
                from .hk import HK

                self.provider_map["hk"] = lambda code, s, e: HK().get_k_data(code, s, e)
            except Exception:
                log.error("hk provider not available", exc_info=True)

        if "usa" not in self.provider_map:
            try:
                from .usa import USA

                self.provider_map["usa"] = lambda code, s, e: USA().get_k_data(
                    code, s, e
                )
            except Exception:
                log.error("usa provider not available", exc_info=True)

        if "etf" not in self.provider_map:
            try:
                from .etf import ETF

                self.provider_map["etf"] = lambda code, s, e: ETF().get_k_data(
                    code, s, e
                )
            except Exception:
                log.error("etf provider not available", exc_info=True)

        if "mootdx" not in self.provider_map:
            try:
                from .astock import AStock
                from .provider import DownloadProvider

                self.provider_map["mootdx"] = lambda code, s, e: AStock().get_k_data(
                    code, s, e, download_provider=DownloadProvider.MOOTDX
                )
            except Exception:
                try:
                    from .etf import ETF
                    from .provider import DownloadProvider

                    self.provider_map["mootdx"] = lambda code, s, e: ETF().get_k_data(
                        code, s, e, download_provider=DownloadProvider.MOOTDX
                    )
                except Exception:
                    log.error("mootdx provider not available", exc_info=True)

    def download(
        self,
        symbols: Iterable[str],
        start: str,
        end: str,
        provider: Optional[str] = None,
        out_dir: Optional[str] = None,
        parallel: int = 4,
        overwrite: bool = False,
        retries: int = 1,
    ) -> List[DownloadResult]:
        """Download the given symbols and save CSVs.

        symbols: iterable of symbol strings
        start, end: dates (YYYY-MM-DD)
        provider: if given, use this provider key for all symbols
        out_dir: directory to save CSVs; defaults to `get_data_dir()`
        parallel: number of worker threads
        overwrite: whether to overwrite existing CSVs
        retries: number of total attempts (1 => 1 attempt, 2 => 2 attempts with 1 retry)
        """
        logging.info(
            "BatchDownloader.download: symbols=%s start=%s end=%s provider=%s out_dir=%s parallel=%s overwrite=%s retries=%s",
            list(symbols),
            start,
            end,
            provider,
            out_dir,
            parallel,
            overwrite,
            retries,
        )

        target_dir = out_dir or get_data_dir()
        init_env(target_dir)
        os.makedirs(target_dir, exist_ok=True)

        symbols_list = list(symbols)

        def _worker(sym: str) -> DownloadResult:
            nonlocal provider
            key = provider or _detect_provider_for_symbol(sym) or "baostock"
            fn = self.provider_map.get(key)
            if not fn:
                return DownloadResult(
                    sym, False, None, RuntimeError(f"no provider for key={key}")
                )


            file_path = data_file_path(sym, start, end, base_dir=target_dir)
            if os.path.exists(file_path) and not overwrite:
                log.info("skipping existing %s", file_path)
                return DownloadResult(sym, True, file_path, None)

            logging.info("downloading %s using provider %s", sym, key)

            last_exc: Optional[Exception] = None
            # retries=1 means 1 attempt (no retry), retries=2 means 2 attempts (1 retry), etc.
            # Fix: range(1, retries) was wrong - it would skip all attempts when retries=1
            # Now: range(1, retries + 1) ensures at least 1 attempt when retries=1
            for attempt in range(1, retries + 1):
                try:
                    df = fn(sym, start, end)
                except Exception as exc:
                    last_exc = exc
                    log.warning(
                        "download failed for %s (attempt %s): %s", sym, attempt, exc
                    )
                    # fall through to retry/backoff handling
                else:
                    # allow pandas-like DataFrame to be saved
                    try:
                        df.to_csv(file_path)
                    except Exception:
                        # fallback: try to convert to string
                        with open(file_path, "w", encoding="utf-8") as f:
                            f.write(str(df))
                    return DownloadResult(sym, True, file_path, None)

                # if we reach here we had an exception and may retry
                # Only retry if this is not the last attempt
                if attempt < retries and self.backoff:
                    base = 0.5
                    sleep_time = min(self.max_backoff, base * (2 ** (attempt - 1)))
                    if self.jitter:
                        sleep_time += random.uniform(0, min(1.0, sleep_time * 0.1))
                    log.error(
                        "backoff sleep %.3fs before retry %s for %s",
                        sleep_time,
                        attempt + 1,
                        sym,
                    )
                    time.sleep(sleep_time)

            return DownloadResult(sym, False, None, last_exc)

        results: List[DownloadResult] = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as ex:
            futures = {ex.submit(_worker, s): s for s in symbols_list}
            for fut in concurrent.futures.as_completed(futures):
                res = fut.result()
                results.append(res)

        return results


__all__ = ["BatchDownloader", "DownloadResult"]
