# -*- coding: utf-8 -*-
import os
import akshare as ak
import pandas as pd
from typing import Optional, Callable, Dict, Tuple
from enum import Enum
from datetime import datetime, timedelta, timezone
import json
import logging

from .env import get_data_dir, data_file_path
from .utils.pacing import global_pacer
from .provider import OHLC, Period, DownloadProvider
from .kdata_utils import generate_weekly_kdata
from .utils.cleaner import clean_ohlc_data
from .utils.longport_client import longport_client, LONGPORT_AVAILABLE

log = logging.getLogger(__name__)





class HKDownloadFunctionManager:
    """港股下载函数管理器，支持手动和自动切换"""
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        初始化下载函数管理器
        
        Args:
            cache_dir: 缓存目录，用于存储失败记录
        """
        self.cache_dir = cache_dir or os.getenv("K_DATA_CENTER") or "/tmp"
        self.cache_file = os.path.join(self.cache_dir, "hk_download_failure_cache.json")
        self.failure_timeout = timedelta(hours=12)
        
        # 注册下载函数
        self.download_functions: Dict[str, Callable] = {
            DownloadProvider.STOCK_HK_HIST.value: self._download_with_stock_hk_hist,
            DownloadProvider.STOCK_HK_DAILY.value: self._download_with_stock_hk_daily,
            DownloadProvider.LONGPORT.value: self._download_with_longport,
        }
        
        # 下载函数优先级（自动模式下的尝试顺序）
        self.priority_order = [
            DownloadProvider.LONGPORT.value,
            DownloadProvider.STOCK_HK_HIST.value,
            DownloadProvider.STOCK_HK_DAILY.value,
        ]
    
    def _download_with_stock_hk_hist(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用stock_hk_hist下载数据"""
        return ak.stock_hk_hist(symbol=stock_code, period="daily", start_date=start_date, end_date=end_date, adjust="qfq")
    
    def _download_with_stock_hk_daily(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用stock_hk_daily下载数据，需要手动切片日期范围"""
        data = ak.stock_hk_daily(symbol=stock_code, adjust="qfq")
        if data is None or data.empty:
            raise RuntimeError(f"stock_hk_daily returned empty data for {stock_code}")
        # stock_hk_daily 没有时间参数，需手动切片
        if '日期' in data.columns:
            data['日期'] = pd.to_datetime(data['日期'])
            # 确保包含 end_date 当天的所有数据：使用 < end_date + 1 day
            start_dt = pd.to_datetime(start_date).normalize()
            end_dt = pd.to_datetime(end_date).normalize() + pd.Timedelta(days=1)
            mask = (data['日期'] >= start_dt) & (data['日期'] < end_dt)
            data = data.loc[mask]
        return data
    
    def _download_with_longport(self, stock_code: str, start_date: str, end_date: str) -> pd.DataFrame:
        """使用 LongPort OpenAPI 下载港股数据"""
        if not LONGPORT_AVAILABLE:
            raise RuntimeError("longport-openapi SDK is not installed.")

        from longport.openapi import Period as LPPeriod, AdjustType
        from datetime import datetime

        # 转换代码格式: "00700" -> "700.HK"
        symbol = f"{int(stock_code)}.HK"
        
        start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()

        log.info(f"LongPort downloading HK data for {symbol} from {start_date} to {end_date}")
        
        ctx = longport_client.context
        candlesticks = ctx.history_candlesticks_by_date(
            symbol=symbol,
            period=LPPeriod.Day,
            adjust_type=AdjustType.ForwardAdjust,
            start=start_dt,
            end=end_dt
        )

        if not candlesticks:
            raise RuntimeError(f"LongPort returned no data for {symbol}")

        # 转换为 DataFrame
        data = pd.DataFrame([
            {
                "日期": c.timestamp.date(),
                "开盘": float(c.open),
                "收盘": float(c.close),
                "最高": float(c.high),
                "最低": float(c.low),
                "成交量": float(c.volume),
            }
            for c in candlesticks
        ])
        
        return data

    def _load_failure_cache(self) -> Dict:
        """加载失败记录缓存"""
        if not os.path.exists(self.cache_file):
            return {}
        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log.warning(f"Failed to load failure cache: {e}")
            return {}
    
    def _save_failure_cache(self, cache: Dict):
        """保存失败记录缓存"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache, f)
        except Exception as e:
            log.warning(f"Failed to save failure cache: {e}")
    
    def _record_failure(self, provider: str):
        """记录下载函数失败"""
        cache = self._load_failure_cache()
        now = datetime.now(timezone.utc)
        cache[provider] = {
            'last_failure': now.isoformat(),
            'failure_count': cache.get(provider, {}).get('failure_count', 0) + 1
        }
        self._save_failure_cache(cache)
        log.info(f"Recorded failure for {provider} at {now.isoformat()}")
    
    def _clear_failure(self, provider: str):
        """清除下载函数的失败记录"""
        cache = self._load_failure_cache()
        if provider in cache:
            cache.pop(provider)
            self._save_failure_cache(cache)
            log.info(f"Cleared failure record for {provider}")
    
    def _is_provider_available(self, provider: str) -> bool:
        """检查下载函数是否可用（12小时内未失败）"""
        cache = self._load_failure_cache()
        if provider not in cache:
            return True
        
        failure_info = cache[provider]
        if 'last_failure' not in failure_info:
            return True
        
        try:
            last_failure_str = failure_info['last_failure']
            # 解析ISO格式的datetime字符串，确保是时区感知的
            last_failure = datetime.fromisoformat(last_failure_str)
            # 如果解析出来的是naive datetime，添加UTC时区
            if last_failure.tzinfo is None:
                last_failure = last_failure.replace(tzinfo=timezone.utc)
            
            now = datetime.now(timezone.utc)
            if now - last_failure < self.failure_timeout:
                log.debug(f"{provider} is unavailable (failed {now - last_failure} ago)")
                return False
            else:
                # 超过12小时，清除失败记录
                self._clear_failure(provider)
                return True
        except Exception as e:
            log.warning(f"Error checking provider availability: {e}")
            return True
    
    def download(
        self, 
        stock_code: str,
        start_date: str,
        end_date: str,
        provider: DownloadProvider = DownloadProvider.AUTO
    ) -> Tuple[pd.DataFrame, str]:
        """
        下载港股数据
        
        Args:
            stock_code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            provider: 下载函数提供者，可以是STOCK_HK_HIST、STOCK_HK_DAILY或AUTO（自动切换）
        
        Returns:
            Tuple[DataFrame, str]: (数据, 使用的提供者名称)
        
        Raises:
            RuntimeError: 所有下载函数都失败时抛出
        """
        # 手动指定提供者
        if provider != DownloadProvider.AUTO:
            provider_name = provider.value
            # 手动指定时，即使提供者之前失败过，也允许强制尝试
            is_available = self._is_provider_available(provider_name)
            if not is_available:
                log.warning(
                    f"{provider_name} was marked as failed within last 12 hours, "
                    f"but allowing forced retry since provider was manually specified"
                )
            
            try:
                # Use global pacer to handle implementation-specific pacing and concurrency
                with global_pacer.limit(provider_name):
                    data = self.download_functions[provider_name](stock_code, start_date, end_date)
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(f"Successfully downloaded {stock_code} using {provider_name}")
                return data, provider_name
            except Exception as e:
                self._record_failure(provider_name)
                log.error(f"Failed to download {stock_code} using {provider_name}: {e}")
                raise RuntimeError(f"Failed to download {stock_code} using {provider_name}: {e}")
        
        # 自动切换模式：按优先级尝试可用的下载函数
        available_providers = [
            p for p in self.priority_order 
            if self._is_provider_available(p)
        ]
        
        if not available_providers:
            raise RuntimeError(
                f"All download providers are temporarily unavailable "
                f"(failed within last 12 hours). Please try again later."
            )
        
        last_error = None
        for provider_name in available_providers:
            try:
                # Use global pacer to handle implementation-specific pacing and concurrency
                with global_pacer.limit(provider_name):
                    data = self.download_functions[provider_name](stock_code, start_date, end_date)
                # 成功时清除失败记录
                self._clear_failure(provider_name)
                log.info(f"Successfully downloaded {stock_code} using {provider_name} (auto mode)")
                return data, provider_name
            except Exception as e:
                self._record_failure(provider_name)
                last_error = e
                log.warning(f"Failed to download {stock_code} using {provider_name}: {e}")
                continue
        
        # 所有提供者都失败
        raise RuntimeError(
            f"All download providers failed for {stock_code}. "
            f"Last error: {last_error}"
        )


class HK(OHLC):
    def __init__(self, download_provider: DownloadProvider = DownloadProvider.AUTO):
        """
        初始化HK类
        
        Args:
            download_provider: 下载函数提供者，默认为自动切换模式
        """
        self.download_provider = download_provider
        self.download_manager = HKDownloadFunctionManager()
    
    @staticmethod
    def rename(name):
        return name

    def get_k_data(
        self, 
        stock_code: str, 
        start_date: str, 
        end_date: str, 
        period: Period = Period.DAILY,
        download_provider: Optional[DownloadProvider] = None
    ) -> pd.DataFrame:
        """
        获取港股的K线数据
        
        Args:
            stock_code: 港股代码
            start_date: 开始日期
            end_date: 结束日期
            period: 周期，支持Period.DAILY（日K）和Period.WEEKLY（周K）
            download_provider: 下载函数提供者，如果为None则使用初始化时设置的提供者
        
        Returns:
            DataFrame: OHLC数据
        """

        name = self.rename(stock_code)
        df = None

        # 构建缓存文件路径，包含周期信息
        data_file = data_file_path(stock_code, start_date, end_date, period)

        data = None
        if os.path.exists(data_file):
            data = pd.read_csv(data_file)
            # 删除多余的Unnamed: 0列（如果有）
            if 'Unnamed: 0' in data.columns:
                data.drop('Unnamed: 0', axis=1, inplace=True)
            # 确保Date是索引而不是列
            if 'Date' in data.columns:
                data['Date'] = pd.to_datetime(data['Date'])
                data.set_index('Date', inplace=True)
            
            # 数据清洗
            data = clean_ohlc_data(data)
            
            df = data
            return df
        else:
            if period == Period.DAILY:
                # 使用下载函数管理器获取数据
                provider = download_provider if download_provider is not None else self.download_provider
                try:
                    data, data_source = self.download_manager.download(stock_code, start_date, end_date, provider)
                except RuntimeError as e:
                    log.error(f"Failed to download HK data for {stock_code}: {e}")
                    raise

                new_columns = {'日期': 'date', '开盘': 'open', '收盘': 'close', '最高': 'high', '最低': 'low', '成交量': 'volume'}
                df = data.rename(columns=new_columns)
                df = df[['date', 'open', 'high', 'low', 'close', 'volume']]
                # 统一格式
                df = df.rename(columns={'date': 'Date'})
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
            elif period == Period.WEEKLY:
                # 递归调用获取日线数据
                daily_df = self.get_k_data(stock_code, start_date, end_date, period=Period.DAILY)
                # 重置索引，将Date索引转换为Date列
                daily_df = daily_df.reset_index()
                # 生成周线数据
                df = generate_weekly_kdata(daily_df)
            else :
                raise NotImplementedError(f"港股类目前不支持{period}周期数据获取")
        
 
        df[['open', 'high', 'low', 'close', 'volume']] = df[['open', 'high', 'low', 'close', 'volume']].astype(float)
        # Ensure 'Date' is the index and not also a column to avoid duplicated 'Date' header
        if 'Date' in df.columns and not isinstance(df.index, pd.DatetimeIndex):
            try:
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
            except Exception:
                df = df.drop(columns=['Date'], errors='ignore')

        if 'Date' in df.columns:
            df = df.drop(columns=['Date'], errors='ignore')

        if not os.path.exists(data_file):
            df.to_csv(data_file, index=True)
            
        # 数据清洗
        df = clean_ohlc_data(df)
            
        # 确保index为DatetimeIndex，且命名为'Date'
        if not isinstance(df.index, pd.DatetimeIndex):
            try:
                df.index = pd.to_datetime(df.index)
            except Exception:
                pass
        df.index.name = 'Date'
        return df
