import json
import logging
import os
import akshare as ak
import baostock as bs
import pandas as pd
import efinance as ef

def get_name_from_code(code:str) -> str:
    """
    通过股票代码获取名字
    code 为 输入 股票代码
    """
    name = ""
    if code.startswith("sh") or code.startswith("sz"):
        filename = os.path.join(os.getenv("K_DATA_CENTER") or "/tmp", "a_stock_name.json")
        # logging.debug("get_name_from_code, code : %s, filename : %s", code, filename)
        try:
            name = get_a_stock_name_from_code(code, filename)
        except Exception as e:
            logging.error("get_a_stock_name_from_code failed, code : %s, error : %s", code, e)
            
    elif code.startswith("hk"):
        # 获取path的父目录
        filename = os.path.join(os.getenv("K_DATA_CENTER") or "/tmp", "hk_stock_name.json")
        
        try:
            name = get_hk_stock_name_from_code(code, filename)
        except Exception as e:
            logging.error("get_hk_stock_name_from_code failed, code : %s, error : %s", code, e)
    elif code.startswith("us."):
        return code[3:] # 美股直接返回代码后部分作为名称
    else:
        filename = os.path.join(os.getenv("K_DATA_CENTER") or "/tmp", "etf_name.json")
        try:
            name = get_etf_name_from_code(code, filename)
        except Exception as e:
            logging.error("get_etf_name_from_code failed, code : %s, error : %s", code, e)

    return name



def get_a_stock_name_from_code(code:str, file : str) -> str:
    """
    获取一个A股股票代码的名称
    code 为 输入 股票代码
    path 为 存放结果数据(kv)的路径，需要被查询和更新
    """ 
    if not os.path.exists(file):
        # create empty file
        with open(file, "w", encoding="utf-8") as f:
            json.dump({}, f)

    with open(file, "r", encoding="utf-8") as f:
        kv = json.load(f) 
    
    value = kv.get(code, "")
    if value == "":
        # 登陆系统
        lg = bs.login()
        if lg.error_code != '0' :
            raise Exception(f"baostock login failed, code : {lg.error_code}, msg : {lg.error_msg}")
        
        rs = bs.query_stock_basic(code=code)
        if rs.error_code == '0' and rs.next():
            row = rs.get_row_data()
            name = row[1]  # 一般第2个字段是股票名称
        else:
            name = ""

        # 登出系统
        bs.logout()

        kv[code] = name
        # dump file
        with open(file, "w", encoding="utf-8") as f:
            json.dump(kv, f)

        return name
    else:
        return value

def get_hk_stock_name_from_code(code:str, file : str) -> str:
    """
    获取一个港股股票代码的名称
    code 为 输入 股票代码
    path 为 存放结果数据(kv)的路径，需要被查询和更新
    """ 
    
    # 获取file的父目录
    parent_dir = os.path.dirname(file)
    name_file = os.path.join(parent_dir, "name_hk.csv")

    if not os.path.exists(name_file):
        stock_hk_spot_em_df = ak.stock_hk_spot_em()
        stock_hk_spot_em_df.to_csv(name_file, index=False)
    else :
        stock_hk_spot_em_df = pd.read_csv(name_file)


    # 获取股票代码对应的名称
    stock_code = code[3:]
    # logging.info(stock_hk_spot_em_df.head(10))
    # logging.info("查找股票代码: %s", stock_code)

    # 查找对应的名称, 代码是数字还是字符串
    # 序号    代码       名称    最新价
    # 861,  00175,   吉利汽车,  18.68

    matched_rows = stock_hk_spot_em_df[stock_hk_spot_em_df['代码'].astype(str).str.zfill(5) == stock_code.zfill(5)]
    if not matched_rows.empty:
        name = matched_rows.iloc[0]['名称']
        return name
    else:
        raise Exception(f"get_hk_stock_name_from_code failed, code : {code}") 

def get_etf_name_from_code(code:str, path : str) -> str:
    """
    获取一个ETF股票代码的名称
    code 为 输入 股票代码
    path 为 存放结果数据(kv)的路径，需要被查询和更新
    """ 
    parent_dir = os.path.dirname(path)
    name_file = os.path.join(parent_dir, "name_etf.csv")

    fund_etf_fund_info_em = None
    if not os.path.exists(name_file):
        fund_etf_fund_info_em = ak.fund_etf_fund_daily_em()
        fund_etf_fund_info_em.to_csv(name_file, index=False)
    else :
        fund_etf_fund_info_em = pd.read_csv(name_file)

    # 基金代码             基金简称      类型  ...     增长率      市价     折价率
    # 0    159909   招商深证TMT50ETF行情  ETF-场内  ...   0.12%  7.0200   0.14%
    # 1    159991     招商创业板大盘ETF行情  ETF-场内  ...   0.64%  1.4840   0.02%

    fund_code = code
    matched_rows = fund_etf_fund_info_em[fund_etf_fund_info_em['基金代码'].astype(str).str.zfill(5) == fund_code.zfill(5)]
    if not matched_rows.empty:
        name = matched_rows.iloc[0]['基金简称']
        return name
    else:
        #raise Exception(f"get_etf_name_from_code failed, code : {code}")
        filename = os.path.join(os.getenv("K_DATA_CENTER") or "/tmp", "etf_name_from_efinance.json")
        if not os.path.exists(filename):
            kv = {}
        else:
            with open(filename, "r", encoding="utf-8") as f:
                kv = json.load(f)

        value = kv.get(code, "")
        if value != "":
            return value
        else:
            # 文件里面还没有，从efinance获取
            data = ef.stock.get_quote_history(fund_code)
            name =  data.iloc[0]['股票名称'] 

            kv[code] = name
            # dump file
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(kv, f)
            return name