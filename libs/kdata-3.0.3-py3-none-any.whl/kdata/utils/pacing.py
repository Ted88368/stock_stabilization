import logging
import threading
import time
import random
from typing import Dict, Optional, Any, Set
from contextlib import contextmanager

log = logging.getLogger(__name__)

class Pacer:
    """
    Global pacer to handle implementation-specific rate limits and concurrency.
    Ensures that different providers/threads respect implementation-specific intervals.
    除 mootdx 外，所有下载实现均通过本 pacer 控制请求间隔，mootdx 间隔为 0（不限制）。
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(Pacer, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        
        self.locks: Dict[str, threading.Lock] = {}
        self.last_call_times: Dict[str, float] = {}

        # 各数据源的最小请求间隔（秒）：同一 provider 相邻两次请求之间至少间隔 N 秒。
        # 0 表示不限制；>0 时在 limit() 内会先 sleep 再放行，避免触发接口限流。
        # 未在此处列出的 provider 使用默认间隔 5.0 秒（见 _get_resources）。
        self.intervals: Dict[str, float] = {
            "mootdx": 0.0,  # 本地/直连，不限制
            "efinance": 5.0,  # A股/ETF
            "baostock": 5.0,  # A股
            "akshare": 5.0,   # A股/ETF/指数等
            "stock_hk_hist": 5.0,   # 港股
            "stock_hk_daily": 5.0,  # 港股日线
            "yfinance": 5.0,        # 美股 Yahoo Finance
            "stock_us_daily": 5.0,  # 美股日线
            "longport": 0.1,  # 港美股 LongPort，约 10 次/秒
        }

        # 允许并行下载的 provider（仅限此类可多请求同时进行）；其余均严格串行，持锁贯穿整个 with 块，保护对方服务器。
        self.parallel_providers: Set[str] = {"longport"}

        self.state_lock = threading.Lock()
        self._initialized = True

    def _get_resources(self, implementation: str):
        """Get or create lock and last_call_time for an implementation."""
        with self.state_lock:
            if implementation not in self.locks:
                self.locks[implementation] = threading.Lock()
                self.last_call_times[implementation] = 0.0
            # 未在 intervals 中配置的 provider 默认间隔 5.0 秒
            interval = self.intervals.get(implementation, 5.0)
            return self.locks[implementation], interval

    @contextmanager
    def limit(self, implementation: str):
        """
        Context manager for rate limiting.
        除 mootdx 外均会做间隔控制；mootdx 直接放行不限制。

        Usage:
            with global_pacer.limit("longport"):
                # your call here
        """
        if not implementation:
            yield
            return
        if implementation == "mootdx":
            yield
            return

        lock, interval = self._get_resources(implementation)
        strict_serial = implementation not in self.parallel_providers

        if strict_serial:
            # 严格串行：持锁直到 with 块结束，同一时刻仅一个请求，保护对方服务器
            lock.acquire()
        try:
            to_sleep = 0
            if interval > 0:
                if strict_serial:
                    now = time.monotonic()
                    elapsed = now - self.last_call_times.get(implementation, 0.0)
                    if elapsed < interval:
                        to_sleep = interval - elapsed + random.uniform(0.0, 0.05)
                        self.last_call_times[implementation] = now + to_sleep
                    else:
                        self.last_call_times[implementation] = now
                else:
                    with lock:
                        now = time.monotonic()
                        elapsed = now - self.last_call_times.get(implementation, 0.0)
                        if elapsed < interval:
                            to_sleep = interval - elapsed + random.uniform(0.0, 0.05)
                            self.last_call_times[implementation] = now + to_sleep
                        else:
                            self.last_call_times[implementation] = now

            if to_sleep > 0:
                log.info(
                    f"Pacer: implementation '{implementation}' rate limited. Sleeping {to_sleep:.3f}s..."
                )
                time.sleep(to_sleep)

            yield
        finally:
            if strict_serial:
                lock.release()

    def wait(self, implementation: str):
        """
        Legacy wait method for backward compatibility.
        """
        with self.limit(implementation):
            pass

# Global singleton instance
global_pacer = Pacer()
