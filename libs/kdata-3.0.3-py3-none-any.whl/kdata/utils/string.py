import pandas as pd

def add_prefix_to_list(lst, prefix):
    return [prefix + str(item) for item in lst]


def kdata_to_json(df: pd.DataFrame) -> str:
    """
    将kdata转换为json字符串
    :param df: kdata数据
    :return: json字符串
    """
    # 创建副本以避免SettingWithCopyWarning
    df = df.copy()
    
    # 检查是否需要重置索引，如果索引名已经是列名则避免重复
    if df.index.name and df.index.name in df.columns:
        # 索引名已存在列中，不需要reset_index
        pass
    else:
        df = df.reset_index()
        
    # 安全地删除可能存在的'index'列
    if 'index' in df.columns:
        df = df.drop('index', axis=1)
        
    # 同样确保Date列是字符串格式的日期
    if 'Date' in df.columns:
        # 检查是否为数值类型    
        if pd.api.types.is_numeric_dtype(df['Date']):
            # 数值型时间戳转换为datetime
            df['Date'] = pd.to_datetime(df['Date'], unit='ms')

        # 无论是什么类型，都转换为字符串格式的日期
        df['Date'] = df['Date'].dt.strftime('%Y-%m-%d') if hasattr(df['Date'], 'dt') else df['Date'].astype(str)    
    # float 怎么在json格式只保留3位小数
    df = df.round(3)
    # 删除"index"列
    if 'index' in df.columns:
        df = df.drop('index', axis=1)
        
    return df.to_json(orient="records")



def combine_lists(list1: list[str], list2: list[str]) -> list[str]:
    """
    合并两个字符串列表，考虑为None的情况
    :param list1: 第一个字符串列表
    :param list2: 第二个字符串列表
    :return: 合并后的字符串列表
    """
    if list1 is None:
        list1 = []
    if list2 is None:
        list2 = []

    #  如果不是str,则转换为str
    list1 = [str(item) for item in list1]
    list2 = [str(item) for item in list2]
    l = list1 + list2
    # 去重
    l = list(set(l))
    # 排序
    l.sort()
    return l